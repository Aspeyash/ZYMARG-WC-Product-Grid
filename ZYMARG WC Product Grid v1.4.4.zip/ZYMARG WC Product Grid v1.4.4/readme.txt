=== ZYMARG WC Product Grid ===
Contributors: zymarg
Tags: woocommerce, elementor, product grid, product slider, dokan, astra, quick view, wishlist, trending, algolia, recommendations
Requires at least: 6.2
Tested up to: 6.7
Requires PHP: 7.4
Stable tag: 1.4.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Customisable WooCommerce Product Grid and Product Grid Slider widgets for Elementor. Quick View modal, Buy Now flow, wishlist, trending, similar, vendor, Algolia search, per-visitor recommendations, and more.

== Description ==

A single Elementor widget that renders WooCommerce products as a responsive grid or as a Swiper-powered slider, with full Elementor styling controls and eleven product-source modes including a per-visitor "Recommended For You" personalised feed.

= Features =

* **One widget, two layouts**: ZYMARG Product Grid renders as either a responsive grid or a Swiper-powered slider, controlled by the Layout setting.
* **Eleven product sources**: All products, Dynamic, Featured, Trending, Recommended For You (personalised), Similar, More From Seller (Dokan), Recently Viewed, Wishlist, Category (auto-detected), Algolia (search results).
* **Eleven toggleable card elements**: image, discount badge (percent / amount / both), stock badge, wishlist heart, quick view, add-to-cart, title (1-3 line clamp), rating (auto-hides), sold count (auto-hides), bold current price, strikethrough subscript old price.
* **Heading section** above the grid with toggle, alignment, "View All" link.
* **Three responsive breakpoints** with locked icon positioning per spec.
* **Variable product pricing** rule: lowest sale price bold + lowest regular strikethrough, left-aligned.

= Quick View modal =

* Opens on click of the eye icon.
* Auto-detected colour swatches for `color` / `colour` / `pa_color` attribute slugs.
* Other attributes render as rounded dropdowns.
* Add-to-Cart and Buy Now action buttons.
* "View full details" link to the PDP.
* Focus trap, escape-to-close, click-outside-to-close.
* Six-tier responsive sizing from Large Desktop (1600px+) down to Small Mobile (<600px).

= Buy Now flow =

* Snapshots the user's cart, replaces with the chosen product, redirects to checkout.
* On order completion: original cart restored.
* On abandon (15-min token expiry or user navigates away from checkout): cart restored.
* Existing cart never lost.

= Trending engine =

* Action Scheduler-driven engagement pipeline.
* Click / quick-view / wishlist-add / cart-add events buffered + flushed every 5 min.
* Top-200 trending list recomputed every 30 min.
* Cold-start seeding from last 90 days of orders on activation.
* Editor-preview diagnostic buttons (Recompute / Flush / Reset).

= Dokan integration =

* "More From Seller" source with 4-step vendor resolution waterfall.
* Staff module support.
* Per-vendor cache (30 min) with auto-invalidation.
* Hides widget when vendor has no other products.
* Editor-preview diagnostic buttons (Clear cache / Test resolution).
* Vendor profile row on every card with avatar, name, location, and store link.

= Algolia integration =

* Source mode for the search-results page.
* Click-position tracking via Algolia analytics IDs (`data-algolia-query-id` / `data-algolia-position`).
* Click events routed through the plugin's own `track_click` AJAX endpoint.

= Wishlist =

* Logged-in: synced via user meta across devices.
* Guest: cookie + WC session, survives session expiry.
* Login merge: guest cookie unioned into user meta on login.
* Cache-safe heart hydration on every page load.

= Recently Viewed =

* Tracks every product page view automatically.
* Logged-in: user meta. Guest: cookie + WC session.

= Security =

* All AJAX endpoints nonce-protected.
* Per-IP rate limiter with daily-rotating salt.
* Configurable per-action limits.
* All internal SQL uses `$wpdb->prepare()` with placeholders.
* No custom database tables.
* HPOS + Cart/Checkout Blocks compatibility declared.

= Compatibility =

* WordPress 6.2+, PHP 7.4-8.3.
* WooCommerce 7.0+ (HPOS-ready, Blocks-ready).
* Elementor Free 3.18+ (no Pro required).
* Astra theme (free + Pro detected).
* Dokan Lite + Pro 3.10+.
* Swiper 11 (auto-detects Elementor Pro's handle, else loads a local bundle, falls back to jsDelivr CDN).

= Extensibility =

* Theme template overrides under `theme/zymarg-wcpg/<path>`.
* Filterable product-source registry via `zymarg_wcpg_source_registry` (register custom sources without touching the plugin).
* All AJAX handlers are class-based and replaceable via standard WP filters.

== Installation ==

1. Upload the `zymarg-wc-product-grid` folder to `/wp-content/plugins/`.
2. Activate the plugin through the Plugins screen.
3. Edit any page with Elementor and look for the **ZYMARG WooCommerce** category in the widgets panel.

== Changelog ==

= 1.4.4 =
* Feature (Quick View - swatches): variation swatches inside the Quick View modal are now **uniform text-only pill buttons** for every attribute type (color, image, label, button, select). The original auto-detection in `Quick_View_Data` is preserved in case any custom CSS/JS keys off `data-attr-type`, but the visible UI is now consistent regardless of attribute type. Matches the user's single-product-page Woo Swatches plugin visual style.
* Feature (Quick View - swatch states): default state has a thin lavender outline-variant border (`#d8bfd3`), hover tints the background to surface (`#faf8ff`), selected state turns solid ZYMARG primary purple (`#9500a5`) with white text, unavailable state is dimmed + line-through. All states use brand palette tokens, no hardcoded greys.
* Feature (Quick View - quantity stepper): redesigned as a **single rounded container** with `−` on the left, centered number, `+` on the right. 48px tall, brand-aligned `#d8bfd3` border, transparent buttons with `#faf8ff` hover. Full-width within its column. Replaces the previous segmented design where each element had its own pill.
* Feature (Quick View - action buttons): Add to cart and Buy now are now styled in the ZYMARG brand palette and laid out **inline side-by-side** (50/50 split with a 10px gap):
    - **Add to cart**: solid `#9500a5` primary purple background, white text
    - **Buy now**: solid `#bd00d1` primary-container purple (slightly brighter shade for visual differentiation)
    - **Hover states**: Add to cart darkens to `#7a0089`, Buy now darkens to `#a000b8`
    - **Disabled state** (when variation not yet selected on variable products): both buttons go to `#d8bfd3` muted lavender with `#534152` text, matching the disabled look on the single-product page.
* Responsive (Quick View - action buttons): at Small Mobile viewport (<600px, where the modal is full-screen and the right column gets cramped), the two action buttons **auto-stack vertically** while staying full-width. Tablet and Large Mobile keep them inline side-by-side.
* Refactor (Quick View CSS): consolidated the prior 5 swatch-variant style blocks (`--color`, `--image`, `--label`, `--button`, plus the `<select>` styles) into a single unified pill style. Removed `.zymarg-wcpg__qv-swatch-icon` and `.zymarg-wcpg__qv-swatch-letter` rendering from the template; the corresponding CSS keeps them hidden as a safety net for theme overrides still emitting those elements.
* Quick View internal accent: the "View full details" link color updated from generic `#1a73e8` blue to brand `#9500a5` purple to match the rest of the modal.
* Compatibility: 100% backward compatible. Quick View AJAX endpoint, variation matching JS, Add-to-cart flow, Buy-now cart-snapshot state machine, focus trap, escape-to-close, click-outside-to-close, modal sizing across all 6 responsive tiers - **all untouched**. Theme overrides of `swatches.php` from any prior version keep working (won't pick up the unified pill style until re-copied from v1.4.4 - additive only; legacy icon/letter spans hidden via CSS fallback).

= 1.4.3 =
* Fix (mobile divider): the divider between rating and sold count is now visible at every breakpoint. v1.4.2 hid it at <=480px to save 5px of horizontal space, but user feedback confirmed the divider is essential UX (`rating | divider | sold count` is the intended visual). The hide rule has been removed and the divider element returns on mobile in all three layouts (inline, count_first, count_indicator).
* Fix (font-size mismatch): the indicator rating value (`★ 4.5`) and the sold count text are now the **same size** on mobile. Before v1.4.3, the indicator value was 11px (via the count-indicator override) while the sold count was still 13px (no mobile override), making them visually mismatched. Sold count is now explicitly 11px at <=480px to match the indicator value. Desktop and tablet sizes are unchanged (both already 13px there).
* Fix (empty row right side): the meta row at narrow viewports was left-bunched with empty space on the right. Rating + divider + sold-count are now wrapped in a `.zymarg-wcpg__meta-end` flex group with `flex: 1` and `justify-content: space-between`. The stock badge stays anchored at the row's left edge; the rating-sold cluster fills the remaining width with the rating element pushed to the left of the group and the sold count pushed to the right - so the divider lands naturally in the centre. Works uniformly across all three layouts.
* Architecture: the meta-row template now emits a two-tier structure when both a stock badge and rating-or-sold exist: `<.zymarg-wcpg__meta><stock-badge><.zymarg-wcpg__meta-end>rating + divider + sold</></ >`. When stock badge is absent, `.zymarg-wcpg__meta-end` is the only child and still fills the full row width (rating left, sold right). When stock badge is the only thing rendering, no end-group wrapper is emitted (single-element row, left-aligned by default).
* Theme override note: themes that copy `templates/grid/rating-soldcount.php` from v1.4.2 or earlier will keep working but won't get the new distribution behaviour until re-copied from v1.4.3. The wrapper class is purely additive - no signature changes.
* Compatibility: 100% backward compatible. All existing widget settings, theme overrides, AJAX payloads continue to work unchanged. CSS additions only - no removals.

= 1.4.2 =
* Feature: **Rating & sold count Layout is now a responsive control** — pick `Inline` / `Count first` / `Indicator` (★ 4.5) independently per Desktop / Tablet / Mobile under Content → Rating & sold count → Layout. New defaults: Desktop=Inline, Tablet=Inline, **Mobile=Indicator** (so narrow cards automatically swap the 5-star graphic for the compact `★ 4.5` variant).
* Feature: New responsive SWITCHER **Show "Sold" word** under the same section. When off, sold count renders as just the number (e.g. `120` instead of `Sold 120`). Defaults: Desktop=Show, Tablet=Show, **Mobile=Hide**. Saves ~30px of horizontal space on narrow cards. The `+` suffix from the `Sold {n}+` format is preserved (becomes `120+`) so rounded counts still read correctly.
* Fix (rating star width): aggressive size compression on the 5-star graphic. Star font-size 11px → **9px** and `letter-spacing` 1px → **0**, dropping the total 5-star block from ~60.5px to **~45px** (~26% narrower). `!important` flags applied so Astra theme + LiteSpeed cache no longer override the rule (a long-standing reason the v1.3.26 11px change wasn't visible on live sites).
* Fix (375px content row clipping): the v1.3.28 meta row used `overflow: hidden` + `flex-shrink: 1` + `text-overflow: ellipsis` on the sold count to enforce single-line behaviour, but on 2-column 375px viewports the sold count was being clipped to zero width and disappearing entirely after the divider. The clipping logic is replaced with **structural compression**: at viewports ≤480px the stock badge gets tighter padding (4px 10px → 2px 6px), the meta gap drops from 8px to 4px, the divider hides, and the price + vendor row gaps shrink to 4px. Combined with the responsive layout + show-sold-text controls above, all three content rows now fit on a single line at 375px without ellipsis or clipping.
* Architecture: the rating-soldcount template now signature-dedupes the three breakpoint variants. When desktop/tablet/mobile would render identical HTML (the common case for users who haven't customised per-device) a **single** variant is emitted with the `--variant-all` class. When they differ, up to three variants are emitted with `--variant-desktop` / `-tablet` / `-mobile` classes and CSS at Elementor's 1024px / 767px breakpoints shows exactly one at a time. Per-device variation costs no extra HTML on the default path.
* New: Load More AJAX payload now echoes `meta_layout_tablet`, `meta_layout_mobile`, `show_sold_text`, `show_sold_text_tablet`, `show_sold_text_mobile` so paginated cards preserve the user's per-breakpoint settings.
* Compatibility: 100% backward compatible. Widgets saved before v1.4.2 that only had `meta_layout` set (non-responsive) auto-inherit that value for tablet + mobile, then the indicator variant kicks in on mobile via the new default. To preserve pre-1.4.2 mobile behaviour exactly, set `Layout (Mobile) = Inline` in the widget. No template signature changes; the `rating-soldcount.php` template still accepts the same input variables. Theme overrides from any prior version continue to work, but won't get the responsive variant feature until re-copied from v1.4.2.

= 1.4.1 =
* Feature: Heading "View All" link now auto-resolves to the vendor's Dokan storefront URL when **Source = More From Seller (Dokan)**. New SWITCHER control **Auto-link to vendor store** under Content → Heading, default ON, visible only when source = vendor AND View All is enabled. When on, the manual View All URL field is hidden (no point showing an input that gets overridden) and the button links to the same vendor that the source itself resolves on the page. Toggle off to fall back to a manual URL.
* Detection logic mirrors `Source_Vendor::detect_vendor_context_product_id()` exactly, so the View All link and the products grid always agree on which vendor they point to. Honours the existing `vendor_auto_detect` + `vendor_product_id` settings.
* Fallback chain (any failure returns settings unchanged - manual URL still works): Dokan inactive → no product context → vendor unresolved → vendor suspended → `dokan_get_store_url()` returns empty. In all those cases the existing "hide link when URL is empty" guard in `grid-wrapper.php` / `slider-wrapper.php` takes over silently.
* Target / nofollow / new-tab settings on the manual URL field are preserved when the auto override fires — only the URL string itself is overridden.
* Resolution happens BEFORE the template loads in `Widget_Product_Grid::render()`, so theme overrides of `templates/grid/grid-wrapper.php` and `templates/slider/slider-wrapper.php` automatically benefit. Both grid and slider layouts work identically.
* New helper: `Vendor_Resolver::get_store_url( $vendor_id )` — wraps Dokan's official `dokan_get_store_url()` with safety checks (Dokan version guard, throwable safety, falsy-return normalisation). Returns absolute URL on success or empty string on failure.
* Compatibility: 100% backward compatible. Existing widgets with manual URLs saved keep their stored value untouched — the override only happens in-memory at render time when the conditions match. Legacy widgets with no `view_all_auto_vendor` setting get the auto behaviour by default (matches the new control's default).

= 1.4.0 =
* Feature: New product source **"Recommended For You"** — per-visitor personalised feed available from the Source dropdown alongside the existing ten modes. Builds a taste profile from the visitor's wishlist, recently-viewed products, purchase history (last 180 days, logged-in users only), and engagement events; scores a bounded candidate pool of up to 200 products across five weighted dimensions (category, purchase, brand, seller, trending); applies a soft 24-hour recency penalty so the feed never re-shows the same item the visitor just looked at; enforces a max-products-per-vendor cap (default 3) so a single Dokan seller never dominates the grid.
* Feature: Scoring weights are fully admin-tunable via five SLIDER controls in **Layout → Recommended For You settings**. Defaults: Category 40, Purchase 30, Brand 15, Seller 10, Trending 5. Weights are normalised at runtime so absolute values don't matter — only the ratio between them does.
* Feature: Brand affinity auto-detects `product_brand` (WooCommerce 9.x+ native), `pwb-brand` (Perfect Brands), or `yith_product_brand` (YITH WooCommerce Brands). When no brand taxonomy is detected the brand-weight slot is redistributed evenly between category and purchase, so the "15%" setting is never silently wasted. Filterable via `zymarg_wcpg_brand_taxonomy`.
* Feature: Seller affinity uses the existing 4-step Vendor_Resolver waterfall. Auto-redistributes to category weight when Dokan is not active.
* Feature: Cold-start strategy control with four options — **hybrid** (default: 50% similar-to-recently-viewed + 30% trending + 20% best-sellers), **trending** (pure trending top-N), **featured** (WooCommerce featured flag), **bestsellers** (lifetime total_sales). Activates automatically when the visitor's profile has fewer than 3 total engagement-weight points (brand-new guest, fresh install).
* Feature: Toggle **Hide already-purchased products** (default on, last-180-day order history). Turn off for replenishment / consumables stores.
* Feature: Final scored ID list cached per-visitor via the new `Affinity_Cache` layer. Logged-in users get a 1h transient keyed by `user_id + settings hash`. Guests get a 15min transient keyed by a hash of their RV/wishlist cookie state. Cache is invalidated atomically on wishlist add/remove (`zymarg_wcpg_wishlist_changed`), cart add (`woocommerce_add_to_cart`), and order completed/processing transitions — via per-user salt rotation in `user_meta` so we never have to scan the transients table.
* Architecture: Three new classes under `includes/Recommendations/` — `Affinity_Profile` (taste-profile builder, normalises category/brand/vendor scores to 0..1, computes 10th/90th-percentile price band), `Affinity_Cache` (transient + salt-rotation layer), `Cold_Start_Fallback` (hybrid/trending/featured/bestsellers strategies). One new source class — `includes/Query/class-source-recommended.php`. All wired into the existing `Query_Builder` registry via the `zymarg_wcpg_source_registry` filter so custom sources can still plug in without code changes.
* Compatibility: 100% backward compatible. The new source is opt-in — existing widgets keep their current source unchanged. All new controls default to safe values. No template changes. Theme overrides of `templates/grid/*.php` from any earlier version continue to work unchanged.

= 1.3.29 =
* Fix (critical): Discount badge was still rendering on a new line below the price on cards where ATC is paired with the vendor or meta row (i.e. not in the price row). Root cause: my v1.3.26 fix used `.zymarg-wcpg__row--price { display: flex; flex-wrap: nowrap; ... }` which is a single-class selector (specificity 0,1,0). The base rule `.zymarg-wcpg__row { display: block; ... }` is defined LATER in the same CSS file with the same specificity (0,1,0), so the cascade picked the later block rule. The v1.3.26 fix appeared to work ONLY when ATC was paired into the price row, because that adds `.zymarg-wcpg__row--has-atc { display: flex }` even later in the file. Cards with ATC paired elsewhere had a block-level price row and the inline discount badge fell to a new line.
* Resolution: rule promoted to compound selector `.zymarg-wcpg__row.zymarg-wcpg__row--price` (specificity 0,2,0), which beats the base block rule unconditionally regardless of file order. Applies to all 3 price-position variants (above title, above rating, below rating) and all ATC-pairing modes.
* No template or PHP changes - CSS specificity fix only. Theme overrides unaffected.

= 1.3.28 =
* Feature (UX): Price row, meta row (rating + sold count) and vendor row are now single-line on every viewport from 375px upward. No more wrapping to a second line on narrow mobile cards - every product card now has exactly 4 predictable rows (title clamped to your line count, plus three single-line rows), so the grid stays visually uniform.
* Technique: `flex-wrap: nowrap` on all 3 rows + `min-width: 0` on flex containers + priority-based ellipsis truncation. Critical elements (prices, discount badge, stock badge, star icon, divider, avatar, ATC button) never shrink. Soft text (sold count, vendor name, vendor location) truncates with ellipsis (`...`) when space is tight.
* Truncation priority order: vendor location -> vendor name -> sold count. Prices and badges never truncate.
* Vendor row UX update: name and location now sit side-by-side on a single line separated by `·` (middle dot), e.g. `Vendor X · Dhaka`. Previously stacked vertically. Separator only appears when location is rendered.
* Removed: `Stacked` option from **Content -> Rating & sold count -> Layout**. Widgets that had stacked saved fall back to `Inline` automatically (graceful migration - no broken cards). If you preferred stacked, the v1.3.27 implementation is preserved in git history.
* Layout options now (3, down from 4): `Inline`, `Count first`, `Indicator`.
* Backwards compatibility: theme overrides of `rating-soldcount.php` from v1.3.27 still work - the layout validator silently coerces unknown values to `inline`. CSS for `.zymarg-wcpg__meta--stacked` kept on disk as a no-op safety net for theme overrides still emitting the class.

= 1.3.27 =
* Refactor: **Style > Content Box Spacing & Widths** section simplified to **Style > Content Box Spacing**. The ten per-element max-width controls added in v1.3.26 have been removed in favour of the four per-row gap controls only. Net result: 14 controls -> 4 controls, all still responsive (separate values per desktop / tablet / mobile).
* Kept controls (still responsive): content rows gap, meta row gap, price row gap, vendor row gap.
* Removed controls: stock badge / rating / divider / sold count max-widths in meta row; price / discount badge / ATC max-widths in price row; vendor name / vendor location max-widths in vendor row; ATC max-width in standalone ATC row.
* Migration: widgets that already had max-width values saved from v1.3.26 will silently ignore those saved values - the controls are gone so they have no effect. No visual regression because the underlying CSS defaults are still in place. If max-width control is needed again in future, restore from v1.3.26 git history.
* Backwards compatibility: every kept control still defaults to unset, so freshly upgraded widgets render identically to v1.3.26.

= 1.3.26 =
* Fix: Discount badge no longer wraps to a new line below the price on narrow mobile screens (e.g. two-column 375px viewports). The price row now uses `display:flex` with `flex-wrap:nowrap` and the price text element gets `min-width:0` so it can shrink/truncate if a card is genuinely too narrow to fit everything. The badge stays inline with the price on desktop, tablet and mobile.
* Improvement: Rating stars reduced from 14px to 11px (height/width scaled to match). Total stars row drops from 80px wide x 16px tall to 60.5px wide x 11px tall — better proportion next to small price/title text on mobile cards.
* Feature: New meta layout option "Indicator — ★ 4.5 | Sold count". Replaces the 5-star graphic with a single star icon and the numeric average rating. Useful for compact cards on mobile where the 5-star graphic competes with price + stock badge for horizontal space. Selectable under **Content → Rating & sold count → Layout**.
* Feature: Typography group control added for the stock badge under **Style → Stock badge**. Font family, size, weight, line-height, letter-spacing and text transform — applied to both in-stock and out-of-stock variants so they stay visually consistent.
* Feature: New **Style → Content Box Spacing & Widths** section. ~14 new responsive controls (separate values per desktop / tablet / mobile) for fine-grained layout control of every content-box row:
  * Content rows — gap between rows.
  * Meta row — gap between elements; max width per element (stock badge, rating, divider, sold count). The sold count and rating widths force ellipsis truncation when the cap is hit.
  * Price row — gap between elements; max width per element (price, discount badge, ATC button).
  * Vendor row — gap between elements; max width per element (vendor name, vendor location). Name and location both truncate with ellipsis when capped.
  * Standalone ATC row — max width for the ATC button.
* Backwards compatibility: every new control defaults to "unset" so a freshly upgraded widget renders identically to v1.3.25. Controls only kick in when the user explicitly sets a value.

= 1.3.25 =
* Feature: Discount badge moved from the image overlay into the price row. Now sits inline next to the price, before the Add-to-Cart button. Applies to all breakpoints (desktop, tablet, mobile).
* Feature: Stock badge ("In stock" / "Out of stock") moved from the image overlay into the meta row. Now sits inline as the leftmost element, before the rating and sold count. Applies to all breakpoints.
* Feature: New Quick View "Display style" control added under Content > Quick view CTA. Two options: "Hover only" (default — icon is hidden until the user hovers the card on a hover-capable device) and "Always visible" (legacy behaviour). Touch devices that report `hover: none` fall back to always-visible regardless of the setting, so the icon is never permanently hidden on phones/tablets that detect as desktop by width.
* Compatibility: Theme overrides that copy `templates/grid/rating-soldcount.php` from earlier versions will continue to work — the new `$stock_badge_html` template variable is optional and defaults to empty. To opt into the new stock-badge-in-meta-row layout, re-copy the template from this version.
* Compatibility: Theme overrides that copy `templates/grid/badges.php` from earlier versions still load without errors. The plugin no longer calls that file from `product-card.php`, but it remains on disk. Themes that rely on the absolutely-positioned image-overlay badges can restore the old layout by editing their copy of `product-card.php` to re-call `badges.php`.
* Internal: AJAX search-page handler defaults to `quickview_display=always` so the search results page UX is unchanged.

= 1.3.24 =
* Maintenance: Fixed Composer PSR-4 prefix in `composer.json` (was `Aspeyash\WCPG\`, now correctly `Zymarg\WCPG\` to match every `namespace` declaration). Prevents an autoload break the day anyone runs `composer install` or `composer dump-autoload`.
* Docs: `readme.txt` refreshed to match the current codebase. Updated plugin name, contributor handle, Stable tag (was 1.3.19), Tested up to (6.6 -> 6.7), and the feature list (now 10 product sources including Algolia and Category; one widget with two layouts, not two widgets).
* Security (hardening): All three remaining direct-SQL queries that used `IN ($ids_in)` string interpolation now use `$wpdb->prepare()` with `%d` placeholders. Affected files: `Trending/class-trending-calculator.php` (publish-date and lifetime-sales lookups), `Query/class-source-trending.php` (re-score date lookup). Values were already int-cast, so this is not a fix for an exploitable vulnerability — it is a defence-in-depth cleanup that also removes the `phpcs:ignore` suppressions.
* Security (hardening): Wishlist cookie reader now caps incoming cookie size at 4 KB before `json_decode()`. Prevents a malicious client from forcing the server to parse an oversized JSON payload. Browsers cap cookies at 4 KB anyway, so legitimate users see no change.
* Tooling: Added `.github/workflows/version-drift-check.yml` GitHub Action. On every push and PR, unzips the plugin and confirms that the plugin header version, the `ZYMARG_WCPG_VERSION` constant, and the readme `Stable tag` all match. Build fails on drift. Prevents the kind of drift the 1.3.19 -> 1.3.23 mismatch caused.

= 1.3.23 =
* See plugin history. (No functional changes carried forward; baseline for the 1.3.24 maintenance pass.)

= 1.3.19 =
* Improvement: Vendor avatar is now fully customizable in Elementor. New controls added to the Vendor Profile section: Avatar size expanded from 16–48px to 12–80px range. Avatar side — choose Left (default) or Right of the vendor name. Avatar shape — Circle (default), Rounded square, or Square. Show border toggle with a color picker. All controls are conditional (only visible when avatar display is enabled) and apply instantly in the Elementor editor preview.

= 1.3.18 =
* Improvement: Quick View modal now uses a full 6-tier responsive sizing spec. Large Desktop (1600px+) 960px/90vh; Desktop (1200-1599px) 900px/90vh; Laptop (992-1199px) 820px/90vh — all two-column 50/50. Tablet (768-991px) 92vw/720px max/92vh two-column 45/55 with tighter padding and smaller typography. Large Mobile (600-767px) 95vw/95vh single column with touch-friendly 44px button targets. Small Mobile (<600px) full-screen 100vw/100vh single column with 48px touch targets. Previously the modal was the same size on all devices above 600px.

= 1.3.17 =
* Fix: Quick View button on the Algolia search results page did nothing when clicked. Root cause: the modal overlay shell (`.zymarg-wcpg__qv-overlay`) is only injected into `wp_footer` when `QuickView_Modal::flag_mount()` is called, which previously only happened inside the Elementor widget renderer. On the standalone search results page no widget renders, so the shell was never printed and `quickview.js` had no DOM element to open. Fix: `flag_mount()` is now called inside `enqueue_search_page_assets()` so the modal shell is always present on search pages.

= 1.3.16 =
* Fix (critical): Add to Cart returning "Something went wrong" on all pages. Root cause: WooCommerce 7.0+ with HPOS does not automatically load the cart/session for AJAX requests. WC()->cart existed as an object but had no session, so add_to_cart() silently returned false triggering the error response. Fix: wc_load_cart() is now called at the top of both Handler_Add_To_Cart and Handler_Buy_Now before any cart operations. This correctly initialises WC()->cart, WC()->customer, and WC()->session for the AJAX context. Wishlist and QuickView were unaffected because they never touch WC()->cart.

= 1.3.15 =
* Fix (critical): is_search_page() was only checking ?s= and ?q= query strings. ZYMARG search uses clean URLs (/search/query) with no query string, so the check always returned false — scripts and nonce were never enqueued on the search page. Quickview and ATC AJAX calls failed because ZYMARGWCPG.nonce was never in the page. Fixed by adding a regex check against REQUEST_URI for the /search/ path prefix.
* Fix: Search page JS was enqueued in wp_footer at priority 1 (after wp_localize_script had already output). Moved both CSS and JS enqueue to wp_enqueue_scripts priority 15 so the inline ZYMARGWCPG localize block is correctly output in <head> before the deferred scripts execute. Nonce is now always present for ATC and quickview on the search page.
* Fix: Split enqueue_search_page_styles() and enqueue_search_page_scripts() methods merged into single enqueue_search_page_assets() hooked at wp_enqueue_scripts priority 15.

= 1.3.14 =
* Fix: Quick view button and Add to Cart now work correctly on the search results page. Root cause: quickview.js had an early-exit guard at line 3 (`if (!ns.ajaxUrl) return`) that caused the entire script to bail out on the search page because ZYMARGWCPG is populated asynchronously there — all 12 event handlers never registered so clicks did nothing. Fix: removed the early-exit guard entirely. All handlers use $(document).on() delegation and are registered immediately at script parse time. ajaxUrl and nonce are now read lazily inside each handler via getNs() at click time, by which point ZYMARGWCPG is always fully populated. frontend.js already had the correct lazy getNs() pattern and required no changes.

= 1.3.13 =
* Fix: Vendor profile now enabled on search results page (show_vendor = yes) to match Elementor widget defaults. Search page should mirror homepage exactly — same features, same design, same behaviour.

= 1.3.12 =
* Fix: Search results page now inherits all card features added since v1.3.5. The AJAX handler (class-handler-search-cards.php) had a hardcoded $settings array missing every key introduced in v1.3.6–v1.3.11: quickview_visibility, show_vendor, vendor_position, vendor_display, vendor_link, vendor_avatar_size, price_position, show_rating, show_sold_count, sold_count_format, meta_layout. All keys are now declared with correct search-page defaults. Quick view is set to "all" devices on the search page (visible on mobile, tablet, and desktop). Vendor profile remains off by default (Dokan dependency — enable by changing show_vendor to "yes" in the handler). The Option B POST override escape hatch is preserved so the search page JS can still pass custom settings without a code change.

= 1.3.11 =
* Fix: Quick view CSS audit — two bugs corrected. (1) Conflict guard was a single @media (max-width:1024px) block covering both tablet and mobile together, meaning "mobile only" mode incorrectly moved the wishlist button on tablet too. Guards are now split into separate tablet and mobile @media blocks so each breakpoint is handled independently. (2) Two separate rules for .zymarg-wcpg__icon-btn--quickview with same specificity (position then display:none) were consolidated into a single rule eliminating the specificity race condition.

= 1.3.10 =
* Fix: Added missing "Below price" option to vendor position control. When price is set to "Above rating", vendor renders between the price block and the rating row. When price is set to "Below rating" (default), vendor renders after the entire bottom row (price + ATC). Total vendor position options now: Below title, Above price, Below price, Above rating & sold count, Below rating & sold count.

= 1.3.9 =
* Feature: Vendor profile position control. New "Position" select under Content > Vendor profile with four options: Below title (default), Above price, Above rating & sold count, Below rating & sold count. The card template now uses four named slots — vendor renders in exactly one slot based on the setting. Fully compatible with the price position setting added in v1.3.7.

= 1.3.8 =
* Feature: Quick View CTA visibility control. New "Visible on" select under Content > Quick View CTA with six options: Desktop only (default), Tablet only, Mobile only, Desktop & Tablet, Tablet & Mobile, All devices. Implemented via data-qv-visibility CSS attribute — no JS, no layout reflow. Conflict guard auto-moves wishlist to bottom-right when quickview is also visible on tablet/mobile so both icons never overlap.

= 1.3.7 =
* Feature (Task 1): Price position control added under Content > Price. Choose "Above rating & sold count" to move the price between the vendor row and the rating row, or keep the default "Below rating & sold count" where price sits in the bottom row alongside the ATC button.
* Feature (Task 2): Rating & Sold Count layout control added under Content > Rating & sold count. Three options: Inline (stars | divider | sold count, default), Stacked (stars on first line, sold count on second line), Count first (sold count | divider | stars).

= 1.3.6 =
* Feature: Vendor profile row on product card. Toggle on/off per widget in Elementor > Content > Vendor profile. Three display styles: Name only, Avatar + Name, Avatar + Name + Location. Optional store link. Avatar size slider (16–48px). Requires Dokan Lite or Pro 3.10+; silently hides when Dokan is absent, vendor unresolvable, or vendor suspended. Uses existing Vendor_Resolver and Vendor_Cache — no extra DB queries per card.

= 1.3.5 =
* Performance: All plugin JS (frontend, quickview, slider) now registered with `strategy=>'defer'` on WordPress 6.3+, falling back to in-footer on 6.2. Defers script execution until after HTML parse — safe because all handlers use $(document).on() delegation.
* Performance: Algolia/WP search page CSS is now enqueued in wp_head (priority 15) instead of wp_footer, eliminating flash of unstyled product cards.
* Performance: Swiper fallback now prefers a local bundle (assets/js/swiper-bundle.min.js) over the jsDelivr CDN, removing an external DNS lookup when Elementor Pro's Swiper is unavailable. CDN remains as last-resort if local file absent.
* Compatibility: WordPress version check for defer strategy is runtime-evaluated — no behaviour change on WP 6.2.

= 1.0.0 =
* Initial public release.
* Phase 1: plugin foundation, autoloader, HPOS + Blocks compatibility, asset registration, Elementor widget category.
* Phase 2: grid widget MVP with all 11 card elements, three responsive breakpoints, Astra-isolated CSS namespace.
* Phase 3A: 5 query sources (Dynamic, Featured, Similar, Recently Viewed, Wishlist) plus storage layer.
* Phase 3B: Trending subsystem (Action Scheduler, engagement store, calculator, seeder) and Dokan-aware More From Seller source. Editor-preview diagnostic buttons replace traditional admin pages.
* Phase 4: AJAX layer (router, rate limiter, 5 user-facing handlers), cache-safe wishlist heart hydration, optimistic UI with rollback, toast notifications, Load More pagination.
* Phase 5: Quick View modal with auto-detected colour swatches and Buy Now flow with 15-min cart-stash + abandon-restore state machine.
* Phase 6: ZYMARG Product Slider layout on Swiper 11 with full responsive controls, autoplay, loop, navigation arrows, multiple pagination styles.
* Phase 7: Server-side wishlist heart state on first render (no FOUC on uncached pages).
* Phase 9: a11y hardening (focus trap, ARIA on modal, keyboard navigation, escape-to-close).
* Phase 10: Polish, readme, version locked to 1.0.0.
