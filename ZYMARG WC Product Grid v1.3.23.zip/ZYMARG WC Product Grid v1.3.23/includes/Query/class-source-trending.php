<?php
/**
 * "Trending products" source.
 *
 * @package Zymarg\WCPG
 */

namespace Zymarg\WCPG\Query;

defined( 'ABSPATH' ) || exit;

use Zymarg\WCPG\Trending\Engagement_Store;
use Zymarg\WCPG\Trending\Trending_Calculator;

/**
 * Class Source_Trending
 *
 * Reads the Action-Scheduler-maintained trending cache. When the widget's
 * weights match the calculator's last cached weights, we serve straight
 * from the cache for sub-millisecond reads. When the widget overrides
 * weights, we re-score the same candidate pool in-memory (no DB hits)
 * so editors can experiment without forcing a global recompute.
 */
class Source_Trending extends Source_Base {

	/**
	 * @inheritDoc
	 */
	public function get_products( array $settings ) {
		$top_ids = Trending_Calculator::get_cached_ids();

		if ( empty( $top_ids ) ) {
			Trending_Calculator::recompute();
			$top_ids = Trending_Calculator::get_cached_ids();
		}

		if ( empty( $top_ids ) ) {
			return array();
		}

		if ( $this->weights_overridden( $settings ) ) {
			$top_ids = $this->rescore_with_overrides( $top_ids, $settings );
		}

		$show_oos = isset( $settings['show_oos'] ) && 'yes' === $settings['show_oos'];
		$products = $this->fetch_products_by_ids( $top_ids, $this->get_limit( $settings ) * 4 );

		if ( ! $show_oos ) {
			$products = array_values(
				array_filter(
					$products,
					static function ( $p ) {
						return $p instanceof \WC_Product && $p->is_in_stock();
					}
				)
			);
		}

		$products = $this->apply_shared_filters( $products, $settings );
		return array_slice( $products, 0, $this->get_limit( $settings ) );
	}

	/**
	 * Whether any of the trending weight controls deviate from defaults.
	 *
	 * @param array $settings Widget settings.
	 * @return bool
	 */
	private function weights_overridden( array $settings ) {
		$ws = (int) ( $settings['trending_w_sales'] ?? 50 );
		$we = (int) ( $settings['trending_w_engagement'] ?? 30 );
		$wr = (int) ( $settings['trending_w_recency'] ?? 20 );
		$wd = (int) ( $settings['trending_window'] ?? 7 );

		$meta     = Trending_Calculator::get_meta();
		$cached_w = isset( $meta['weights'] ) ? $meta['weights'] : null;
		$cached_d = isset( $meta['window_days'] ) ? (int) $meta['window_days'] : 7;

		$normalised = Trending_Calculator::resolve_weights(
			array(
				'w_sales'      => $ws,
				'w_engagement' => $we,
				'w_recency'    => $wr,
			)
		);
		if ( ! is_array( $cached_w ) ) {
			return true;
		}
		$diff = abs( $cached_w['sales'] - $normalised['sales'] )
			+ abs( $cached_w['engagement'] - $normalised['engagement'] )
			+ abs( $cached_w['recency'] - $normalised['recency'] )
			+ ( $cached_d !== $wd ? 1 : 0 );

		return $diff > 0.02;
	}

	/**
	 * Re-rank a candidate pool using the widget's overridden weights.
	 *
	 * @param int[] $pool_ids  Candidate product IDs.
	 * @param array $settings  Widget settings.
	 * @return int[]
	 */
	private function rescore_with_overrides( array $pool_ids, array $settings ) {
		$window  = max( 1, (int) ( $settings['trending_window'] ?? 7 ) );
		$weights = Trending_Calculator::resolve_weights(
			array(
				'w_sales'      => (int) ( $settings['trending_w_sales'] ?? 50 ),
				'w_engagement' => (int) ( $settings['trending_w_engagement'] ?? 30 ),
				'w_recency'    => (int) ( $settings['trending_w_recency'] ?? 20 ),
			)
		);

		$totals  = Engagement_Store::get_window_totals( $window );
		$now     = time();
		$max_eng = 1;
		foreach ( $totals as $t ) {
			$max_eng = max( $max_eng, $t['score'] );
		}

		global $wpdb;
		$ids_in = implode( ',', array_map( 'intval', $pool_ids ) );
		$rows   = $wpdb->get_results(
			"SELECT ID, post_date_gmt, post_date FROM {$wpdb->posts}
			 WHERE ID IN ($ids_in) AND post_type = 'product' AND post_status = 'publish'" // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared,WordPress.DB.DirectDatabaseQuery
		);
		$dates = array();
		foreach ( (array) $rows as $row ) {
			$src                     = $row->post_date_gmt && '0000-00-00 00:00:00' !== $row->post_date_gmt ? $row->post_date_gmt : $row->post_date;
			$dates[ (int) $row->ID ] = (int) strtotime( $src );
		}
		$max_age = 1;
		foreach ( $dates as $ts ) {
			$max_age = max( $max_age, max( 1, ( $now - $ts ) / DAY_IN_SECONDS ) );
		}

		$scored = array();
		foreach ( $pool_ids as $pid ) {
			$pid     = (int) $pid;
			$eng     = isset( $totals[ $pid ] ) ? (int) $totals[ $pid ]['score'] : 0;
			$ts      = isset( $dates[ $pid ] ) ? (int) $dates[ $pid ] : 0;
			$age     = $ts > 0 ? max( 1, ( $now - $ts ) / DAY_IN_SECONDS ) : $max_age;
			$recency = 1 - min( 1, $age / $max_age );
			$norm_e  = $eng / $max_eng;

			// Sales: use lifetime total_sales as a stable proxy when re-scoring on demand
			// (avoids re-querying orders just for a knob change).
			$sales = (int) get_post_meta( $pid, 'total_sales', true );

			$score = ( $weights['sales'] * min( 1, $sales / 100 ) )
				+ ( $weights['engagement'] * $norm_e )
				+ ( $weights['recency'] * $recency );

			$scored[ $pid ] = $score;
		}
		arsort( $scored, SORT_NUMERIC );
		return array_keys( $scored );
	}
}
