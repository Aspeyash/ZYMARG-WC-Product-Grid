=== Aspeyash WooCommerce Product Grid ===
Contributors: aspeyash
Tags: woocommerce, elementor, product grid, product slider, dokan, astra, quick view, wishlist
Requires at least: 6.2
Tested up to: 6.6
Requires PHP: 7.4
Stable tag: 1.3.19
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Customisable WooCommerce Product Grid and Product Grid Slider widgets for Elementor. Quick View modal, Buy Now flow, wishlist, trending, similar, vendor, and more.

== Description ==

Two Elementor widgets that render WooCommerce products as a responsive grid or as a Swiper-powered slider, with full Elementor styling controls.

= Features =

* **Two widgets**: Aspeyash Product Grid + Aspeyash Product Slider, both fully customisable in Elementor.
* **Eight product sources**: All products, Dynamic, Featured, Trending, Similar, More From Seller (Dokan), Recently Viewed, Wishlist.
* **Eleven toggleable card elements**: image, discount badge (percent / amount / both), stock badge, wishlist heart, quick view, add-to-cart, title (1-3 line clamp), rating (auto-hides), sold count (auto-hides), bold current price, strikethrough subscript old price.
* **Heading section** above the grid with toggle, alignment, "View All" link.
* **Three responsive breakpoints** with locked icon positioning per spec.
* **Variable product pricing** rule: lowest sale price bold + lowest regular strikethrough, left-aligned.

= Quick View modal =

* Opens on click of the eye icon.
* Auto-detected colour swatches for `color` / `colour` / `pa_color` attribute slugs.
* Other attributes render as rounded dropdowns.
* Add-to-Cart and Buy Now action buttons.
* "View full details" link to the PDP.
* Focus trap, escape-to-close, click-outside-to-close.

= Buy Now flow =

* Snapshots the user's cart, replaces with the chosen product, redirects to checkout.
* On order completion: original cart restored.
* On abandon (15-min token expiry or user navigates away from checkout): cart restored.
* Existing cart never lost.

= Trending engine =

* Action Scheduler-driven engagement pipeline.
* Click / quick-view / wishlist-add / cart-add events buffered + flushed every 5 min.
* Top-200 trending list recomputed every 30 min.
* Cold-start seeding from last 90 days of orders on activation.
* Editor-preview diagnostic buttons (Recompute / Flush / Reset).

= Dokan integration =

* "More From Seller" source with 4-step vendor resolution waterfall.
* Staff module support.
* Per-vendor cache (30 min) with auto-invalidation.
* Hides widget when vendor has no other products.
* Editor-preview diagnostic buttons (Clear cache / Test resolution).

= Wishlist =

* Logged-in: synced via user meta across devices.
* Guest: cookie + WC session, survives session expiry.
* Login merge: guest cookie unioned into user meta on login.
* Cache-safe heart hydration on every page load.

= Recently Viewed =

* Tracks every product page view automatically.
* Logged-in: user meta. Guest: cookie + WC session.

= Security =

* All AJAX endpoints nonce-protected.
* Per-IP rate limiter with daily-rotating salt.
* Configurable per-action limits.
* No raw SQL on user data.
* No custom database tables.
* HPOS + Cart/Checkout Blocks compatibility declared.

= Compatibility =

* WordPress 6.2+, PHP 7.4-8.3.
* WooCommerce 7.0+ (HPOS-ready, Blocks-ready).
* Elementor Free 3.18+ (no Pro required).
* Astra theme (free + Pro detected).
* Dokan Lite + Pro 3.10+.
* Swiper 11 (auto-detects Elementor Pro's handle, else loads from jsdelivr CDN).

== Installation ==

1. Upload the `aspeyash-wc-product-grid` folder to `/wp-content/plugins/`.
2. Activate the plugin through the Plugins screen.
3. Edit any page with Elementor and look for the **Aspeyash WooCommerce** category in the widgets panel.

== Changelog ==

= 1.3.19 =
* Improvement: Vendor avatar is now fully customizable in Elementor. New controls added to the Vendor Profile section: Avatar size expanded from 16–48px to 12–80px range. Avatar side — choose Left (default) or Right of the vendor name. Avatar shape — Circle (default), Rounded square, or Square. Show border toggle with a color picker. All controls are conditional (only visible when avatar display is enabled) and apply instantly in the Elementor editor preview.

= 1.3.18 =
* Improvement: Quick View modal now uses a full 6-tier responsive sizing spec. Large Desktop (1600px+) 960px/90vh; Desktop (1200-1599px) 900px/90vh; Laptop (992-1199px) 820px/90vh — all two-column 50/50. Tablet (768-991px) 92vw/720px max/92vh two-column 45/55 with tighter padding and smaller typography. Large Mobile (600-767px) 95vw/95vh single column with touch-friendly 44px button targets. Small Mobile (<600px) full-screen 100vw/100vh single column with 48px touch targets. Previously the modal was the same size on all devices above 600px.

= 1.3.17 =
* Fix: Quick View button on the Algolia search results page did nothing when clicked. Root cause: the modal overlay shell (`.zymarg-wcpg__qv-overlay`) is only injected into `wp_footer` when `QuickView_Modal::flag_mount()` is called, which previously only happened inside the Elementor widget renderer. On the standalone search results page no widget renders, so the shell was never printed and `quickview.js` had no DOM element to open. Fix: `flag_mount()` is now called inside `enqueue_search_page_assets()` so the modal shell is always present on search pages.

= 1.3.16 =
* Fix (critical): Add to Cart returning "Something went wrong" on all pages. Root cause: WooCommerce 7.0+ with HPOS does not automatically load the cart/session for AJAX requests. WC()->cart existed as an object but had no session, so add_to_cart() silently returned false triggering the error response. Fix: wc_load_cart() is now called at the top of both Handler_Add_To_Cart and Handler_Buy_Now before any cart operations. This correctly initialises WC()->cart, WC()->customer, and WC()->session for the AJAX context. Wishlist and QuickView were unaffected because they never touch WC()->cart.



= 1.3.15 =
* Fix (critical): is_search_page() was only checking ?s= and ?q= query strings. ZYMARG search uses clean URLs (/search/query) with no query string, so the check always returned false — scripts and nonce were never enqueued on the search page. Quickview and ATC AJAX calls failed because ZYMARGWCPG.nonce was never in the page. Fixed by adding a regex check against REQUEST_URI for the /search/ path prefix.
* Fix: Search page JS was enqueued in wp_footer at priority 1 (after wp_localize_script had already output). Moved both CSS and JS enqueue to wp_enqueue_scripts priority 15 so the inline ZYMARGWCPG localize block is correctly output in <head> before the deferred scripts execute. Nonce is now always present for ATC and quickview on the search page.
* Fix: Split enqueue_search_page_styles() and enqueue_search_page_scripts() methods merged into single enqueue_search_page_assets() hooked at wp_enqueue_scripts priority 15.



= 1.3.14 =
* Fix: Quick view button and Add to Cart now work correctly on the search results page. Root cause: quickview.js had an early-exit guard at line 3 (`if (!ns.ajaxUrl) return`) that caused the entire script to bail out on the search page because ZYMARGWCPG is populated asynchronously there — all 12 event handlers never registered so clicks did nothing. Fix: removed the early-exit guard entirely. All handlers use $(document).on() delegation and are registered immediately at script parse time. ajaxUrl and nonce are now read lazily inside each handler via getNs() at click time, by which point ZYMARGWCPG is always fully populated. frontend.js already had the correct lazy getNs() pattern and required no changes.



= 1.3.13 =
* Fix: Vendor profile now enabled on search results page (show_vendor = yes) to match Elementor widget defaults. Search page should mirror homepage exactly — same features, same design, same behaviour.



= 1.3.12 =
* Fix: Search results page now inherits all card features added since v1.3.5. The AJAX handler (class-handler-search-cards.php) had a hardcoded $settings array missing every key introduced in v1.3.6–v1.3.11: quickview_visibility, show_vendor, vendor_position, vendor_display, vendor_link, vendor_avatar_size, price_position, show_rating, show_sold_count, sold_count_format, meta_layout. All keys are now declared with correct search-page defaults. Quick view is set to "all" devices on the search page (visible on mobile, tablet, and desktop). Vendor profile remains off by default (Dokan dependency — enable by changing show_vendor to "yes" in the handler). The Option B POST override escape hatch is preserved so the search page JS can still pass custom settings without a code change.



= 1.3.11 =
* Fix: Quick view CSS audit — two bugs corrected. (1) Conflict guard was a single @media (max-width:1024px) block covering both tablet and mobile together, meaning "mobile only" mode incorrectly moved the wishlist button on tablet too. Guards are now split into separate tablet and mobile @media blocks so each breakpoint is handled independently. (2) Two separate rules for .zymarg-wcpg__icon-btn--quickview with same specificity (position then display:none) were consolidated into a single rule eliminating the specificity race condition.



= 1.3.10 =
* Fix: Added missing "Below price" option to vendor position control. When price is set to "Above rating", vendor renders between the price block and the rating row. When price is set to "Below rating" (default), vendor renders after the entire bottom row (price + ATC). Total vendor position options now: Below title, Above price, Below price, Above rating & sold count, Below rating & sold count.



= 1.3.9 =
* Feature: Vendor profile position control. New "Position" select under Content > Vendor profile with four options: Below title (default), Above price, Above rating & sold count, Below rating & sold count. The card template now uses four named slots — vendor renders in exactly one slot based on the setting. Fully compatible with the price position setting added in v1.3.7.



= 1.3.8 =
* Feature: Quick View CTA visibility control. New "Visible on" select under Content > Quick View CTA with six options: Desktop only (default), Tablet only, Mobile only, Desktop & Tablet, Tablet & Mobile, All devices. Implemented via data-qv-visibility CSS attribute — no JS, no layout reflow. Conflict guard auto-moves wishlist to bottom-right when quickview is also visible on tablet/mobile so both icons never overlap.



= 1.3.7 =
* Feature (Task 1): Price position control added under Content > Price. Choose "Above rating & sold count" to move the price between the vendor row and the rating row, or keep the default "Below rating & sold count" where price sits in the bottom row alongside the ATC button.
* Feature (Task 2): Rating & Sold Count layout control added under Content > Rating & sold count. Three options: Inline (stars | divider | sold count, default), Stacked (stars on first line, sold count on second line), Count first (sold count | divider | stars).



= 1.3.6 =
* Feature: Vendor profile row on product card. Toggle on/off per widget in Elementor > Content > Vendor profile. Three display styles: Name only, Avatar + Name, Avatar + Name + Location. Optional store link. Avatar size slider (16–48px). Requires Dokan Lite or Pro 3.10+; silently hides when Dokan is absent, vendor unresolvable, or vendor suspended. Uses existing Vendor_Resolver and Vendor_Cache — no extra DB queries per card.



= 1.3.5 =
* Performance: All plugin JS (frontend, quickview, slider) now registered with `strategy=>'defer'` on WordPress 6.3+, falling back to in-footer on 6.2. Defers script execution until after HTML parse — safe because all handlers use $(document).on() delegation.
* Performance: Algolia/WP search page CSS is now enqueued in wp_head (priority 15) instead of wp_footer, eliminating flash of unstyled product cards.
* Performance: Swiper fallback now prefers a local bundle (assets/js/swiper-bundle.min.js) over the jsDelivr CDN, removing an external DNS lookup when Elementor Pro's Swiper is unavailable. CDN remains as last-resort if local file absent.
* Compatibility: WordPress version check for defer strategy is runtime-evaluated — no behaviour change on WP 6.2.



= 1.0.0 =
* Initial public release.
* Phase 1: plugin foundation, autoloader, HPOS + Blocks compatibility, asset registration, Elementor widget category.
* Phase 2: grid widget MVP with all 11 card elements, three responsive breakpoints, Astra-isolated CSS namespace.
* Phase 3A: 5 query sources (Dynamic, Featured, Similar, Recently Viewed, Wishlist) plus storage layer.
* Phase 3B: Trending subsystem (Action Scheduler, engagement store, calculator, seeder) and Dokan-aware More From Seller source. Editor-preview diagnostic buttons replace traditional admin pages.
* Phase 4: AJAX layer (router, rate limiter, 5 user-facing handlers), cache-safe wishlist heart hydration, optimistic UI with rollback, toast notifications, Load More pagination.
* Phase 5: Quick View modal with auto-detected colour swatches and Buy Now flow with 15-min cart-stash + abandon-restore state machine.
* Phase 6: Aspeyash Product Slider widget on Swiper 11 with full responsive controls, autoplay, loop, navigation arrows, multiple pagination styles.
* Phase 7: Server-side wishlist heart state on first render (no FOUC on uncached pages).
* Phase 9: a11y hardening (focus trap, ARIA on modal, keyboard navigation, escape-to-close).
* Phase 10: Polish, readme, version locked to 1.0.0.
