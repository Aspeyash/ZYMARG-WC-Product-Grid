<?php
/**
 * Wishlist shortcode.
 *
 * Exposes the current visitor's wishlist as a server-side product grid that
 * works on any page / any theme without Elementor. Designed to be dropped
 * into the My Account → Wishlist tab (or any other page) so users can find
 * their saved items whenever they want.
 *
 *   [zymarg_wcpg_wishlist]                   default
 *   [zymarg_wcpg_wishlist columns="4"]       force a column count (1-6)
 *   [zymarg_wcpg_wishlist empty_message="…"] override the empty-state copy
 *
 * Rendering uses WooCommerce's own `content-product.php` template, so the
 * cards inherit whichever theme is active. Each ID is resolved directly
 * (no WP_Query) — bypasses multilingual / vendor-scope / B2B catalog
 * filters that could otherwise silently drop wishlist items.
 *
 * @package Zymarg\WCPG
 */

namespace Zymarg\WCPG\Shortcodes;

defined( 'ABSPATH' ) || exit;

use Zymarg\WCPG\Wishlist\Wishlist_Store;

/**
 * Class Wishlist_Shortcode
 */
class Wishlist_Shortcode {

	const SHORTCODE = 'zymarg_wcpg_wishlist';

	/**
	 * Register the shortcode.
	 *
	 * @return void
	 */
	public function register() {
		add_shortcode( self::SHORTCODE, array( $this, 'render' ) );
	}

	/**
	 * Render the visitor's wishlist as a product grid.
	 *
	 * @param array|string $atts Optional shortcode attributes.
	 * @return string HTML.
	 */
	public function render( $atts ) {
		$atts = shortcode_atts(
			array(
				'columns'       => '3',
				'empty_message' => '',
			),
			(array) $atts,
			self::SHORTCODE
		);

		// Hard dependencies.
		if ( ! class_exists( 'WooCommerce' ) || ! class_exists( '\Zymarg\WCPG\Wishlist\Wishlist_Store' ) ) {
			return '';
		}

		$ids = Wishlist_Store::get_ids();

		/* ---- Resolve each ID directly (skip WP_Query filters) ---- */
		$valid_ids   = array();
		$valid_posts = array();
		foreach ( $ids as $id ) {
			$product = wc_get_product( (int) $id );
			if ( ! $product ) {
				continue;
			}
			$post = get_post( (int) $id );
			if ( ! $post || 'publish' !== $post->post_status ) {
				continue;
			}
			$valid_ids[]   = (int) $id;
			$valid_posts[] = $post;
		}

		/* ---- Self-heal stale IDs (deleted / unpublished products) ---- */
		if ( is_user_logged_in() && count( $valid_ids ) !== count( $ids ) ) {
			update_user_meta(
				get_current_user_id(),
				Wishlist_Store::USER_META_KEY,
				$valid_ids
			);
		}

		/* ---- Empty state ---- */
		if ( empty( $valid_posts ) ) {
			$msg = '' !== $atts['empty_message']
				? $atts['empty_message']
				: __( 'Your wishlist is empty. Browse products and tap the heart icon to save items.', 'zymarg-wcpg' );

			$shop_url = function_exists( 'wc_get_page_permalink' )
				? wc_get_page_permalink( 'shop' )
				: home_url( '/' );

			return '<div class="zymarg-wcpg-wishlist zymarg-wcpg-wishlist--empty">'
				. '<p>' . esc_html( $msg ) . '</p>'
				. '<a class="button" href="' . esc_url( $shop_url ) . '">'
				. esc_html__( 'Browse products', 'zymarg-wcpg' )
				. '</a>'
				. '</div>';
		}

		/* ---- Grid ---- */
		$columns = max( 1, min( 6, (int) $atts['columns'] ) );

		ob_start();
		echo '<div class="zymarg-wcpg-wishlist zymarg-wcpg-wishlist--cols-' . esc_attr( $columns ) . '">';

		// Preserve the outer global $post (this shortcode often runs inside
		// the My Account page's own loop).
		global $post;
		$saved_post = $post;

		if ( function_exists( 'wc_set_loop_prop' ) ) {
			wc_set_loop_prop( 'columns', $columns );
			wc_set_loop_prop( 'is_shortcode', true );
		}

		woocommerce_product_loop_start();
		foreach ( $valid_posts as $post ) { // phpcs:ignore WordPress.WP.GlobalVariablesOverride
			setup_postdata( $post );
			wc_get_template_part( 'content', 'product' );
		}
		woocommerce_product_loop_end();

		// Restore outer-loop context.
		$post = $saved_post; // phpcs:ignore WordPress.WP.GlobalVariablesOverride
		wp_reset_postdata();

		echo '</div>';
		return ob_get_clean();
	}
}
