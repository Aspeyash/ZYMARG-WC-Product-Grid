<?php
/**
 * Main plugin bootstrap class.
 *
 * @package Zymarg\WCPG
 */

namespace Zymarg\WCPG;

defined( 'ABSPATH' ) || exit;

/**
 * Class Plugin
 *
 * Singleton that wires up all subsystems once dependencies are confirmed.
 */
final class Plugin {

	/**
	 * Singleton instance.
	 *
	 * @var Plugin|null
	 */
	private static $instance = null;

	/**
	 * Compatibility checker.
	 *
	 * @var Compatibility|null
	 */
	private $compatibility = null;

	/**
	 * Whether init() has already run.
	 *
	 * @var bool
	 */
	private $booted = false;

	/**
	 * Get the singleton instance.
	 *
	 * @return Plugin
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * No public construction.
	 */
	private function __construct() {}

	/**
	 * Disallow cloning.
	 */
	public function __clone() {
		_doing_it_wrong( __FUNCTION__, 'Cloning is forbidden.', '0.1.0' );
	}

	/**
	 * Disallow unserialization.
	 */
	public function __wakeup() {
		_doing_it_wrong( __FUNCTION__, 'Unserialization is forbidden.', '0.1.0' );
	}

	/**
	 * Boot the plugin. Safe to call multiple times.
	 */
	public function init() {
		if ( $this->booted ) {
			return;
		}
		$this->booted = true;

		// Load translations as early as possible.
		( new I18n() )->register();

		// Compatibility must be evaluated before we wire up anything else.
		$this->compatibility = new Compatibility();
		$this->compatibility->register();

		if ( ! $this->compatibility->is_environment_ready() ) {
			// Hard requirements missing; admin notices will explain.
			return;
		}

		// Register asset handles (does not enqueue yet).
		( new Assets() )->register();

		// Tracker and wishlist merge run on every page load (front-end only).
		( new Tracking\Recently_Viewed() )->register();
		( new Wishlist\Wishlist_Merge() )->register();

		// Register public shortcodes (e.g. [zymarg_wcpg_wishlist] for dropping
		// the visitor's wishlist into My Account or any other page).
		( new Shortcodes\Wishlist_Shortcode() )->register();

		// Trending subsystem: scheduled jobs.
		( new Trending\Trending_Scheduler() )->register();

		// Recommendations: per-visitor result-cache invalidation hooks
		// (wishlist / cart / order events).
		( new Recommendations\Affinity_Cache() )->register();

		// Vendor cache: invalidation hooks (Dokan-aware).
		( new Vendor\Vendor_Cache() )->register();

		// Admin-only AJAX endpoints used by the Elementor editor preview buttons.
		if ( is_admin() || wp_doing_ajax() ) {
			( new Admin\Editor_Ajax() )->register();
		}

		// User-facing AJAX router (wishlist, ATC, track-click, hydrate, load-more,
		// quick view, buy now).
		( new Ajax\Ajax_Router() )->register();

		// Quick View modal mount + Buy Now state machine.
		( new QuickView\QuickView_Modal() )->register();
		( new QuickView\BuyNow_Handler() )->register();

		// Register Elementor category + widget hooks.
		( new Elementor\ElementorLoader() )->register();

		/**
		 * Fires when the plugin has fully booted with all dependencies satisfied.
		 *
		 * @since 0.1.0
		 */
		do_action( 'zymarg_wcpg_loaded' );
	}

	/**
	 * Get the compatibility service.
	 *
	 * @return Compatibility|null
	 */
	public function compatibility() {
		return $this->compatibility;
	}
}
