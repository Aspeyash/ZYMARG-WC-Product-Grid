/**
 * ZYMARG WC Wishlist Button — live count badge updates.
 *
 * Listens for the `zymarg_wcpg:wishlist:changed` event broadcast by
 * frontend.js whenever a heart toggle resolves successfully, and refreshes
 * every count badge on the page (this widget can be placed multiple times
 * — e.g. in a desktop header and a mobile drawer — and they all stay in
 * sync).
 *
 * Also listens to the `hydrate` AJAX response that runs on every page load
 * (cache-safe initial count for full-page-cached pages).
 *
 * @package Zymarg\WCPG
 * @since   1.5.0
 */
( function ( $ ) {
	'use strict';

	if ( ! window.jQuery ) { return; }

	function applyCount( count ) {
		count = parseInt( count, 10 );
		if ( isNaN( count ) || count < 0 ) { count = 0; }

		var $badges = $( '[data-zymarg-wcpg-wishlist-count]' );
		if ( ! $badges.length ) { return; }

		$badges.each( function () {
			var $badge = $( this );
			var $wrap  = $badge.closest( '.zymarg-wcpg-wlb' );
			var prev   = parseInt( $badge.text(), 10 );
			if ( isNaN( prev ) ) { prev = 0; }

			$badge.text( count );

			if ( $wrap.length ) {
				$wrap.toggleClass( 'zymarg-wcpg-wlb--empty', count === 0 );
				$wrap.attr( 'data-empty', count === 0 ? 1 : 0 );
			}

			// Bump animation only when count actually changed.
			if ( prev !== count ) {
				$badge.removeClass( 'is-bumping' );
				// Force reflow so re-adding the class restarts the animation.
				/* eslint-disable-next-line no-unused-expressions */
				$badge[ 0 ].offsetWidth;
				$badge.addClass( 'is-bumping' );
				window.setTimeout( function () { $badge.removeClass( 'is-bumping' ); }, 400 );
			}
		} );
	}

	// 1. Live updates from heart toggles anywhere on the page.
	$( document ).on( 'zymarg_wcpg:wishlist:changed', function ( e, payload ) {
		if ( ! payload || typeof payload.count === 'undefined' ) { return; }
		applyCount( payload.count );
	} );

	// 2. Cache-safe initial count via the hydrate broadcast (frontend.js
	//    fires this once on DOM ready after the /hydrate request resolves).
	$( document ).on( 'zymarg_wcpg:wishlist:hydrated', function ( e, payload ) {
		if ( ! payload || typeof payload.count === 'undefined' ) { return; }
		applyCount( payload.count );
	} );

}( window.jQuery ) );
