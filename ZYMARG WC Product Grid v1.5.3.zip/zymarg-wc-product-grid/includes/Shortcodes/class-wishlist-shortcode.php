<?php
/**
 * Wishlist shortcode.
 *
 * Renders the current visitor's wishlist as a product grid using THIS
 * plugin's own card template (`grid/product-card.php`) — so the cards
 * look identical to your Product Grid widgets, the homepage, the search
 * results page and the Connection Engine category pages. No more falling
 * back to the theme's default WC card.
 *
 *   [zymarg_wcpg_wishlist]                   default (3 cols)
 *   [zymarg_wcpg_wishlist columns="4"]       force a column count (1-6)
 *   [zymarg_wcpg_wishlist empty_message="…"] override the empty-state copy
 *
 * Filters:
 *   zymarg_wcpg_wishlist_card_settings(array $settings)
 *     — change which card features show (badges, wishlist heart, quickview,
 *     ATC, vendor row, rating, sold count, price position, etc.).
 *
 * Storage handshake is auth-aware via Wishlist_Store — same source of truth
 * as the heart buttons on every card / the Wishlist Button widget header.
 *
 * @package Zymarg\WCPG
 */

namespace Zymarg\WCPG\Shortcodes;

defined( 'ABSPATH' ) || exit;

use Zymarg\WCPG\Assets;
use Zymarg\WCPG\Template_Loader;
use Zymarg\WCPG\Wishlist\Wishlist_Store;
use Zymarg\WCPG\QuickView\QuickView_Modal;

/**
 * Class Wishlist_Shortcode
 */
class Wishlist_Shortcode {

	const SHORTCODE = 'zymarg_wcpg_wishlist';

	/**
	 * Register the shortcode.
	 *
	 * @return void
	 */
	public function register() {
		add_shortcode( self::SHORTCODE, array( $this, 'render' ) );
	}

	/**
	 * Render the visitor's wishlist as a product grid.
	 *
	 * @param array|string $atts Optional shortcode attributes.
	 * @return string HTML.
	 */
	public function render( $atts ) {
		$atts = shortcode_atts(
			array(
				'columns'       => '3',
				'empty_message' => '',
			),
			(array) $atts,
			self::SHORTCODE
		);

		// Hard dependencies.
		if ( ! class_exists( 'WooCommerce' )
			|| ! class_exists( '\Zymarg\WCPG\Wishlist\Wishlist_Store' )
			|| ! class_exists( '\Zymarg\WCPG\Template_Loader' )
		) {
			return '';
		}

		// Make sure the storefront's grid CSS + JS (and quick view + wishlist
		// heart runtime) are present on the page — without this, the cards
		// render with the right structure but no styling / no interactivity.
		$this->enqueue_runtime();

		$ids = Wishlist_Store::get_ids();

		/* ---- Resolve each ID directly (skip WP_Query filters) ---- */
		$valid_ids = array();
		$products  = array();
		foreach ( $ids as $id ) {
			$product = wc_get_product( (int) $id );
			if ( ! $product ) {
				continue;
			}
			$post = get_post( (int) $id );
			if ( ! $post || 'publish' !== $post->post_status ) {
				continue;
			}
			$valid_ids[] = (int) $id;
			$products[]  = $product;
		}

		/* ---- Self-heal stale IDs (deleted / unpublished products) ---- */
		if ( is_user_logged_in() && count( $valid_ids ) !== count( $ids ) ) {
			update_user_meta(
				get_current_user_id(),
				Wishlist_Store::USER_META_KEY,
				$valid_ids
			);
		}

		/* ---- Empty state ---- */
		if ( empty( $products ) ) {
			$msg = '' !== $atts['empty_message']
				? $atts['empty_message']
				: __( 'Nothing saved yet. Tap the heart on anything you love and it\'ll be waiting for you here — across all your devices.', 'zymarg-wcpg' );

			$shop_url = function_exists( 'wc_get_page_permalink' )
				? wc_get_page_permalink( 'shop' )
				: home_url( '/' );

			return '<div class="zymarg-wcpg zymarg-wcpg-wishlist zymarg-wcpg-wishlist--empty">'
				. '<div class="zymarg-wcpg__empty-state">'
				. '<p>' . esc_html( $msg ) . '</p>'
				. '<a class="button zymarg-wcpg__empty-cta" href="' . esc_url( $shop_url ) . '">'
				. esc_html__( 'Browse products', 'zymarg-wcpg' )
				. '</a>'
				. '</div>'
				. '</div>';
		}

		/* ---- Grid ---- */
		$columns  = max( 1, min( 6, (int) $atts['columns'] ) );
		$settings = $this->default_card_settings();

		// data-settings payload so the shared hydrate + load-more runtime can
		// reason about the cards (we only ship the visible knobs — the rest
		// the grid widget exposes don't apply to a static wishlist grid).
		$payload = array(
			'source'              => 'wishlist',
			'columns'             => $columns,
			'show_image'          => $settings['show_image'],
			'show_discount_badge' => $settings['show_discount_badge'],
			'show_stock_badge'    => $settings['show_stock_badge'],
			'show_wishlist'       => $settings['show_wishlist'],
			'show_quickview'      => $settings['show_quickview'],
			'show_atc'            => $settings['show_atc'],
			'show_title'          => $settings['show_title'],
			'show_rating'         => $settings['show_rating'],
			'show_sold_count'     => $settings['show_sold_count'],
			'show_price'          => $settings['show_price'],
		);

		$widget_id = 'zymarg-wcpg-wishlist';

		ob_start();
		?>
		<div class="zymarg-wcpg zymarg-wcpg-wishlist"
			data-widget-id="<?php echo esc_attr( $widget_id ); ?>"
			data-zymarg-hydrate="1"
			data-show-view-cart="1"
			data-settings="<?php echo esc_attr( wp_json_encode( $payload ) ); ?>">
			<div class="zymarg-wcpg__grid zymarg-wcpg__grid--cols-<?php echo (int) $columns; ?>">
				<?php
				foreach ( $products as $product ) {
					Template_Loader::get_template(
						'grid/product-card.php',
						array(
							'product'   => $product,
							'settings'  => $settings,
							'widget_id' => $widget_id,
						)
					);
				}
				?>
			</div>
		</div>
		<?php

		// Make sure the Quick View modal shell is rendered in the footer
		// (otherwise clicking the Quick View icon on a card does nothing).
		if ( class_exists( '\Zymarg\WCPG\QuickView\QuickView_Modal' ) && method_exists( '\Zymarg\WCPG\QuickView\QuickView_Modal', 'flag_mount' ) ) {
			QuickView_Modal::flag_mount();
		}

		return (string) ob_get_clean();
	}

	/**
	 * Default card display settings.
	 *
	 * Same recipe used by the storefront grid widget, the search-results page
	 * (Handler_Search_Cards) and the Connection Engine category pages, so a
	 * wishlist card looks identical to a homepage / search / category card.
	 *
	 * Filterable via `zymarg_wcpg_wishlist_card_settings`.
	 *
	 * @return array
	 */
	private function default_card_settings() {
		$settings = array(
			// Image.
			'show_image'            => 'yes',
			'image_hover_zoom'      => 'yes',
			'image_full_resolution' => 'no',

			// Badges.
			'show_discount_badge'   => 'yes',
			'show_stock_badge'      => 'yes',

			// Wishlist heart (lets the customer remove items from the grid
			// without leaving the page).
			'show_wishlist'         => 'yes',
			'wishlist_icon'         => null,
			'wishlist_icon_active'  => null,

			// Quick View.
			'show_quickview'        => 'yes',
			'quickview_visibility'  => 'all',
			'quickview_icon'        => null,

			// Add to Cart.
			'show_atc'              => 'yes',
			'atc_icon'              => null,

			// Title.
			'show_title'            => 'yes',

			// Vendor profile.
			'show_vendor'           => 'yes',
			'vendor_position'       => 'below_title',
			'vendor_display'        => 'avatar_name',
			'vendor_link'           => 'yes',
			'vendor_avatar_size'    => array(
				'size' => 24,
				'unit' => 'px',
			),
			'vendor_avatar_side'    => 'left',
			'vendor_avatar_shape'   => 'circle',
			'vendor_avatar_border'  => '',

			// Price.
			'show_price'            => 'yes',
			'price_position'        => 'below_rating',

			// Rating & sold count.
			'show_rating'           => 'yes',
			'show_sold_count'       => 'yes',
			'sold_count_format'     => 'sold_n',
			'meta_layout'           => 'inline',
		);

		/**
		 * Filter the wishlist card display settings.
		 *
		 * @since 1.5.1
		 *
		 * @param array $settings Settings passed to `grid/product-card.php`.
		 */
		return (array) apply_filters( 'zymarg_wcpg_wishlist_card_settings', $settings );
	}

	/**
	 * Ensure the storefront card runtime is loaded on whichever page the
	 * shortcode is rendered on (My Account → Wishlist, a standalone page,
	 * a popup — anywhere). Idempotent: WP merges duplicate enqueues.
	 *
	 * @return void
	 */
	private function enqueue_runtime() {
		if ( ! class_exists( '\Zymarg\WCPG\Assets' ) ) {
			return;
		}
		// Styles.
		wp_enqueue_style( Assets::HANDLE_FRONTEND );
		wp_enqueue_style( Assets::HANDLE_QUICKVIEW );
		// Scripts (frontend.js handles wishlist hydration / heart toggle /
		// add-to-cart; quickview.js handles the modal). Both registered as
		// deferred — safe to enqueue late.
		wp_enqueue_script( Assets::HANDLE_FRONTEND );
		wp_enqueue_script( Assets::HANDLE_QUICKVIEW );
	}
}
