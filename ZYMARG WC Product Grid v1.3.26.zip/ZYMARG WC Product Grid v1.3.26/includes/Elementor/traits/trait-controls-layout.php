<?php
/**
 * Layout tab controls (Tab 1).
 *
 * @package Zymarg\WCPG
 */

namespace Zymarg\WCPG\Elementor\Traits;

defined( 'ABSPATH' ) || exit;

/**
 * Trait Controls_Layout
 *
 * Registers the Layout section in the Content tab. The Heading section is
 * provided by Controls_Heading and is registered before this section in the
 * widget's register_controls() to honour the locked control order.
 */
trait Controls_Layout {

	/**
	 * Register the Layout section.
	 */
	protected function register_layout_section() {
		$this->start_controls_section(
			'section_layout',
			array(
				'label' => __( 'Layout', 'zymarg-wcpg' ),
			)
		);

		$this->add_control(
			'layout_type',
			array(
				'label'       => __( 'Layout type', 'zymarg-wcpg' ),
				'type'        => \Elementor\Controls_Manager::SELECT,
				'default'     => 'grid',
				'options'     => array(
					'grid'   => __( 'Grid', 'zymarg-wcpg' ),
					'slider' => __( 'Slider (Swiper carousel)', 'zymarg-wcpg' ),
				),
				'description' => __( 'Choose how products are displayed. Slider mode reveals additional controls (autoplay, arrows, pagination, etc.).', 'zymarg-wcpg' ),
			)
		);

		$this->add_responsive_control(
			'columns',
			array(
				'label'          => __( 'Columns', 'zymarg-wcpg' ),
				'type'           => \Elementor\Controls_Manager::SELECT,
				'default'        => '4',
				'tablet_default' => '3',
				'mobile_default' => '2',
				'options'        => array(
					'1' => '1',
					'2' => '2',
					'3' => '3',
					'4' => '4',
					'5' => '5',
					'6' => '6',
				),
				'selectors'      => array(
					'{{WRAPPER}} .zymarg-wcpg__grid' => 'grid-template-columns: repeat({{VALUE}}, minmax(0, 1fr));',
				),
			)
		);

		$this->add_control(
			'total_products',
			array(
				'label'       => __( 'Total products', 'zymarg-wcpg' ),
				'type'        => \Elementor\Controls_Manager::NUMBER,
				'default'     => 8,
				'min'         => 0,
				'max'         => 100,
				'step'        => 1,
				'description' => __( 'Number of products to show. Set to 0 for no limit (subject to a 500-product safety ceiling).', 'zymarg-wcpg' ),
			)
		);

		$this->add_control(
			'large_grid_notice',
			array(
				'type'      => \Elementor\Controls_Manager::RAW_HTML,
				'raw'       => '<div class="elementor-panel-alert elementor-panel-alert-info">'
					. esc_html__( 'Tip: For grids over 30 products, keep "Use full resolution" off in the Image settings for better performance.', 'zymarg-wcpg' )
					. '</div>',
				'condition' => array( 'total_products' => array( 31, 100 ) ),
			)
		);

		$this->add_control(
			'source',
			array(
				'label'   => __( 'Source', 'zymarg-wcpg' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => 'all',
				'options' => array(
					'all'      => __( 'All products', 'zymarg-wcpg' ),
					'dynamic'  => __( 'Dynamic products', 'zymarg-wcpg' ),
					'featured' => __( 'Featured products', 'zymarg-wcpg' ),
					'trending' => __( 'Trending products', 'zymarg-wcpg' ),
					'similar'  => __( 'Similar products', 'zymarg-wcpg' ),
					'vendor'   => __( 'More From Seller (Dokan)', 'zymarg-wcpg' ),
					'recent'   => __( 'Recently viewed', 'zymarg-wcpg' ),
					'wishlist' => __( 'Wishlist', 'zymarg-wcpg' ),
					'algolia'  => __( 'Algolia Search Results (search pages only)', 'zymarg-wcpg' ),
					'category' => __( 'Category Page (auto-detected)', 'zymarg-wcpg' ),
				),
			)
		);

		$this->add_control(
			'orderby',
			array(
				'label'   => __( 'Order by', 'zymarg-wcpg' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => 'date',
				'options' => array(
					'date'       => __( 'Date', 'zymarg-wcpg' ),
					'title'      => __( 'Title', 'zymarg-wcpg' ),
					'price'      => __( 'Price', 'zymarg-wcpg' ),
					'popularity' => __( 'Popularity (sales)', 'zymarg-wcpg' ),
					'rating'     => __( 'Rating', 'zymarg-wcpg' ),
					'rand'       => __( 'Random', 'zymarg-wcpg' ),
					'menu_order' => __( 'Menu order', 'zymarg-wcpg' ),
				),
			)
		);

		$this->add_control(
			'order',
			array(
				'label'     => __( 'Order', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::SELECT,
				'default'   => 'DESC',
				'options'   => array(
					'ASC'  => __( 'Ascending', 'zymarg-wcpg' ),
					'DESC' => __( 'Descending', 'zymarg-wcpg' ),
				),
				'condition' => array(
					'orderby!' => array( 'rand', 'menu_order' ),
				),
			)
		);

		$this->add_control(
			'show_oos',
			array(
				'label'        => __( 'Show out-of-stock products', 'zymarg-wcpg' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default'      => '',
			)
		);

		$this->add_control(
			'include_products',
			array(
				'label'       => __( 'Include product IDs', 'zymarg-wcpg' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'placeholder' => '12, 34, 56',
				'description' => __( 'Comma-separated product IDs. The async picker ships in Phase 4.', 'zymarg-wcpg' ),
			)
		);

		$this->add_control(
			'exclude_products',
			array(
				'label'       => __( 'Exclude product IDs', 'zymarg-wcpg' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'placeholder' => '12, 34, 56',
				'description' => __( 'Comma-separated product IDs.', 'zymarg-wcpg' ),
			)
		);

		$this->add_control(
			'include_categories',
			array(
				'label'       => __( 'Include categories', 'zymarg-wcpg' ),
				'type'        => \Elementor\Controls_Manager::SELECT2,
				'multiple'    => true,
				'options'     => self::get_category_options(),
				'label_block' => true,
			)
		);

		$this->add_control(
			'exclude_categories',
			array(
				'label'       => __( 'Exclude categories', 'zymarg-wcpg' ),
				'type'        => \Elementor\Controls_Manager::SELECT2,
				'multiple'    => true,
				'options'     => self::get_category_options(),
				'label_block' => true,
			)
		);

		$this->add_control(
			'pagination_mode',
			array(
				'label'   => __( 'Pagination', 'zymarg-wcpg' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => 'none',
				'options' => array(
					'none'      => __( 'None', 'zymarg-wcpg' ),
					'load_more' => __( 'Load more button', 'zymarg-wcpg' ),
				),
				'description' => __( 'Numbered pagination ships in Phase 9 polish.', 'zymarg-wcpg' ),
			)
		);

		$this->add_control(
			'load_more_text',
			array(
				'label'     => __( 'Load more button text', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::TEXT,
				'default'   => __( 'Load more', 'zymarg-wcpg' ),
				'condition' => array( 'pagination_mode' => 'load_more' ),
			)
		);

		$this->add_control(
			'empty_message',
			array(
				'label'   => __( 'Empty state message', 'zymarg-wcpg' ),
				'type'    => \Elementor\Controls_Manager::TEXTAREA,
				'default' => __( 'No products found.', 'zymarg-wcpg' ),
				'rows'    => 2,
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Fetch product category options for the SELECT2 controls.
	 *
	 * Capped at 200 terms to avoid bloating the editor UI on large catalogs.
	 * If a store has more than 200 categories, the remainder are still
	 * available via include/exclude category IDs in Phase 4 controls.
	 *
	 * @return array<int,string>
	 */
	private static function get_category_options() {
		$options = array();

		if ( ! taxonomy_exists( 'product_cat' ) ) {
			return $options;
		}

		$terms = get_terms(
			array(
				'taxonomy'   => 'product_cat',
				'hide_empty' => false,
				'number'     => 200,
				'orderby'    => 'name',
			)
		);

		if ( is_array( $terms ) ) {
			foreach ( $terms as $term ) {
				$options[ (int) $term->term_id ] = $term->name;
			}
		}

		return $options;
	}
}
