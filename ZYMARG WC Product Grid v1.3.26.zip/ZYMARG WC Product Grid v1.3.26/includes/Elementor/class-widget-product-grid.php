<?php
/**
 * ZYMARG WC Product Grid Elementor widget.
 *
 * Single widget that supports both Grid and Slider layouts via the
 * `layout_type` control on the Layout tab. Slider-specific controls
 * (autoplay, arrows, pagination, etc.) appear only when the slider
 * layout is selected, courtesy of Elementor's `condition` mechanic.
 *
 * @package Zymarg\WCPG
 */

namespace Zymarg\WCPG\Elementor;

defined( 'ABSPATH' ) || exit;

use Zymarg\WCPG\Assets;
use Zymarg\WCPG\Elementor\Traits\Controls_Heading;
use Zymarg\WCPG\Elementor\Traits\Controls_Layout;
use Zymarg\WCPG\Elementor\Traits\Controls_Settings;
use Zymarg\WCPG\Elementor\Traits\Controls_Slider;
use Zymarg\WCPG\Elementor\Traits\Controls_Source;
use Zymarg\WCPG\Elementor\Traits\Controls_Style;
use Zymarg\WCPG\Elementor\Traits\Editor_Diagnostics;
use Zymarg\WCPG\Query\Query_Builder;
use Zymarg\WCPG\Query\Source_Base;
use Zymarg\WCPG\Template_Loader;

/**
 * Class Widget_Product_Grid
 */
class Widget_Product_Grid extends \Elementor\Widget_Base {

	use Controls_Heading;
	use Controls_Layout;
	use Controls_Settings;
	use Controls_Slider;
	use Controls_Source;
	use Controls_Style;
	use Editor_Diagnostics;

	/**
	 * Widget machine name.
	 */
	public function get_name() {
		return 'zymarg_product_grid';
	}

	/**
	 * Widget display name.
	 */
	public function get_title() {
		return __( 'ZYMARG WC Product Grid', 'zymarg-wcpg' );
	}

	/**
	 * Panel icon.
	 */
	public function get_icon() {
		return 'eicon-products';
	}

	/**
	 * Categories.
	 */
	public function get_categories() {
		return array( ElementorLoader::CATEGORY_SLUG );
	}

	/**
	 * Search keywords.
	 */
	public function get_keywords() {
		return array( 'woocommerce', 'product', 'products', 'grid', 'slider', 'carousel', 'shop', 'zymarg' );
	}

	/**
	 * Style handles. Returned unconditionally to avoid edge cases when
	 * Elementor probes deps outside a render context. Slider CSS is
	 * additionally enqueued at render time when slider layout is active.
	 */
	public function get_style_depends() {
		return array( Assets::HANDLE_FRONTEND, Assets::HANDLE_QUICKVIEW );
	}

	/**
	 * Script handles. Same defensive contract as get_style_depends().
	 */
	public function get_script_depends() {
		if ( class_exists( '\Zymarg\WCPG\QuickView\QuickView_Modal' ) ) {
			\Zymarg\WCPG\QuickView\QuickView_Modal::flag_mount();
		}
		return array( Assets::HANDLE_FRONTEND, Assets::HANDLE_QUICKVIEW );
	}

	/**
	 * Register widget controls.
	 *
	 * Order in the panel:
	 *   Content tab : Heading -> Layout -> Slider* -> Source* -> Settings
	 *   Style   tab : Heading -> Card -> Image -> Badges -> Icons ->
	 *                 Title -> Rating -> Price -> ATC -> Empty -> Slider*
	 *
	 *   * Conditional sections shown only for relevant layout/source.
	 */
	protected function register_controls() {
		$this->register_heading_layout_section();
		$this->register_layout_section();
		$this->register_slider_section();
		$this->register_source_sections();
		$this->register_settings_sections();

		$this->register_heading_style_section();
		$this->register_style_sections();
		$this->register_slider_style_section();
	}

	/**
	 * Render the widget on the front end (and inside Elementor's editor preview).
	 */
	protected function render() {
		// Hard guard: WooCommerce must be available.
		if ( ! function_exists( 'wc_get_product' ) ) {
			if ( $this->is_editor_mode() ) {
				echo '<div class="zymarg-wcpg__editor-notice">' . esc_html__( 'WooCommerce is not active. The widget will not render on the front end.', 'zymarg-wcpg' ) . '</div>';
			}
			return;
		}

		$settings = $this->get_settings_for_display();
		$source   = isset( $settings['source'] ) ? (string) $settings['source'] : 'all';
		$layout   = isset( $settings['layout_type'] ) && 'slider' === $settings['layout_type'] ? 'slider' : 'grid';

		// Editor-preview diagnostics for sources with their own subsystems.
		if ( $this->is_editor_mode() && current_user_can( 'manage_options' ) ) {
			if ( 'trending' === $source ) {
				$this->render_trending_diagnostics( $settings );
			} elseif ( 'vendor' === $source ) {
				$this->render_vendor_diagnostics( $settings );
			}
		}

		// Similar source needs a current product to make sense.
		if ( $this->is_editor_mode() && 'similar' === $source ) {
			$auto = ! isset( $settings['similar_auto_detect'] ) || 'yes' === $settings['similar_auto_detect'];
			$pid  = $auto ? ( get_queried_object_id() ?: 0 ) : (int) ( $settings['similar_product_id'] ?? 0 );
			if ( ! $pid ) {
				echo '<div class="zymarg-wcpg__editor-notice">';
				esc_html_e( 'Similar products needs a single-product page (or a manual product ID). The widget will be empty until placed on a product page.', 'zymarg-wcpg' );
				echo '</div>';
			}
		}

		$result = Query_Builder::get_products( $settings );

		// HIDE_WIDGET sentinel: emit no markup at all on the front end (per
		// locked spec for Similar / More From Seller when no matches).
		if ( Source_Base::HIDE_WIDGET === $result ) {
			if ( $this->is_editor_mode() ) {
				echo '<div class="zymarg-wcpg__editor-notice">';
				esc_html_e( 'No matching products. This widget is hidden on the front end (per locked spec for Similar / More From Seller).', 'zymarg-wcpg' );
				echo '</div>';
			} else {
				echo '<!-- zymarg-wcpg: widget suppressed (no matching products) -->';
			}
			return;
		}

		// Slider mode: enqueue Swiper-dependent assets and render the slider
		// template. Grid mode: render the grid template. The same product
		// card template is used inside both wrappers, so styling controls
		// apply identically.
		if ( 'slider' === $layout ) {
			wp_enqueue_style( Assets::HANDLE_SLIDER );
			wp_enqueue_script( Assets::HANDLE_SLIDER );
			$template = 'slider/slider-wrapper.php';
		} else {
			$template = 'grid/grid-wrapper.php';
		}

		Template_Loader::get_template(
			$template,
			array(
				'widget_id' => $this->get_id(),
				'settings'  => $settings,
				'products'  => $result,
			)
		);
	}

	/**
	 * Whether we are currently rendering inside Elementor's editor.
	 *
	 * @return bool
	 */
	private function is_editor_mode() {
		return class_exists( '\Elementor\Plugin' )
			&& isset( \Elementor\Plugin::$instance )
			&& \Elementor\Plugin::$instance->editor
			&& \Elementor\Plugin::$instance->editor->is_edit_mode();
	}
}
