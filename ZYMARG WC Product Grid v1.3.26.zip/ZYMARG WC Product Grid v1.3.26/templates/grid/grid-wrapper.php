<?php
/**
 * Grid wrapper template.
 *
 * Theme override: copy to theme/zymarg-wcpg/grid/grid-wrapper.php
 *
 * @package Zymarg\WCPG
 *
 * @var array  $settings  Sanitized widget settings.
 * @var int    $widget_id Elementor widget ID.
 * @var array  $products  Array of WC_Product objects (may be empty).
 */

defined( 'ABSPATH' ) || exit;

$show_heading = isset( $settings['show_heading'] ) && 'yes' === $settings['show_heading'];

// Heading values are only used when show_heading is on.
$heading_text   = isset( $settings['heading_text'] ) ? (string) $settings['heading_text'] : '';
$subheading     = isset( $settings['subheading_text'] ) ? (string) $settings['subheading_text'] : '';
$allowed_tags   = array( 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'div', 'span' );
$heading_tag    = isset( $settings['heading_tag'] ) && in_array( $settings['heading_tag'], $allowed_tags, true ) ? $settings['heading_tag'] : 'h2';
$show_view_all  = isset( $settings['show_view_all'] ) && 'yes' === $settings['show_view_all'];
$view_all_text  = isset( $settings['view_all_text'] ) ? (string) $settings['view_all_text'] : __( 'View All', 'zymarg-wcpg' );
$view_all_url   = isset( $settings['view_all_url']['url'] ) ? (string) $settings['view_all_url']['url'] : '';
$view_all_blank = ! empty( $settings['view_all_url']['is_external'] );
$view_all_nf    = ! empty( $settings['view_all_url']['nofollow'] );

$columns       = isset( $settings['columns'] ) ? max( 1, min( 6, (int) $settings['columns'] ) ) : 4;
$empty_message = isset( $settings['empty_message'] ) ? (string) $settings['empty_message'] : __( 'No products found.', 'zymarg-wcpg' );

$pagination_mode = isset( $settings['pagination_mode'] ) ? (string) $settings['pagination_mode'] : 'none';
$load_more_text  = isset( $settings['load_more_text'] ) ? (string) $settings['load_more_text'] : __( 'Load more', 'zymarg-wcpg' );

// Settings payload echoed into a data-attr so the Load More AJAX request
// can replay the same query shape. Source-internal knobs are never echoed.
$payload_keys = array(
	'source',
	'total_products',
	'orderby',
	'order',
	'show_oos',
	'columns',
	'show_image',
	'show_discount_badge',
	'show_stock_badge',
	'show_wishlist',
	'show_quickview',
	'show_atc',
	'show_title',
	'show_rating',
	'show_sold_count',
	'show_price',
	'discount_badge_mode',
	'image_full_resolution',
	'image_hover_zoom',
	'show_stock_in',
	'show_stock_out',
	'title_lines',
	'sold_count_format',
);
$payload = array();
foreach ( $payload_keys as $k ) {
	if ( isset( $settings[ $k ] ) ) {
		$payload[ $k ] = is_scalar( $settings[ $k ] ) ? (string) $settings[ $k ] : $settings[ $k ];
	}
}
?>
<div class="zymarg-wcpg"
	data-widget-id="<?php echo esc_attr( $widget_id ); ?>"
	data-zymarg-hydrate="1"
	data-show-view-cart="<?php echo ( ! isset( $settings['show_view_cart_link'] ) || 'yes' === $settings['show_view_cart_link'] ) ? '1' : '0'; ?>"
	data-settings="<?php echo esc_attr( wp_json_encode( $payload ) ); ?>">

	<?php if ( $show_heading && ( '' !== $heading_text || '' !== $subheading || ( $show_view_all && $view_all_url ) ) ) : ?>
		<div class="zymarg-wcpg__heading">
			<div class="zymarg-wcpg__heading-main">
				<?php if ( '' !== $heading_text ) : ?>
					<<?php echo esc_html( $heading_tag ); ?> class="zymarg-wcpg__heading-title">
						<?php echo esc_html( $heading_text ); ?>
					</<?php echo esc_html( $heading_tag ); ?>>
				<?php endif; ?>

				<?php if ( '' !== $subheading ) : ?>
					<div class="zymarg-wcpg__heading-subtitle">
						<?php echo esc_html( $subheading ); ?>
					</div>
				<?php endif; ?>
			</div>

			<?php if ( $show_view_all && '' !== $view_all_url ) : ?>
				<a class="zymarg-wcpg__heading-link"
					href="<?php echo esc_url( $view_all_url ); ?>"
					<?php echo $view_all_blank ? 'target="_blank"' : ''; ?>
					<?php echo $view_all_nf ? 'rel="nofollow noopener"' : ( $view_all_blank ? 'rel="noopener"' : '' ); ?>>
					<?php echo esc_html( $view_all_text ); ?>
				</a>
			<?php endif; ?>
		</div>
	<?php endif; ?>

	<?php if ( empty( $products ) ) : ?>
		<?php
		\Zymarg\WCPG\Template_Loader::get_template(
			'parts/empty-state.php',
			array( 'message' => $empty_message )
		);
		?>
	<?php else : ?>
		<div class="zymarg-wcpg__grid zymarg-wcpg__grid--cols-<?php echo (int) $columns; ?>">
			<?php
			foreach ( $products as $product ) {
				if ( ! $product instanceof \WC_Product ) {
					continue;
				}
				\Zymarg\WCPG\Template_Loader::get_template(
					'grid/product-card.php',
					array(
						'product'   => $product,
						'settings'  => $settings,
						'widget_id' => $widget_id,
					)
				);
			}
			?>
		</div>

		<?php
		$total_setting = isset( $settings['total_products'] ) ? (int) $settings['total_products'] : 8;
		$is_unlimited  = $total_setting <= 0;
		// Load More is irrelevant when unlimited (we already showed everything),
		// and only shown when the page filled to the requested per-page count.
		// For Algolia source use nb_hits from the filter for accurate detection.
		$algolia_nb_hits = 'algolia' === ( $settings['source'] ?? '' )
			? (int) apply_filters( 'zymarg_wcpg_algolia_nb_hits', 0 )
			: 0;
		$show_load_more = 'load_more' === $pagination_mode
			&& ! $is_unlimited
			&& (
				( $algolia_nb_hits > 0 && $algolia_nb_hits > count( $products ) )
				|| ( 0 === $algolia_nb_hits && count( $products ) >= max( 1, $total_setting ) )
			);

		// For category source: read term ID from filter for load-more button.
		$category_term_id = 'category' === ( $settings['source'] ?? '' )
			? (int) apply_filters( 'zymarg_wcpg_category_term_id', 0 )
			: 0;
		?>
		<?php if ( $show_load_more ) : ?>
			<div class="zymarg-wcpg__pagination">
				<button type="button"
					class="zymarg-wcpg__load-more"
					data-page="2"
					data-action="zymarg-load-more"
					<?php if ( 'algolia' === ( $settings['source'] ?? '' ) ) : ?>
						data-algolia-query="<?php echo esc_attr( get_search_query() ); ?>"
					<?php endif; ?>
					<?php if ( $category_term_id > 0 ) : ?>
						data-category-term-id="<?php echo esc_attr( $category_term_id ); ?>"
					<?php endif; ?>>
					<span class="zymarg-wcpg__load-more-text"><?php echo esc_html( $load_more_text ); ?></span>
					<span class="zymarg-wcpg__load-more-spinner" aria-hidden="true"></span>
				</button>
			</div>
		<?php endif; ?>
	<?php endif; ?>

</div>
