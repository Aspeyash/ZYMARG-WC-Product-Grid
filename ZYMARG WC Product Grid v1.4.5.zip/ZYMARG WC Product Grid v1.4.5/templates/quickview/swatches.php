<?php
/**
 * Quick View attribute swatches.
 *
 * v1.4.4: unified to text-only pill buttons for every attribute type.
 * The original auto-detection (color / image / label / button / select)
 * is preserved in the data layer (Quick_View_Data), but the template
 * now renders all types as the same button pill - matching the user's
 * single-product-page "Woo Swatches" visual style.
 *
 *   color / image / label / button / select  ->  text-only pill button
 *
 * Attribute name labels (like "Color:") are NOT rendered visually -
 * they are exposed to assistive tech via `aria-label` on the wrapping
 * group, same as in earlier versions.
 *
 * The `data-attr-type` attribute is still emitted on the wrapper for
 * any custom JS/CSS that wants to differentiate behaviour by type.
 *
 * @package Zymarg\WCPG
 *
 * @var array $attributes
 */

defined( 'ABSPATH' ) || exit;

if ( empty( $attributes ) || ! is_array( $attributes ) ) {
	return;
}
?>
<?php foreach ( $attributes as $attr ) : ?>
	<div class="zymarg-wcpg__qv-attr zymarg-wcpg__qv-attr--pill"
		role="group"
		aria-label="<?php echo esc_attr( $attr['label'] ); ?>"
		data-attribute-name="<?php echo esc_attr( $attr['name'] ); ?>"
		data-slug="<?php echo esc_attr( $attr['slug'] ); ?>"
		data-attr-type="<?php echo esc_attr( $attr['type'] ); ?>">

		<div class="zymarg-wcpg__qv-swatches"
			role="listbox"
			aria-label="<?php echo esc_attr( $attr['label'] ); ?>">
			<?php foreach ( $attr['values'] as $value ) : ?>
				<button type="button"
					class="zymarg-wcpg__qv-swatch zymarg-wcpg__qv-swatch--pill"
					role="option"
					aria-selected="false"
					data-value="<?php echo esc_attr( $value['value'] ); ?>"
					data-label="<?php echo esc_attr( $value['label'] ); ?>">
					<span class="zymarg-wcpg__qv-swatch-name"><?php echo esc_html( $value['label'] ); ?></span>
				</button>
			<?php endforeach; ?>
		</div>
	</div>
<?php endforeach; ?>
