<?php
/**
 * Plugin Name:       ZYMARG WC Product Grid
 * Plugin URI:        https://zymarg.com
 * Description:       Customisable WooCommerce Product Grid and Product Grid Slider widgets for Elementor. Compatible with Astra and Dokan.
 * Version:           1.4.5
 * Requires at least: 6.2
 * Requires PHP:      7.4
 * Author:            ZYMARG
 * Author URI:        https://zymarg.com
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       zymarg-wcpg
 * Domain Path:       /languages
 *
 * Requires Plugins:  woocommerce, elementor
 *
 * @package Zymarg\WCPG
 */

defined( 'ABSPATH' ) || exit;

/* -------------------------------------------------------------------------
 * Constants
 * ------------------------------------------------------------------------- */

define( 'ZYMARG_WCPG_VERSION', '1.4.5' );
define( 'ZYMARG_WCPG_FILE', __FILE__ );
define( 'ZYMARG_WCPG_DIR', plugin_dir_path( __FILE__ ) );
define( 'ZYMARG_WCPG_URL', plugin_dir_url( __FILE__ ) );
define( 'ZYMARG_WCPG_BASENAME', plugin_basename( __FILE__ ) );
define( 'ZYMARG_WCPG_MIN_PHP', '7.4' );
define( 'ZYMARG_WCPG_MIN_WP', '6.2' );
define( 'ZYMARG_WCPG_MIN_WC', '7.0' );
define( 'ZYMARG_WCPG_MIN_ELEMENTOR', '3.18.0' );

/* -------------------------------------------------------------------------
 * Autoloader
 *
 * Prefer Composer autoload if vendor/ exists, otherwise fall back to a
 * lightweight PSR-4 SPL autoloader for the ZYMARG\WCPG namespace.
 * ------------------------------------------------------------------------- */

if ( file_exists( ZYMARG_WCPG_DIR . 'vendor/autoload.php' ) ) {
	require_once ZYMARG_WCPG_DIR . 'vendor/autoload.php';
} else {
	spl_autoload_register(
		static function ( $class ) {
			$prefix = 'Zymarg\\WCPG\\';
			if ( strncmp( $class, $prefix, strlen( $prefix ) ) !== 0 ) {
				return;
			}

			$relative = substr( $class, strlen( $prefix ) );
			$relative = str_replace( '\\', DIRECTORY_SEPARATOR, $relative );

			// Convert class name to WP-style file name:
			//   Snake_Case  -> snake-case
			//   StudlyCaps  -> studly-caps
			//   Mixed_Words -> mixed-words
			$parts     = explode( DIRECTORY_SEPARATOR, $relative );
			$file_name = array_pop( $parts );

			// 1. Replace underscores with dashes (Snake_Case -> Snake-Case).
			$file_name = str_replace( '_', '-', $file_name );
			// 2. Insert dash before each capital letter not at start and not already preceded by a dash.
			$file_name = preg_replace( '/(?<!^)(?<!-)([A-Z])/', '-$1', $file_name );
			// 3. Lowercase and prefix with class-.
			$file_name = 'class-' . strtolower( $file_name ) . '.php';

			$path = ZYMARG_WCPG_DIR . 'includes/' . ( $parts ? implode( DIRECTORY_SEPARATOR, $parts ) . DIRECTORY_SEPARATOR : '' ) . $file_name;

			if ( is_readable( $path ) ) {
				require_once $path;
			}
		}
	);
}

/* -------------------------------------------------------------------------
 * Environment guards (run before bootstrap)
 * ------------------------------------------------------------------------- */

/**
 * Render an admin notice. Used for environment errors.
 *
 * @param string $message Already-translated message.
 */
function zymarg_wcpg_admin_notice( $message ) {
	add_action(
		'admin_notices',
		static function () use ( $message ) {
			printf( '<div class="notice notice-error"><p><strong>ZYMARG WC Product Grid:</strong> %s</p></div>', wp_kses_post( $message ) );
		}
	);
}

// PHP version guard.
if ( version_compare( PHP_VERSION, ZYMARG_WCPG_MIN_PHP, '<' ) ) {
	zymarg_wcpg_admin_notice(
		sprintf(
			/* translators: 1: required PHP version, 2: current PHP version */
			esc_html__( 'requires PHP %1$s or higher. You are running %2$s.', 'zymarg-wcpg' ),
			ZYMARG_WCPG_MIN_PHP,
			PHP_VERSION
		)
	);
	return;
}

// WordPress version guard.
global $wp_version;
if ( version_compare( $wp_version, ZYMARG_WCPG_MIN_WP, '<' ) ) {
	zymarg_wcpg_admin_notice(
		sprintf(
			/* translators: 1: required WP version, 2: current WP version */
			esc_html__( 'requires WordPress %1$s or higher. You are running %2$s.', 'zymarg-wcpg' ),
			ZYMARG_WCPG_MIN_WP,
			$wp_version
		)
	);
	return;
}

/* -------------------------------------------------------------------------
 * Activation / Deactivation
 * ------------------------------------------------------------------------- */

register_activation_hook(
	__FILE__,
	static function () {
		// Store version for future migrations.
		update_option( 'zymarg_wcpg_version', ZYMARG_WCPG_VERSION, false );

		// Seed default settings if missing.
		if ( false === get_option( 'zymarg_wcpg_settings' ) ) {
			add_option(
				'zymarg_wcpg_settings',
				array(
					'rate_limit_window'   => 60,
					'rate_limit_wishlist' => 30,
					'rate_limit_atc'      => 20,
					'rate_limit_quick'    => 60,
					'rate_limit_buynow'   => 10,
					'rate_limit_track'    => 120,
				),
				'',
				false
			);
		}

		// Schedule the cold-start trending seed (one-shot; idempotent).
		if ( class_exists( '\Zymarg\WCPG\Trending\Trending_Scheduler' ) ) {
			\Zymarg\WCPG\Trending\Trending_Scheduler::schedule_seed();
		}
	}
);

register_deactivation_hook(
	__FILE__,
	static function () {
		// Clear any rate-limit transients we may have set.
		// We avoid wiping wishlist/recently-viewed data on deactivate.
		global $wpdb;
		$wpdb->query(
			"DELETE FROM {$wpdb->options} WHERE option_name LIKE '\\_transient\\_zymarg\\_rl\\_%' OR option_name LIKE '\\_transient\\_timeout\\_zymarg\\_rl\\_%'"
		);

		// Unschedule all Action Scheduler jobs we own.
		if ( class_exists( '\Zymarg\WCPG\Trending\Trending_Scheduler' ) ) {
			\Zymarg\WCPG\Trending\Trending_Scheduler::unschedule_all();
		}
	}
);

/* -------------------------------------------------------------------------
 * HPOS + Cart/Checkout Blocks compatibility declaration
 *
 * Must run on `before_woocommerce_init` (very early), before the main
 * bootstrap. Done here rather than inside the Plugin class for timing safety.
 * ------------------------------------------------------------------------- */

add_action(
	'before_woocommerce_init',
	static function () {
		if ( class_exists( '\Automattic\WooCommerce\Utilities\FeaturesUtil' ) ) {
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility(
				'custom_order_tables',
				ZYMARG_WCPG_FILE,
				true
			);
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility(
				'cart_checkout_blocks',
				ZYMARG_WCPG_FILE,
				true
			);
		}
	}
);

/* -------------------------------------------------------------------------
 * Bootstrap
 * ------------------------------------------------------------------------- */

add_action(
	'plugins_loaded',
	static function () {
		\Zymarg\WCPG\Plugin::instance()->init();
	},
	20 // After WooCommerce + Elementor (both load on default 10).
);
