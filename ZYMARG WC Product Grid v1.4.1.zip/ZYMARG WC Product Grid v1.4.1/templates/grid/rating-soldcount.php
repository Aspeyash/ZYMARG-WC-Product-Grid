<?php
/**
 * Rating + sold count row.
 *
 * Hard rules:
 *   - Rating auto-hides when product has 0 ratings.
 *   - Sold count auto-hides when total_sales is 0.
 *   - Divider only renders when BOTH rating and sold count are visible
 *     AND layout is inline or count_first.
 *   - Entire wrapper is omitted when nothing renders.
 *
 * Layout modes (meta_layout setting):
 *   inline          — ★★★★☆ | Sold 120   (default, one row, 5-star graphic)
 *   count_first     — Sold 120 | ★★★★☆   (sold count on the left)
 *   count_indicator — ★ 4.5 | Sold 120   (v1.3.26: single star icon + numeric rating)
 *
 * v1.3.28: the 'stacked' layout was removed. Widgets that have it saved
 * fall back to 'inline' via the validator below. The whole meta row is
 * now single-line on every viewport.
 *
 * v1.3.25: the stock badge is now rendered into this row as the leftmost
 * element when product-card.php passes a non-empty $stock_badge_html. The
 * whole row also renders for the badge alone, even if rating and sold
 * count are both empty.
 *
 * @package Zymarg\WCPG
 *
 * @var \WC_Product $product
 * @var array       $settings
 * @var string      $stock_badge_html  Pre-built badge HTML (already escaped) or ''.
 */

defined( 'ABSPATH' ) || exit;

if ( ! ( $product instanceof \WC_Product ) ) {
	return;
}

$show_rating = ! isset( $settings['show_rating'] ) || 'yes' === $settings['show_rating'];
$show_sold   = ! isset( $settings['show_sold_count'] ) || 'yes' === $settings['show_sold_count'];

$rating_count = (int) $product->get_rating_count();
$rating_avg   = (float) $product->get_average_rating();
$total_sales  = (int) $product->get_total_sales();

$render_rating = $show_rating && $rating_count > 0 && $rating_avg > 0;
$render_sold   = $show_sold && $total_sales > 0;

// v1.3.25: stock badge is owned by this row now. Default to empty when the
// template is loaded by a theme override that pre-dates v1.3.25.
$stock_badge_html = isset( $stock_badge_html ) && is_string( $stock_badge_html ) ? $stock_badge_html : '';
$render_stock     = '' !== $stock_badge_html;

if ( ! $render_rating && ! $render_sold && ! $render_stock ) {
	return; // Whole row omitted from DOM.
}

// Wrapper class - allows product-card to pass row class.
$wrapper_class = isset( $wrapper_class ) && is_string( $wrapper_class )
	? $wrapper_class
	: 'zymarg-wcpg__meta';

// Layout mode.
$layout = isset( $settings['meta_layout'] ) ? (string) $settings['meta_layout'] : 'inline';
if ( ! in_array( $layout, array( 'inline', 'count_first', 'count_indicator' ), true ) ) {
	$layout = 'inline';
}

// Sold count formatter.
$sold_html = '';
if ( $render_sold ) {
	$format = isset( $settings['sold_count_format'] ) ? (string) $settings['sold_count_format'] : 'sold_n';
	switch ( $format ) {
		case 'n_sold':
			$sold_html = sprintf(
				/* translators: %s: number of items sold */
				esc_html__( '%s sold', 'zymarg-wcpg' ),
				esc_html( number_format_i18n( $total_sales ) )
			);
			break;
		case 'sold_n_plus':
			$rounded   = max( 0, (int) floor( $total_sales / 10 ) * 10 );
			$display   = $rounded < 10 ? $total_sales : $rounded;
			$sold_html = sprintf(
				/* translators: %s: number of items sold (rounded down to nearest 10) */
				esc_html__( 'Sold %s+', 'zymarg-wcpg' ),
				esc_html( number_format_i18n( $display ) )
			);
			break;
		case 'sold_n':
		default:
			$sold_html = sprintf(
				/* translators: %s: number of items sold */
				esc_html__( 'Sold %s', 'zymarg-wcpg' ),
				esc_html( number_format_i18n( $total_sales ) )
			);
			break;
	}
}

$fill_pct = $render_rating ? min( 100, max( 0, ( $rating_avg / 5 ) * 100 ) ) : 0;

$aria_rating = $render_rating
	? sprintf(
		/* translators: %s: rating average */
		__( 'Rated %s out of 5', 'zymarg-wcpg' ),
		number_format_i18n( $rating_avg, 1 )
	)
	: '';

// Build reusable HTML fragments.
$rating_html = '';
if ( $render_rating ) {
	$rating_html = sprintf(
		'<div class="zymarg-wcpg__rating" aria-label="%s">
			<span class="zymarg-wcpg__rating-stars" aria-hidden="true">
				<span class="zymarg-wcpg__rating-fill" style="width:%s%%;"></span>
			</span>
		</div>',
		esc_attr( $aria_rating ),
		esc_attr( $fill_pct )
	);
}

// v1.3.26: count-indicator variant - single star icon + numeric rating.
$rating_indicator_html = '';
if ( $render_rating ) {
	$rating_indicator_html = sprintf(
		'<div class="zymarg-wcpg__rating zymarg-wcpg__rating--indicator" aria-label="%s">
			<span class="zymarg-wcpg__rating-icon" aria-hidden="true">&#9733;</span>
			<span class="zymarg-wcpg__rating-value">%s</span>
		</div>',
		esc_attr( $aria_rating ),
		esc_html( number_format_i18n( $rating_avg, 1 ) )
	);
}

$divider_html = '<span class="zymarg-wcpg__divider" aria-hidden="true"></span>';

$sold_span = $render_sold
	? '<span class="zymarg-wcpg__sold">' . $sold_html . '</span>'
	: '';
?>

<?php if ( 'count_first' === $layout ) : ?>

	<div class="<?php echo esc_attr( $wrapper_class ); ?> zymarg-wcpg__meta zymarg-wcpg__meta--count-first">
		<?php if ( $render_stock ) : ?>
			<?php echo $stock_badge_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
		<?php endif; ?>
		<?php if ( $render_sold ) : ?>
			<?php echo $sold_span; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
		<?php endif; ?>
		<?php if ( $render_rating && $render_sold ) : ?>
			<?php echo $divider_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
		<?php endif; ?>
		<?php if ( $render_rating ) : ?>
			<?php echo $rating_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
		<?php endif; ?>
	</div>

<?php else : // inline (default) ?>

	<div class="<?php echo esc_attr( $wrapper_class ); ?> zymarg-wcpg__meta zymarg-wcpg__meta--inline">
		<?php if ( $render_stock ) : ?>
			<?php echo $stock_badge_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
		<?php endif; ?>
		<?php if ( $render_rating ) : ?>
			<?php
			// v1.3.26: count_indicator uses the single-star indicator instead of the 5-star graphic.
			echo 'count_indicator' === $layout ? $rating_indicator_html : $rating_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			?>
		<?php endif; ?>
		<?php if ( $render_rating && $render_sold ) : ?>
			<?php echo $divider_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
		<?php endif; ?>
		<?php if ( $render_sold ) : ?>
			<?php echo $sold_span; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
		<?php endif; ?>
	</div>

<?php endif; ?>
