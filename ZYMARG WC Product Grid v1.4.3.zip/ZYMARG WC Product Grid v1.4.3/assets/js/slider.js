/* global jQuery, Swiper */
/**
 * ZYMARG WC Product Grid - Slider Runtime
 *
 * Initialises Swiper on each .zymarg-wcpg--slider on the page using
 * the JSON config attached to the wrapper element. Re-initialises when
 * Elementor renders or re-renders the widget in the editor.
 */
( function ( $ ) {
	'use strict';

	function initOne( el ) {
		if ( typeof Swiper === 'undefined' ) {
			return;
		}
		var $el = $( el );
		if ( $el.data( 'zymargSwiperInited' ) ) {
			return;
		}
		var raw = $el.attr( 'data-swiper-config' );
		var config = {};
		try {
			config = raw ? JSON.parse( raw ) : {};
		} catch ( err ) {
			config = {};
		}

		var $swiperEl = $el.find( '.swiper' ).first();
		if ( ! $swiperEl.length ) { return; }

		// Resolve nav/pagination element references.
		if ( config.navigation === true ) {
			config.navigation = {
				nextEl: $el.find( '.swiper-button-next' )[ 0 ],
				prevEl: $el.find( '.swiper-button-prev' )[ 0 ]
			};
		}
		if ( config.pagination && typeof config.pagination === 'object' ) {
			config.pagination.el = $el.find( '.swiper-pagination' )[ 0 ];
		}

		try {
			var instance = new Swiper( $swiperEl[ 0 ], config );
			$el.data( 'zymargSwiperInited', true );
			$el.data( 'zymargSwiperInstance', instance );
		} catch ( e ) {
			if ( window.console ) { console.error( '[ZYMARG WCPG] Swiper init failed', e ); }
		}
	}

	function initAll( $scope ) {
		$scope = $scope || $( document );
		$scope.find( '.zymarg-wcpg--slider' ).each( function () {
			initOne( this );
		} );
	}

	$( function () { initAll(); } );

	// Elementor editor + frontend lifecycle.
	$( window ).on( 'elementor/frontend/init', function () {
		if ( window.elementorFrontend && elementorFrontend.hooks ) {
			elementorFrontend.hooks.addAction(
				'frontend/element_ready/zymarg_product_grid.default',
				function ( $scope ) { initAll( $scope ); }
			);
		}
	} );

} )( jQuery );
