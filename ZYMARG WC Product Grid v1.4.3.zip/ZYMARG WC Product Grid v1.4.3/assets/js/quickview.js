/* global jQuery, ZYMARGWCPG */
/**
 * ZYMARG WC Product Grid - Quick View Modal
 *
 * Lifecycle:
 *   1. Click eye icon -> open modal shell, AJAX fetch product data
 *   2. Inject HTML, bind variation logic + actions
 *   3. Variable products: client-side variation matrix resolution
 *   4. ATC -> existing add_to_cart endpoint (with variation_id)
 *   5. Buy Now -> buy_now endpoint, redirect to checkout
 *
 * Accessibility: focus trap, escape closes, click-outside closes,
 * focus return to trigger element.
 *
 * v1.3.14 fix: Removed the early-exit guard `if (!ns.ajaxUrl) return`.
 * That guard caused the entire script to bail out on the search results
 * page because ZYMARGWCPG is populated asynchronously there (via
 * waitForWCPG polling), so ns.ajaxUrl was empty at script-parse time.
 * All event handlers use $(document).on() delegation and are registered
 * immediately — the ajaxUrl/nonce are now read lazily inside each handler
 * at click time, by which point ZYMARGWCPG is always populated.
 */
( function ( $ ) {
	'use strict';

	var $overlay   = null;
	var $body      = null;
	var $content   = null;
	var $closeBtn  = null;
	var triggerEl  = null;
	var matrix     = [];
	var selection  = {};
	var currentPid = 0;
	var currentVid = 0;

	/**
	 * Read ajaxUrl + nonce lazily at call time — never at init time.
	 * This is safe on both Elementor pages (ZYMARGWCPG populated by
	 * wp_localize_script before DOM ready) and the search results page
	 * (populated asynchronously by waitForWCPG, always resolved before
	 * any user click can fire).
	 */
	function getNs() {
		return window.ZYMARGWCPG || {};
	}

	function ajax( action, data ) {
		var ns = getNs();
		return $.ajax( {
			url: ns.ajaxUrl || '/wp-admin/admin-ajax.php',
			method: 'POST',
			dataType: 'json',
			data: $.extend( {
				action: 'zymarg_wcpg_' + action,
				nonce: ns.nonce || ''
			}, data || {} )
		} );
	}

	function ensureRefs() {
		if ( $overlay && $overlay.length ) { return true; }
		$overlay = $( '.zymarg-wcpg__qv-overlay' );
		if ( ! $overlay.length ) { return false; }
		$body     = $overlay.find( '.zymarg-wcpg__qv-body' );
		$content  = $overlay.find( '.zymarg-wcpg__qv-content' );
		$closeBtn = $overlay.find( '.zymarg-wcpg__qv-close' );
		return true;
	}

	function open( productId, fromEl ) {
		if ( ! ensureRefs() ) { return; }
		triggerEl  = fromEl || null;
		currentPid = parseInt( productId, 10 );
		matrix     = [];
		selection  = {};
		currentVid = 0;

		var ns = getNs();

		$overlay.attr( 'hidden', false ).attr( 'aria-hidden', 'false' );
		$( 'body' ).addClass( 'zymarg-wcpg-qv-open' );
		setTimeout( function () { $overlay.addClass( 'is-open' ); }, 10 );
		$body.attr( 'aria-busy', 'true' );
		$content.empty();

		ajax( 'quick_view', { product_id: currentPid } )
			.done( function ( res ) {
				if ( res && res.success && res.data && res.data.html ) {
					$content.html( res.data.html );
					if ( res.data.product && Array.isArray( res.data.product.variations ) ) {
						matrix = res.data.product.variations;
					}
					$body.attr( 'aria-busy', 'false' );
					trapFocus();
				} else {
					$content.html( '<p>' + ( ( ns.i18n && ns.i18n.genericError ) || 'Error' ) + '</p>' );
					$body.attr( 'aria-busy', 'false' );
				}
			} )
			.fail( function () {
				var ns2 = getNs();
				$content.html( '<p>' + ( ( ns2.i18n && ns2.i18n.genericError ) || 'Error' ) + '</p>' );
				$body.attr( 'aria-busy', 'false' );
			} );
	}

	function close() {
		if ( ! $overlay || ! $overlay.length ) { return; }
		$overlay.removeClass( 'is-open' );
		$( 'body' ).removeClass( 'zymarg-wcpg-qv-open' );
		setTimeout( function () {
			$overlay.attr( 'hidden', true ).attr( 'aria-hidden', 'true' );
			$content.empty();
			matrix = []; selection = {}; currentVid = 0;
			if ( triggerEl && typeof triggerEl.focus === 'function' ) {
				try { triggerEl.focus(); } catch ( e ) {}
			}
		}, 200 );
	}

	function trapFocus() {
		if ( ! $overlay || ! $overlay.length ) { return; }
		var $focusable = $overlay.find( 'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])' ).filter( ':visible' );
		if ( $focusable.length ) {
			$focusable.first().trigger( 'focus' );
		} else {
			$closeBtn.trigger( 'focus' );
		}
	}

	/* ---------------- Variation logic ---------------- */
	function resolveVariation() {
		if ( ! matrix.length ) { return null; }
		for ( var i = 0; i < matrix.length; i++ ) {
			var v = matrix[ i ];
			var match = true;
			for ( var key in selection ) {
				if ( ! Object.prototype.hasOwnProperty.call( selection, key ) ) { continue; }
				var sel = selection[ key ];
				if ( ! sel ) { match = false; break; }
				var attrVal = v.attributes && v.attributes[ key ];
				// Empty attribute on a variation = "any" -> matches.
				if ( attrVal && attrVal !== sel ) { match = false; break; }
			}
			if ( match ) { return v; }
		}
		return null;
	}

	function allAttributesSelected() {
		var $attrs = $content.find( '.zymarg-wcpg__qv-attr' );
		var ok     = true;
		$attrs.each( function () {
			var name = $( this ).data( 'attribute-name' );
			if ( ! selection[ name ] ) { ok = false; }
		} );
		return ok;
	}

	function refreshVariationUI() {
		var ns      = getNs();
		var $atc    = $content.find( '.zymarg-wcpg__qv-btn--atc' );
		var $buy    = $content.find( '.zymarg-wcpg__qv-btn--buy-now' );
		var $status = $content.find( '.zymarg-wcpg__qv-variation-status' );
		var $price  = $content.find( '.zymarg-wcpg__qv-price' );
		var $img    = $content.find( '.zymarg-wcpg__qv-image' );

		if ( ! allAttributesSelected() ) {
			$atc.prop( 'disabled', true );
			$buy.prop( 'disabled', true );
			$status.text( '' );
			currentVid = 0;
			return;
		}
		var v = resolveVariation();
		if ( ! v ) {
			$atc.prop( 'disabled', true );
			$buy.prop( 'disabled', true );
			$status.text( ( ns.i18n && ns.i18n.unavailable ) || 'This combination is unavailable.' );
			currentVid = 0;
			return;
		}
		if ( ! v.in_stock ) {
			$atc.prop( 'disabled', true );
			$buy.prop( 'disabled', true );
			$status.text( ( ns.i18n && ns.i18n.outOfStock ) || 'Out of stock' );
			currentVid = 0;
			return;
		}
		if ( ! v.purchasable ) {
			$atc.prop( 'disabled', true );
			$buy.prop( 'disabled', true );
			$status.text( '' );
			currentVid = 0;
			return;
		}
		$atc.prop( 'disabled', false );
		$buy.prop( 'disabled', false );
		$status.text( '' );
		currentVid = v.variation_id;
		if ( v.price_html ) { $price.html( v.price_html ); }
		if ( v.image )      { $img.attr( 'src', v.image ); }
	}

	function getVariationAttrs() {
		var attrs = {};
		for ( var key in selection ) {
			if ( Object.prototype.hasOwnProperty.call( selection, key ) ) {
				attrs[ key ] = selection[ key ];
			}
		}
		return attrs;
	}

	/* ---------------- Event handlers ---------------- */

	// Quantity stepper — increment.
	$( document ).on( 'click', '.zymarg-wcpg__qv-qty-btn--inc', function ( e ) {
		e.preventDefault();
		var $input = $( this ).siblings( '.zymarg-wcpg__qv-qty' );
		if ( ! $input.length ) { return; }
		var max     = parseInt( $input.attr( 'max' ), 10 );
		var current = parseInt( $input.val(), 10 ) || 1;
		if ( isNaN( max ) || current < max ) {
			$input.val( current + 1 ).trigger( 'change' );
		}
	} );

	// Quantity stepper — decrement.
	$( document ).on( 'click', '.zymarg-wcpg__qv-qty-btn--dec', function ( e ) {
		e.preventDefault();
		var $input = $( this ).siblings( '.zymarg-wcpg__qv-qty' );
		if ( ! $input.length ) { return; }
		var min     = parseInt( $input.attr( 'min' ), 10 ) || 1;
		var current = parseInt( $input.val(), 10 ) || 1;
		if ( current > min ) {
			$input.val( current - 1 ).trigger( 'change' );
		}
	} );

	// Sanitize manual quantity input.
	$( document ).on( 'change input', '.zymarg-wcpg__qv-qty', function () {
		var $input = $( this );
		var min = parseInt( $input.attr( 'min' ), 10 ) || 1;
		var max = parseInt( $input.attr( 'max' ), 10 );
		var v   = parseInt( $input.val(), 10 );
		if ( isNaN( v ) || v < min ) { v = min; }
		if ( ! isNaN( max ) && v > max ) { v = max; }
		if ( String( v ) !== $input.val() ) { $input.val( v ); }
	} );

	// Click eye icon on any card (Elementor grid or search results page).
	$( document ).on( 'click', '.zymarg-wcpg__icon-btn--quickview', function ( e ) {
		e.preventDefault();
		var pid = parseInt( $( this ).data( 'product-id' ), 10 );
		if ( ! pid ) { return; }
		open( pid, this );
	} );

	// Close — X button.
	$( document ).on( 'click', '.zymarg-wcpg__qv-close', function ( e ) {
		e.preventDefault();
		close();
	} );

	// Close — overlay backdrop click.
	$( document ).on( 'click', '.zymarg-wcpg__qv-overlay', function ( e ) {
		if ( e.target === this ) { close(); }
	} );

	// Close — Escape key.
	$( document ).on( 'keydown', function ( e ) {
		if ( e.key === 'Escape' && $overlay && $overlay.hasClass( 'is-open' ) ) {
			close();
		}
	} );

	// Gallery thumbnail click.
	$( document ).on( 'click', '.zymarg-wcpg__qv-thumb', function ( e ) {
		e.preventDefault();
		var src = $( this ).data( 'large' );
		$content.find( '.zymarg-wcpg__qv-thumb' ).removeClass( 'is-active' );
		$( this ).addClass( 'is-active' );
		if ( src ) {
			$content.find( '.zymarg-wcpg__qv-image' ).attr( 'src', src );
		}
	} );

	// Swatch click.
	$( document ).on( 'click', '.zymarg-wcpg__qv-swatch', function ( e ) {
		e.preventDefault();
		var $btn  = $( this );
		var $attr = $btn.closest( '.zymarg-wcpg__qv-attr' );
		var name  = $attr.data( 'attribute-name' );
		var value = $btn.data( 'value' );
		$attr.find( '.zymarg-wcpg__qv-swatch' ).attr( 'aria-selected', 'false' );
		$btn.attr( 'aria-selected', 'true' );
		selection[ name ] = value;
		refreshVariationUI();
	} );

	// Dropdown variation change.
	$( document ).on( 'change', '.zymarg-wcpg__qv-select', function () {
		var name = $( this ).data( 'attribute-name' );
		var val  = $( this ).val();
		if ( val ) {
			selection[ name ] = val;
		} else {
			delete selection[ name ];
		}
		refreshVariationUI();
	} );

	// ATC inside modal.
	$( document ).on( 'click', '.zymarg-wcpg__qv-btn--atc', function ( e ) {
		e.preventDefault();
		var $btn = $( this );
		if ( $btn.prop( 'disabled' ) || $btn.hasClass( 'is-loading' ) ) { return; }
		var $product = $content.find( '.zymarg-wcpg__qv-product' );
		var type     = $product.data( 'product-type' );
		var qty      = parseInt( $content.find( '.zymarg-wcpg__qv-qty' ).val(), 10 ) || 1;

		if ( type === 'variable' && ! currentVid ) { return; }

		$btn.addClass( 'is-loading' );
		ajax( 'add_to_cart', {
			product_id:   currentPid,
			variation_id: currentVid,
			variation:    getVariationAttrs(),
			quantity:     qty
		} ).done( function ( res ) {
			var ns = getNs();
			if ( res && res.success ) {
				if ( ns.toast ) {
					ns.toast( ( res.data && res.data.message ) || 'Added', 'success' );
				}
				if ( res.data && res.data.fragments ) {
					$( document.body ).trigger( 'wc_fragments_refreshed', [ res.data.fragments, res.data.cart_hash ] );
					$( document.body ).trigger( 'added_to_cart',          [ res.data.fragments, res.data.cart_hash, $btn ] );
				}
				close();
			} else if ( ns.toast ) {
				ns.toast( ( res && res.data && res.data.message ) || ( ns.i18n && ns.i18n.genericError ) || 'Error', 'error' );
			}
		} ).fail( function ( xhr ) {
			var ns = getNs();
			if ( ns.toast ) {
				ns.toast( xhr.status === 429
					? ( ( ns.i18n && ns.i18n.rateLimited ) || 'Too many requests' )
					: ( ( ns.i18n && ns.i18n.genericError ) || 'Error' ),
					'error'
				);
			}
		} ).always( function () {
			$btn.removeClass( 'is-loading' );
		} );
	} );

	// Buy Now inside modal.
	$( document ).on( 'click', '.zymarg-wcpg__qv-btn--buy-now', function ( e ) {
		e.preventDefault();
		var $btn = $( this );
		if ( $btn.prop( 'disabled' ) || $btn.hasClass( 'is-loading' ) ) { return; }
		var $product = $content.find( '.zymarg-wcpg__qv-product' );
		var type     = $product.data( 'product-type' );
		var qty      = parseInt( $content.find( '.zymarg-wcpg__qv-qty' ).val(), 10 ) || 1;

		if ( type === 'variable' && ! currentVid ) { return; }

		$btn.addClass( 'is-loading' );
		ajax( 'buy_now', {
			product_id:   currentPid,
			variation_id: currentVid,
			variation:    getVariationAttrs(),
			quantity:     qty
		} ).done( function ( res ) {
			var ns = getNs();
			if ( res && res.success && res.data && res.data.redirect ) {
				window.location.href = res.data.redirect;
			} else if ( ns.toast ) {
				ns.toast( ( res && res.data && res.data.message ) || ( ( ns.i18n && ns.i18n.genericError ) || 'Error' ), 'error' );
				$btn.removeClass( 'is-loading' );
			}
		} ).fail( function ( xhr ) {
			var ns = getNs();
			if ( ns.toast ) {
				ns.toast( xhr.status === 429
					? ( ( ns.i18n && ns.i18n.rateLimited ) || 'Too many requests' )
					: ( ( ns.i18n && ns.i18n.genericError ) || 'Error' ),
					'error'
				);
			}
			$btn.removeClass( 'is-loading' );
		} );
	} );

	// Expose for debugging.
	( window.ZYMARGWCPG = window.ZYMARGWCPG || {} ).openQuickView  = open;
	( window.ZYMARGWCPG = window.ZYMARGWCPG || {} ).closeQuickView = close;

} )( jQuery );
