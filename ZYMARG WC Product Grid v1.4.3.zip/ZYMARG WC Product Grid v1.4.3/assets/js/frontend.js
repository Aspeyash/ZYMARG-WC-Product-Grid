/* global jQuery, ZYMARGWCPG */
/**
 * ZYMARG WC Product Grid - Frontend Runtime (Phase 4)
 *
 * Real AJAX layer:
 *   - Cache-safe wishlist heart hydration on page load (one /hydrate call
 *     reads visitor wishlist IDs and toggles aria-pressed on every heart).
 *   - Wishlist click: optimistic toggle, AJAX persist, rollback on error.
 *   - Add to cart: simple products only (variable links to PDP); refreshes
 *     cart fragments via the WC fragments hook so themed mini-carts update.
 *   - Click tracking on card link clicks (throttled per card per page).
 *   - Quick view click: posts a quickview event for trending, prevents
 *     default - the modal arrives in Phase 5.
 *   - Load more pagination: posts widget settings + page, appends rendered
 *     cards, hydrates them too.
 *   - Toast notifications for success / error / rate-limit messages.
 *
 * v1.3.14 fix: ajaxUrl and nonce are no longer read once at IIFE init time.
 * They are read lazily via getNs() inside every handler and every ajax()
 * call. This fixes silent failures on the search results page where
 * ZYMARGWCPG is populated asynchronously (waitForWCPG polling) — by the
 * time any user click fires, ZYMARGWCPG is always fully populated.
 */
( function ( $ ) {
	'use strict';

	var ns   = ( window.ZYMARGWCPG = window.ZYMARGWCPG || {} );
	ns.ready = true;

	var TRACK_KEY = '_zymargTracked';

	/**
	 * Read ajaxUrl + nonce lazily at call time.
	 * Always returns the live window.ZYMARGWCPG object so async
	 * population (search page) is picked up correctly.
	 */
	function getNs() {
		return window.ZYMARGWCPG || {};
	}

	/* ----------------------------------------------------------------- *
	 * Toast
	 * ----------------------------------------------------------------- */
	var $toastHost = null;
	function toast( message, type ) {
		if ( ! message ) { return; }
		if ( ! $toastHost ) {
			$toastHost = $( '<div class="zymarg-wcpg__toast-host" role="status" aria-live="polite"></div>' ).appendTo( 'body' );
		}
		var $t = $( '<div class="zymarg-wcpg__toast"></div>' )
			.addClass( 'zymarg-wcpg__toast--' + ( type || 'info' ) )
			.text( message )
			.appendTo( $toastHost );
		setTimeout( function () { $t.addClass( 'is-in' ); }, 10 );
		setTimeout( function () {
			$t.removeClass( 'is-in' );
			setTimeout( function () { $t.remove(); }, 250 );
		}, 2400 );
	}

	function ajax( action, data ) {
		var _ns = getNs();
		return $.ajax( {
			url: _ns.ajaxUrl || '/wp-admin/admin-ajax.php',
			method: 'POST',
			dataType: 'json',
			data: $.extend( {
				action: 'zymarg_wcpg_' + action,
				nonce:  _ns.nonce || ''
			}, data || {} )
		} );
	}

	/* ----------------------------------------------------------------- *
	 * Hydration - cache-safe wishlist heart state
	 * ----------------------------------------------------------------- */
	function hydrate( $scope ) {
		$scope = $scope || $( document );
		var $hearts = $scope.find( '.zymarg-wcpg__icon-btn--wishlist' );
		if ( ! $hearts.length ) { return; }
		ajax( 'hydrate', {} ).done( function ( res ) {
			if ( ! res || ! res.success || ! res.data ) { return; }
			var ids   = res.data.wishlist_ids || [];
			var idMap = {};
			for ( var i = 0; i < ids.length; i++ ) { idMap[ ids[ i ] ] = true; }
			$hearts.each( function () {
				var _ns2 = getNs();
				var pid  = parseInt( $( this ).data( 'product-id' ), 10 );
				$( this ).attr( 'aria-pressed', idMap[ pid ] ? 'true' : 'false' );
				$( this ).attr(
					'aria-label',
					idMap[ pid ]
						? ( ( _ns2.i18n && _ns2.i18n.removeFromWishlist ) || 'Remove from wishlist' )
						: ( ( _ns2.i18n && _ns2.i18n.addToWishlist )      || 'Add to wishlist' )
				);
			} );
		} );
	}

	/* ----------------------------------------------------------------- *
	 * Wishlist click
	 * ----------------------------------------------------------------- */
	$( document ).on( 'click', '.zymarg-wcpg__icon-btn--wishlist', function ( e ) {
		e.preventDefault();
		var $btn = $( this );
		if ( $btn.data( 'busy' ) ) { return; }
		$btn.data( 'busy', true );

		var pid    = parseInt( $btn.data( 'product-id' ), 10 );
		var wasOn  = $btn.attr( 'aria-pressed' ) === 'true';
		var nextOn = ! wasOn;

		// Optimistic toggle.
		$btn.attr( 'aria-pressed', nextOn ? 'true' : 'false' );

		ajax( 'wishlist', { op: 'toggle', product_id: pid } )
			.done( function ( res ) {
				var _ns = getNs();
				if ( res && res.success ) {
					var on = !! ( res.data && res.data.in_wishlist );
					$btn.attr( 'aria-pressed', on ? 'true' : 'false' );
					toast( res.data && res.data.message ? res.data.message : '', 'success' );
				} else {
					// Rollback.
					$btn.attr( 'aria-pressed', wasOn ? 'true' : 'false' );
					toast( ( res && res.data && res.data.message ) || ( ( _ns.i18n && _ns.i18n.genericError ) || 'Error' ), 'error' );
				}
			} )
			.fail( function ( xhr ) {
				var _ns = getNs();
				$btn.attr( 'aria-pressed', wasOn ? 'true' : 'false' );
				if ( xhr.status === 429 ) {
					toast( ( _ns.i18n && _ns.i18n.rateLimited ) || 'Too many requests', 'error' );
				} else {
					toast( ( _ns.i18n && _ns.i18n.genericError ) || 'Error', 'error' );
				}
			} )
			.always( function () { $btn.data( 'busy', false ); } );
	} );

	/* ----------------------------------------------------------------- *
	 * Add to cart - simple products only
	 * ----------------------------------------------------------------- */
	$( document ).on( 'click', '.zymarg-wcpg__icon-btn--atc', function ( e ) {
		var $btn = $( this );
		var type = String( $btn.data( 'product-type' ) || 'simple' );
		var pid  = parseInt( $btn.data( 'product-id' ), 10 );

		// Variable products: let the <a> link navigate to the PDP.
		if ( 'simple' !== type || ! pid ) { return; }

		// Out-of-stock: let the link navigate too.
		var inStock = $btn.closest( '.zymarg-wcpg__card' ).is( ':not(.is-oos)' );
		if ( ! inStock ) { return; }

		e.preventDefault();
		if ( $btn.data( 'busy' ) ) { return; }
		$btn.data( 'busy', true ).addClass( 'is-loading' );

		ajax( 'add_to_cart', { product_id: pid, quantity: 1 } )
			.done( function ( res ) {
				var _ns = getNs();
				if ( res && res.success ) {
					toast( ( res.data && res.data.message ) || ( ( _ns.i18n && _ns.i18n.addedToCart ) || 'Added' ), 'success' );

					if ( res.data && res.data.fragments ) {
						$( document.body ).trigger(
							'wc_fragments_refreshed',
							[ res.data.fragments, res.data.cart_hash ]
						);

						// Check if we're inside an Elementor widget wrapper.
						// On the search page there is no .zymarg-wcpg ancestor,
						// so $widget will be empty — treat that as showViewCart=true
						// (same as the widget default) so fragments still fire.
						var $widget      = $btn.closest( '.zymarg-wcpg' );
						var showViewCart = $widget.length
							? ( '0' !== $widget.attr( 'data-show-view-cart' ) )
							: true;

						if ( showViewCart ) {
							$( document.body ).trigger(
								'added_to_cart',
								[ res.data.fragments, res.data.cart_hash, $btn ]
							);
						} else {
							$btn.siblings( '.added_to_cart' ).remove();
							$btn.parent().find( '.added_to_cart' ).remove();
						}
					}
				} else {
					toast( ( res && res.data && res.data.message ) || ( ( _ns.i18n && _ns.i18n.genericError ) || 'Error' ), 'error' );
				}
			} )
			.fail( function ( xhr ) {
				var _ns = getNs();
				if ( xhr.status === 429 ) {
					toast( ( _ns.i18n && _ns.i18n.rateLimited ) || 'Too many requests', 'error' );
				} else {
					toast( ( _ns.i18n && _ns.i18n.genericError ) || 'Error', 'error' );
				}
			} )
			.always( function () {
				$btn.data( 'busy', false ).removeClass( 'is-loading' );
			} );
	} );

	/* ----------------------------------------------------------------- *
	 * Click tracking on card link clicks (throttle once per card per page).
	 * ----------------------------------------------------------------- */
	$( document ).on( 'click', '.zymarg-wcpg__title-link, .zymarg-wcpg__image-link', function () {
		var $card = $( this ).closest( '.zymarg-wcpg__card' );
		if ( ! $card.length || $card.data( TRACK_KEY ) ) { return; }
		var pid = parseInt( $card.data( 'product-id' ), 10 );
		if ( ! pid ) { return; }
		$card.data( TRACK_KEY, true );
		ajax( 'track_click', { product_id: pid, event: 'click' } );
	} );

	/* ----------------------------------------------------------------- *
	 * Load more pagination
	 * ----------------------------------------------------------------- */
	$( document ).on( 'click', '.zymarg-wcpg__load-more', function ( e ) {
		e.preventDefault();
		var $btn = $( this );
		if ( $btn.data( 'busy' ) ) { return; }

		var $widget = $btn.closest( '.zymarg-wcpg' );
		var $grid   = $widget.find( '.zymarg-wcpg__grid' );
		var page    = parseInt( $btn.data( 'page' ), 10 ) || 2;
		var settings;
		try {
			settings = JSON.parse( $widget.attr( 'data-settings' ) || '{}' );
		} catch ( err ) {
			settings = {};
		}

		var extraData = {
			page:      page,
			widget_id: $widget.attr( 'data-widget-id' )
		};
		var algoliaQuery = $btn.data( 'algolia-query' );
		if ( algoliaQuery !== undefined && algoliaQuery !== '' ) {
			extraData.algolia_query = String( algoliaQuery );
		}

		$btn.data( 'busy', true ).addClass( 'is-loading' );

		ajax( 'load_more', $.extend( extraData, settings ) )
			.done( function ( res ) {
				if ( res && res.success && res.data && res.data.html ) {
					var $newCards = $( res.data.html );
					$grid.append( $newCards );
					hydrate( $newCards );
					if ( res.data.has_more ) {
						$btn.data( 'page', page + 1 );
					} else {
						$btn.remove();
					}
				} else {
					$btn.remove();
				}
			} )
			.fail( function ( xhr ) {
				var _ns = getNs();
				if ( xhr.status === 429 ) {
					toast( ( _ns.i18n && _ns.i18n.rateLimited ) || 'Too many requests', 'error' );
				} else {
					toast( ( _ns.i18n && _ns.i18n.genericError ) || 'Error', 'error' );
				}
			} )
			.always( function () {
				$btn.data( 'busy', false ).removeClass( 'is-loading' );
			} );
	} );

	/* ----------------------------------------------------------------- *
	 * Bootstrap on DOM ready.
	 * ----------------------------------------------------------------- */
	$( function () {
		hydrate();
	} );

	// Re-hydrate when Elementor renders a widget (covers the editor preview
	// reload and AJAX-loaded sections).
	$( window ).on( 'elementor/frontend/init', function () {
		if ( window.elementorFrontend && elementorFrontend.hooks ) {
			elementorFrontend.hooks.addAction(
				'frontend/element_ready/zymarg_product_grid.default',
				function ( $scope ) { hydrate( $scope ); }
			);
		}
	} );

	// Expose for debugging / external use.
	ns.hydrate = hydrate;
	ns.toast   = toast;

} )( jQuery );
