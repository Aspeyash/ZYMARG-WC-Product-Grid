/* global jQuery, ajaxurl, ZYMARGWCPG, console */
/**
 * ZYMARG WC Product Grid - Editor Runtime
 *
 * Phase 3B: handles the diagnostic action buttons inside the editor preview
 * for the Trending and More From Seller widgets. Buttons post to admin-only
 * AJAX endpoints; results show as inline status messages.
 */
( function ( $ ) {
	'use strict';

	function ajaxAction( action, data, button ) {
		var $btn = $( button );
		var $diag = $btn.closest( '.zymarg-wcpg__editor-diag' );
		var nonce = $diag.data( 'nonce' );
		var pid = $diag.data( 'product-id' );
		var $status = $diag.find( '.zymarg-wcpg__editor-diag-status' );

		if ( ! $status.length ) {
			$status = $( '<div class="zymarg-wcpg__editor-diag-status"></div>' ).appendTo( $diag );
		}

		$btn.prop( 'disabled', true );
		$status.removeClass( 'is-error is-success' ).text( '...' );

		$.post(
			( window.ajaxurl || '/wp-admin/admin-ajax.php' ),
			$.extend(
				{
					action: 'zymarg_wcpg_editor_' + action,
					nonce: nonce
				},
				pid ? { product_id: pid } : {},
				data || {}
			)
		).done( function ( res ) {
			if ( res && res.success ) {
				$status.addClass( 'is-success' ).text( ( res.data && res.data.message ) || 'OK' );
			} else {
				var msg = ( res && res.data && res.data.message ) || 'Request failed.';
				$status.addClass( 'is-error' ).text( msg );
			}
		} ).fail( function ( xhr ) {
			$status.addClass( 'is-error' ).text( 'HTTP ' + xhr.status );
		} ).always( function () {
			$btn.prop( 'disabled', false );
		} );
	}

	$( document ).on( 'click', '.zymarg-wcpg__editor-diag-btn', function ( e ) {
		e.preventDefault();
		var action = $( this ).data( 'action' );
		var confirmText = $( this ).data( 'confirm' );
		if ( confirmText && ! window.confirm( confirmText ) ) {
			return;
		}
		ajaxAction( action, {}, this );
	} );

	if ( window.console && typeof window.console.info === 'function' ) {
		window.console.info( '[ZYMARG WCPG] Editor diagnostics ready.' );
	}
} )( jQuery );
