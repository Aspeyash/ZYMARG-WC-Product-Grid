<?php
/**
 * Event write buffer.
 *
 * Click / quick-view / wishlist-add / cart-add events are funnelled here
 * before being flushed in batches into the aggregate Engagement_Store.
 * This keeps front-end latency O(1) and reduces option writes by ~50x
 * even on busy stores.
 *
 * @package Zymarg\WCPG
 */

namespace Zymarg\WCPG\Trending;

defined( 'ABSPATH' ) || exit;

/**
 * Class Event_Buffer
 */
class Event_Buffer {

	const TRANSIENT_KEY = 'zymarg_wcpg_event_buffer';
	const LOCK_KEY      = 'zymarg_wcpg_event_flush_lock';
	const TTL           = 600; // 10 minutes safety net.
	const HARD_CAP      = 200;
	const FLUSH_AT      = 50;

	/**
	 * Push an event into the buffer. Triggers a flush when the soft
	 * cap is reached.
	 *
	 * @param int    $product_id Product ID.
	 * @param string $type       Event type.
	 * @param string $ip_hash    Salted hash of IP+UA, used for de-dup.
	 * @return bool True on success.
	 */
	public static function push( $product_id, $type, $ip_hash = '' ) {
		$product_id = (int) $product_id;
		$valid      = array_keys( Engagement_Store::event_weights() );
		if ( $product_id <= 0 || ! in_array( $type, $valid, true ) ) {
			return false;
		}

		$buffer = self::read();

		// Per-day per-product per-IP de-dup. Same visitor counts at most once.
		$today = wp_date( 'Y-m-d' );
		$key   = $product_id . '|' . $type . '|' . $ip_hash . '|' . $today;
		foreach ( $buffer as $existing ) {
			if ( ( $existing['k'] ?? '' ) === $key ) {
				return true; // Already counted.
			}
		}

		$buffer[] = array(
			'pid'   => $product_id,
			'event' => $type,
			'ts'    => time(),
			'k'     => $key,
		);

		// Hard cap: drop oldest if we overflow (safety against transient corruption).
		if ( count( $buffer ) > self::HARD_CAP ) {
			$buffer = array_slice( $buffer, -self::HARD_CAP );
		}

		set_transient( self::TRANSIENT_KEY, $buffer, self::TTL );

		// Soft cap: trigger inline flush when hit.
		if ( count( $buffer ) >= self::FLUSH_AT ) {
			self::flush();
		}
		return true;
	}

	/**
	 * Read the current buffer.
	 *
	 * @return array
	 */
	public static function read() {
		$buffer = get_transient( self::TRANSIENT_KEY );
		return is_array( $buffer ) ? $buffer : array();
	}

	/**
	 * Flush the buffer into the aggregate store.
	 *
	 * Uses a short-lived lock so two concurrent requests cannot
	 * double-write the same events.
	 *
	 * @return int Number of events flushed.
	 */
	public static function flush() {
		// Lock - 30s. wp_cache_add returns false if key already exists.
		if ( ! wp_cache_add( self::LOCK_KEY, 1, 'zymarg_wcpg', 30 ) ) {
			return 0;
		}

		$buffer = self::read();
		if ( empty( $buffer ) ) {
			wp_cache_delete( self::LOCK_KEY, 'zymarg_wcpg' );
			return 0;
		}

		// Atomic-ish swap: read, clear transient, then write to aggregate.
		delete_transient( self::TRANSIENT_KEY );

		Engagement_Store::record_events( $buffer );

		wp_cache_delete( self::LOCK_KEY, 'zymarg_wcpg' );
		return count( $buffer );
	}
}
