<?php
/**
 * Trending score computation.
 *
 * Combines three signals into a single per-product score:
 *   - Sales velocity in window (HPOS-aware via wc_get_orders)
 *   - Engagement (sum of weighted clicks/quickviews/wishlists/cart-adds)
 *   - Recency (inverse of days since publish)
 *
 * Score formula:
 *   trending_score =
 *       (W_sales      * normalize(sales_count_in_window))
 *     + (W_engagement * normalize(engagement_score_in_window))
 *     + (W_recency    * normalize(recency_inverse))
 *
 * Defaults W_sales=50, W_engagement=30, W_recency=20 (per locked spec).
 * Each factor is normalised to [0..1] against the candidate-pool max
 * before weighting.
 *
 * @package Zymarg\WCPG
 */

namespace Zymarg\WCPG\Trending;

defined( 'ABSPATH' ) || exit;

/**
 * Class Trending_Calculator
 */
class Trending_Calculator {

	const CACHE_OPTION         = 'zymarg_wcpg_trending_cache';
	const META_KEY             = 'zymarg_wcpg_trending_meta';
	const TOP_N                = 200;
	const COLD_START_THRESHOLD = 100; // events. Below: lean on lifetime sales.

	/**
	 * Recompute and cache the top-N trending product IDs.
	 *
	 * @param array $opts Optional overrides: window, weights.
	 * @return int Number of products cached.
	 */
	public static function recompute( array $opts = array() ) {
		$window  = isset( $opts['window'] ) ? (int) $opts['window'] : 7;
		$weights = self::resolve_weights( $opts );
		$totals  = Engagement_Store::get_window_totals( $window );

		$cold_start = self::is_cold_start( $totals );
		$sales_map  = self::compute_sales_map( $window );
		$pool_ids   = array_unique( array_merge( array_keys( $totals ), array_keys( $sales_map ) ) );

		if ( $cold_start ) {
			$pool_ids = array_unique( array_merge( $pool_ids, self::cold_start_pool() ) );
		}

		if ( empty( $pool_ids ) ) {
			update_option( self::CACHE_OPTION, array(), false );
			self::write_meta( $window, $weights, 0, $cold_start );
			return 0;
		}

		$dates_map  = self::fetch_publish_dates( $pool_ids );
		$lifetime   = $cold_start ? self::fetch_lifetime_sales( $pool_ids ) : array();
		$now        = time();
		$max_age    = 1;
		foreach ( $dates_map as $ts ) {
			$age     = max( 1, ( $now - (int) $ts ) / DAY_IN_SECONDS );
			$max_age = max( $max_age, $age );
		}

		$max_sales = max( 1, $sales_map ? max( $sales_map ) : 0 );
		$max_eng   = 1;
		foreach ( $totals as $t ) {
			$max_eng = max( $max_eng, $t['score'] );
		}
		$max_lifetime = max( 1, $lifetime ? max( $lifetime ) : 0 );

		$scored = array();
		foreach ( $pool_ids as $pid ) {
			$pid     = (int) $pid;
			$sales   = isset( $sales_map[ $pid ] ) ? (int) $sales_map[ $pid ] : 0;
			$eng     = isset( $totals[ $pid ] ) ? (int) $totals[ $pid ]['score'] : 0;
			$ts      = isset( $dates_map[ $pid ] ) ? (int) $dates_map[ $pid ] : 0;
			$age     = $ts > 0 ? max( 1, ( $now - $ts ) / DAY_IN_SECONDS ) : $max_age;
			$recency = 1 - min( 1, $age / $max_age );

			$norm_sales = $sales / $max_sales;
			$norm_eng   = $eng / $max_eng;

			if ( $cold_start && 0 === $eng && 0 === $sales ) {
				$lt         = isset( $lifetime[ $pid ] ) ? (int) $lifetime[ $pid ] : 0;
				$norm_sales = $lt / $max_lifetime;
			}

			$score = ( $weights['sales'] * $norm_sales )
				+ ( $weights['engagement'] * $norm_eng )
				+ ( $weights['recency'] * $recency );

			if ( $score > 0 ) {
				$scored[ $pid ] = $score;
			}
		}

		arsort( $scored, SORT_NUMERIC );
		$top = array_slice( array_keys( $scored ), 0, self::TOP_N );

		update_option( self::CACHE_OPTION, $top, false );
		self::write_meta( $window, $weights, count( $top ), $cold_start );

		return count( $top );
	}

	/**
	 * Whether we're in cold-start mode (insufficient live data).
	 *
	 * @param array $totals Window totals.
	 * @return bool
	 */
	public static function is_cold_start( array $totals ) {
		$total_events = 0;
		foreach ( $totals as $t ) {
			$total_events += (int) $t['events'];
		}
		return $total_events < self::COLD_START_THRESHOLD;
	}

	/**
	 * Get cached top-N product IDs (without recomputing).
	 *
	 * @return int[]
	 */
	public static function get_cached_ids() {
		$ids = get_option( self::CACHE_OPTION, array() );
		return is_array( $ids ) ? array_map( 'intval', $ids ) : array();
	}

	/**
	 * Calculator metadata (for editor diagnostics).
	 *
	 * @return array
	 */
	public static function get_meta() {
		$meta = get_option( self::META_KEY, array() );
		return is_array( $meta ) ? $meta : array();
	}

	/**
	 * Resolve weights from input overrides; defaults from locked spec.
	 *
	 * @param array $opts Inputs.
	 * @return array{sales:float,engagement:float,recency:float}
	 */
	public static function resolve_weights( array $opts ) {
		$ws    = isset( $opts['w_sales'] ) ? max( 0, (int) $opts['w_sales'] ) : 50;
		$we    = isset( $opts['w_engagement'] ) ? max( 0, (int) $opts['w_engagement'] ) : 30;
		$wr    = isset( $opts['w_recency'] ) ? max( 0, (int) $opts['w_recency'] ) : 20;
		$total = $ws + $we + $wr;
		if ( $total <= 0 ) {
			return array(
				'sales'      => 0.5,
				'engagement' => 0.3,
				'recency'    => 0.2,
			);
		}
		return array(
			'sales'      => $ws / $total,
			'engagement' => $we / $total,
			'recency'    => $wr / $total,
		);
	}

	/**
	 * Compute per-product sales count in window (HPOS-aware).
	 *
	 * @param int $window_days Window size.
	 * @return array<int,int> Map pid -> count.
	 */
	private static function compute_sales_map( $window_days ) {
		if ( ! function_exists( 'wc_get_orders' ) ) {
			return array();
		}
		$after = gmdate( 'Y-m-d H:i:s', time() - ( max( 1, $window_days ) * DAY_IN_SECONDS ) );

		$orders = wc_get_orders(
			array(
				'limit'        => -1,
				'status'       => array( 'wc-completed', 'wc-processing' ),
				'date_created' => '>=' . $after,
				'return'       => 'ids',
				'type'         => 'shop_order',
			)
		);
		if ( empty( $orders ) || is_wp_error( $orders ) ) {
			return array();
		}

		$map = array();
		foreach ( $orders as $order_id ) {
			$order = wc_get_order( $order_id );
			if ( ! $order ) {
				continue;
			}
			foreach ( $order->get_items() as $item ) {
				$pid = (int) $item->get_product_id();
				if ( $pid <= 0 ) {
					continue;
				}
				$qty = (int) $item->get_quantity();
				if ( ! isset( $map[ $pid ] ) ) {
					$map[ $pid ] = 0;
				}
				$map[ $pid ] += max( 1, $qty );
			}
		}
		return $map;
	}

	/**
	 * Bulk fetch publish-date timestamps for a set of products.
	 *
	 * @param int[] $product_ids Product IDs.
	 * @return array<int,int> Map pid -> unix timestamp.
	 */
	private static function fetch_publish_dates( array $product_ids ) {
		if ( empty( $product_ids ) ) {
			return array();
		}
		global $wpdb;
		$ids          = array_values( array_filter( array_map( 'intval', $product_ids ) ) );
		if ( empty( $ids ) ) {
			return array();
		}
		$placeholders = implode( ', ', array_fill( 0, count( $ids ), '%d' ) );
		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT ID, post_date_gmt, post_date FROM {$wpdb->posts}
				 WHERE ID IN ($placeholders) AND post_type = 'product' AND post_status = 'publish'", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$ids
			)
		);
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$map = array();
		if ( $rows ) {
			foreach ( $rows as $row ) {
				$src                   = $row->post_date_gmt && '0000-00-00 00:00:00' !== $row->post_date_gmt ? $row->post_date_gmt : $row->post_date;
				$map[ (int) $row->ID ] = (int) strtotime( $src );
			}
		}
		return $map;
	}

	/**
	 * Bulk fetch lifetime total_sales meta values.
	 *
	 * @param int[] $product_ids Product IDs.
	 * @return array<int,int>
	 */
	private static function fetch_lifetime_sales( array $product_ids ) {
		if ( empty( $product_ids ) ) {
			return array();
		}
		global $wpdb;
		$ids          = array_values( array_filter( array_map( 'intval', $product_ids ) ) );
		if ( empty( $ids ) ) {
			return array();
		}
		$placeholders = implode( ', ', array_fill( 0, count( $ids ), '%d' ) );
		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT post_id, meta_value FROM {$wpdb->postmeta}
				 WHERE post_id IN ($placeholders) AND meta_key = %s", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				array_merge( $ids, array( 'total_sales' ) )
			)
		);
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		$map = array();
		if ( $rows ) {
			foreach ( $rows as $row ) {
				$map[ (int) $row->post_id ] = (int) $row->meta_value;
			}
		}
		return $map;
	}

	/**
	 * Lifetime top-200 by total_sales, used to bootstrap cold-start ordering.
	 *
	 * @return int[]
	 */
	private static function cold_start_pool() {
		$query = new \WP_Query(
			array(
				'post_type'      => 'product',
				'post_status'    => 'publish',
				'posts_per_page' => 200,
				'meta_key'       => 'total_sales', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
				'orderby'        => 'meta_value_num',
				'order'          => 'DESC',
				'fields'         => 'ids',
				'no_found_rows'  => true,
			)
		);
		return is_array( $query->posts ) ? array_map( 'intval', $query->posts ) : array();
	}

	/**
	 * Write metadata about the most recent recompute (for editor diagnostics).
	 *
	 * @param int   $window     Days.
	 * @param array $weights    Resolved weights.
	 * @param int   $cached_n   Count of IDs cached.
	 * @param bool  $cold_start Whether cold-start fallback was used.
	 */
	private static function write_meta( $window, array $weights, $cached_n, $cold_start ) {
		update_option(
			self::META_KEY,
			array(
				'recomputed_at' => time(),
				'window_days'   => (int) $window,
				'weights'       => $weights,
				'cached_count'  => (int) $cached_n,
				'cold_start'    => (bool) $cold_start,
			),
			false
		);
	}
}
