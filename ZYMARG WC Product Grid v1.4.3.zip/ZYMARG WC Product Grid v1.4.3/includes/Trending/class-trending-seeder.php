<?php
/**
 * Cold-start seeder.
 *
 * On first activation, reads completed/processing orders from the last
 * 90 days and synthesises one cart_add event per ordered product line
 * dated to the order creation time. This bootstraps Trending so it's
 * sensible from day 1 on stores with existing sales history.
 *
 * @package Zymarg\WCPG
 */

namespace Zymarg\WCPG\Trending;

defined( 'ABSPATH' ) || exit;

/**
 * Class Trending_Seeder
 */
class Trending_Seeder {

	const LOOKBACK_DAYS = 90;
	const BATCH_SIZE    = 500;

	/**
	 * Seed the engagement store from historical orders.
	 *
	 * Runs in chunks to stay under typical PHP memory limits.
	 *
	 * @return int Synthetic events written.
	 */
	public static function run() {
		if ( ! function_exists( 'wc_get_orders' ) ) {
			return 0;
		}
		$after = gmdate( 'Y-m-d H:i:s', time() - ( self::LOOKBACK_DAYS * DAY_IN_SECONDS ) );

		$page    = 1;
		$written = 0;

		do {
			$orders = wc_get_orders(
				array(
					'limit'        => self::BATCH_SIZE,
					'paged'        => $page,
					'orderby'      => 'date',
					'order'        => 'ASC',
					'status'       => array( 'wc-completed', 'wc-processing' ),
					'date_created' => '>=' . $after,
					'type'         => 'shop_order',
					'return'       => 'ids',
				)
			);

			if ( empty( $orders ) || is_wp_error( $orders ) ) {
				break;
			}

			$events = array();
			foreach ( $orders as $order_id ) {
				$order = wc_get_order( $order_id );
				if ( ! $order ) {
					continue;
				}
				$ts = $order->get_date_created();
				$ts = $ts ? $ts->getTimestamp() : time();
				foreach ( $order->get_items() as $item ) {
					$pid = (int) $item->get_product_id();
					if ( $pid <= 0 ) {
						continue;
					}
					$events[] = array(
						'pid'   => $pid,
						'event' => 'cart_add',
						'ts'    => $ts,
					);
				}
			}

			if ( $events ) {
				Engagement_Store::record_events( $events );
				$written += count( $events );
			}

			++$page;

			if ( self::is_memory_pressured() ) {
				break;
			}
		} while ( count( $orders ) === self::BATCH_SIZE );

		return $written;
	}

	/**
	 * Whether we should bail out due to memory pressure.
	 *
	 * @return bool
	 */
	private static function is_memory_pressured() {
		$limit = function_exists( 'wp_convert_hr_to_bytes' ) ? wp_convert_hr_to_bytes( ini_get( 'memory_limit' ) ) : 0;
		if ( $limit <= 0 ) {
			return false;
		}
		return memory_get_usage( true ) / $limit > 0.85;
	}
}
