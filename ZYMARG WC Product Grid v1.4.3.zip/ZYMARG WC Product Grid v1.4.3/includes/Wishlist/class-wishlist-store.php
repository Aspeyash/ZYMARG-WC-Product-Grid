<?php
/**
 * Wishlist storage layer.
 *
 * Storage handshake (per locked spec):
 *   - Logged-in: update_user_meta('_zymarg_wishlist', [ids])
 *   - Guest:     cookie 'zymarg_wl' + WC session mirror
 *
 * Phase 3A ships read access plus public mutators. The mutators are used
 * now by the login-merge hook; the AJAX handler that lets visitors toggle
 * wishlist state from the heart button lands in Phase 4.
 *
 * @package Zymarg\WCPG
 */

namespace Zymarg\WCPG\Wishlist;

defined( 'ABSPATH' ) || exit;

/**
 * Class Wishlist_Store
 */
class Wishlist_Store {

	const COOKIE_NAME   = 'zymarg_wl';
	const SESSION_KEY   = 'zymarg_wl';
	const USER_META_KEY = '_zymarg_wishlist';
	const COOKIE_TTL    = YEAR_IN_SECONDS;

	/**
	 * Get the wishlist for the current visitor.
	 *
	 * @return int[]
	 */
	public static function get_ids() {
		if ( is_user_logged_in() ) {
			$ids = get_user_meta( get_current_user_id(), self::USER_META_KEY, true );
			return is_array( $ids ) ? self::sanitize_ids( $ids ) : array();
		}

		if ( ! empty( $_COOKIE[ self::COOKIE_NAME ] ) ) {
			$raw = (string) wp_unslash( $_COOKIE[ self::COOKIE_NAME ] );
			// Hard cap before json_decode: browsers cap cookies at ~4 KB anyway,
			// so any larger payload is either corrupt or hostile. Skip it cheaply
			// instead of letting json_decode burn CPU on a megabyte of garbage.
			if ( strlen( $raw ) > 4096 ) {
				return array();
			}
			$decoded = json_decode( $raw, true );
			if ( is_array( $decoded ) ) {
				return self::sanitize_ids( $decoded );
			}
		}

		if ( function_exists( 'WC' ) && WC() && WC()->session ) {
			$session_ids = WC()->session->get( self::SESSION_KEY );
			if ( is_array( $session_ids ) ) {
				return self::sanitize_ids( $session_ids );
			}
		}

		return array();
	}

	/**
	 * Whether a product is in the visitor's wishlist.
	 *
	 * @param int $product_id Product ID.
	 * @return bool
	 */
	public static function has( $product_id ) {
		$product_id = (int) $product_id;
		return $product_id > 0 && in_array( $product_id, self::get_ids(), true );
	}

	/**
	 * Add a product to the wishlist.
	 *
	 * @param int $product_id Product ID.
	 * @return int[]
	 */
	public static function add( $product_id ) {
		$product_id = (int) $product_id;
		if ( $product_id <= 0 ) {
			return self::get_ids();
		}
		$ids = self::get_ids();
		if ( ! in_array( $product_id, $ids, true ) ) {
			$ids[] = $product_id;
			self::write( $ids );
		}
		return $ids;
	}

	/**
	 * Remove a product from the wishlist.
	 *
	 * @param int $product_id Product ID.
	 * @return int[]
	 */
	public static function remove( $product_id ) {
		$product_id = (int) $product_id;
		if ( $product_id <= 0 ) {
			return self::get_ids();
		}
		$ids = array_values( array_diff( self::get_ids(), array( $product_id ) ) );
		self::write( $ids );
		return $ids;
	}

	/**
	 * Replace the wishlist with the supplied IDs.
	 *
	 * @param int[] $ids Product IDs.
	 */
	public static function set( array $ids ) {
		self::write( self::sanitize_ids( $ids ) );
	}

	/**
	 * Persist the list.
	 *
	 * @param int[] $ids Sanitized IDs.
	 */
	private static function write( array $ids ) {
		$ids = self::sanitize_ids( $ids );

		if ( is_user_logged_in() ) {
			update_user_meta( get_current_user_id(), self::USER_META_KEY, $ids );
		} elseif ( ! headers_sent() ) {
			$value = wp_json_encode( $ids );
			setcookie(
				self::COOKIE_NAME,
				(string) $value,
				array(
					'expires'  => time() + self::COOKIE_TTL,
					'path'     => COOKIEPATH ? COOKIEPATH : '/',
					'domain'   => COOKIE_DOMAIN ? COOKIE_DOMAIN : '',
					'secure'   => is_ssl(),
					'httponly' => false,
					'samesite' => 'Lax',
				)
			);
			$_COOKIE[ self::COOKIE_NAME ] = $value;
		}

		if ( function_exists( 'WC' ) && WC() && WC()->session ) {
			WC()->session->set( self::SESSION_KEY, $ids );
		}
	}

	/**
	 * Sanitize an ID list.
	 *
	 * @param array $ids Raw IDs.
	 * @return int[]
	 */
	private static function sanitize_ids( $ids ) {
		$ids = array_map( 'intval', (array) $ids );
		$ids = array_filter(
			$ids,
			static function ( $i ) {
				return $i > 0;
			}
		);
		return array_values( array_unique( $ids ) );
	}
}
