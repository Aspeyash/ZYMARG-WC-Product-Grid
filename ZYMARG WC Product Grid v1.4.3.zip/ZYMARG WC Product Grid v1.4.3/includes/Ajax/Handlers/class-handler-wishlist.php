<?php
/**
 * Wishlist AJAX handler.
 *
 * @package Zymarg\WCPG
 */

namespace Zymarg\WCPG\Ajax\Handlers;

defined( 'ABSPATH' ) || exit;

use Zymarg\WCPG\Ajax\Handler_Base;
use Zymarg\WCPG\Trending\Event_Buffer;
use Zymarg\WCPG\Wishlist\Wishlist_Store;

/**
 * Class Handler_Wishlist
 */
class Handler_Wishlist extends Handler_Base {

	/** @inheritDoc */
	public function action_key() {
		return 'wishlist';
	}

	/** @inheritDoc */
	protected function handle() {
		$op         = $this->post( 'op' );
		$product_id = $this->post_int( 'product_id' );

		if ( ! in_array( $op, array( 'add', 'remove', 'toggle' ), true ) ) {
			$this->send_error( __( 'Invalid operation.', 'zymarg-wcpg' ), 400 );
		}

		$product = wc_get_product( $product_id );
		if ( ! $product || ! $product->is_visible() ) {
			$this->send_error( __( 'Product not found.', 'zymarg-wcpg' ), 404 );
		}

		$was_in = Wishlist_Store::has( $product_id );
		$is_in  = $was_in;

		switch ( $op ) {
			case 'add':
				Wishlist_Store::add( $product_id );
				$is_in = true;
				break;
			case 'remove':
				Wishlist_Store::remove( $product_id );
				$is_in = false;
				break;
			case 'toggle':
				if ( $was_in ) {
					Wishlist_Store::remove( $product_id );
					$is_in = false;
				} else {
					Wishlist_Store::add( $product_id );
					$is_in = true;
				}
				break;
		}

		// Track wishlist_add events for trending (only the add direction).
		if ( $is_in && ! $was_in ) {
			Event_Buffer::push( $product_id, 'wishlist_add', self::ip_hash() );
		}

		$ids = Wishlist_Store::get_ids();
		$this->send_success(
			array(
				'product_id'  => $product_id,
				'in_wishlist' => $is_in,
				'count'       => count( $ids ),
				'message'     => $is_in
					? __( 'Added to wishlist', 'zymarg-wcpg' )
					: __( 'Removed from wishlist', 'zymarg-wcpg' ),
			)
		);
	}
}
