<?php
/**
 * Search Cards handler.
 *
 * Receives an ordered list of product IDs (sourced from Algolia by the
 * browser) and returns server-rendered product-card HTML using the real
 * product-card.php template — so Quick View, Add to Cart, Wishlist, badges,
 * and every other card feature works identically to the Elementor widget.
 *
 * Called by the custom Algolia search results page (zymarg-search-results)
 * after it has resolved product IDs from Algolia's REST API.
 *
 * v1.3.12: $settings array updated to include ALL keys introduced since
 * v1.3.5 so the search results page inherits every feature automatically:
 *   - quickview_visibility  (v1.3.8)  — all devices on search page
 *   - show_vendor           (v1.3.6)  — yes (matches widget default)
 *   - vendor_position       (v1.3.9)  — below_title
 *   - vendor_display        (v1.3.6)  — avatar_name
 *   - vendor_link           (v1.3.6)  — yes
 *   - vendor_avatar_size    (v1.3.6)  — 24px
 *   - price_position        (v1.3.7)  — below_rating
 *   - show_rating           (v1.3.7)  — yes
 *   - show_sold_count       (v1.3.7)  — yes
 *   - sold_count_format     (v1.3.7)  — sold_n
 *   - meta_layout           (v1.3.7)  — inline
 *
 * @package Zymarg\WCPG
 */

namespace Zymarg\WCPG\Ajax\Handlers;

defined( 'ABSPATH' ) || exit;

use Zymarg\WCPG\Ajax\Handler_Base;
use Zymarg\WCPG\Template_Loader;

/**
 * Class Handler_Search_Cards
 */
class Handler_Search_Cards extends Handler_Base {

	/** @inheritDoc */
	public function action_key() {
		return 'search_cards';
	}

	/** @inheritDoc */
	public function allows_guests() {
		return true;
	}

	/** @inheritDoc */
	protected function handle() {

		// Sanitize incoming product ID list.
		$raw_ids = isset( $_POST['product_ids'] ) ? wp_unslash( $_POST['product_ids'] ) : array(); // phpcs:ignore WordPress.Security.NonceVerification.Missing
		if ( ! is_array( $raw_ids ) ) {
			$raw_ids = array_filter( array_map( 'trim', explode( ',', (string) $raw_ids ) ) );
		}
		$product_ids = array_values( array_filter( array_map( 'absint', $raw_ids ) ) );

		if ( empty( $product_ids ) ) {
			$this->send_error( __( 'No product IDs provided.', 'zymarg-wcpg' ), 400 );
		}

		// Cap at 80 to mirror the HTML page maxHits config.
		$product_ids = array_slice( $product_ids, 0, 80 );

		// ── Default display settings ──────────────────────────────────────
		//
		// These are the canonical search-results-page defaults. Every key
		// that exists in product-card.php MUST be listed here so the
		// template never silently falls back to a hardcoded value.
		//
		// When you add a new Elementor setting to the widget, add its
		// search-page default here too. Keep in sync with card template.
		$settings = array(

			// ── Image ───────────────────────────────────────────────────
			'show_image'            => 'yes',
			'image_hover_zoom'      => 'yes',
			'image_full_resolution' => 'no',

			// ── Badges ──────────────────────────────────────────────────
			'show_discount_badge'   => 'yes',
			'show_stock_badge'      => 'yes',

			// ── Wishlist ─────────────────────────────────────────────────
			'show_wishlist'         => 'yes',
			'wishlist_icon'         => null,
			'wishlist_icon_active'  => null,

			// ── Quick View (v1.3.8: visibility key added) ────────────────
			// 'all' = visible on every device on the search results page.
			// The search page is a standalone experience (not an Elementor
			// widget), so showing quickview everywhere makes sense here.
			'show_quickview'        => 'yes',
			'quickview_visibility'  => 'all',
			// v1.3.25: display style. 'always' keeps the existing search
			// page UX (icon always visible). The Elementor grid widget
			// defaults to 'hover_only' separately.
			'quickview_display'     => 'always',
			'quickview_icon'        => null,

			// ── Add to Cart ──────────────────────────────────────────────
			'show_atc'              => 'yes',
			'atc_icon'              => null,

			// ── Title ────────────────────────────────────────────────────
			'show_title'            => 'yes',

			// ── Vendor profile (v1.3.6 / v1.3.9 / v1.3.10 / v1.3.19) ─────
			// Matches the Elementor widget defaults — vendor visible,
			// avatar + name display, linked to store, 24px avatar,
			// left side, circle shape, no border.
			'show_vendor'           => 'yes',
			'vendor_position'       => 'below_title',
			'vendor_display'        => 'avatar_name',
			'vendor_link'           => 'yes',
			'vendor_avatar_size'    => array( 'size' => 24, 'unit' => 'px' ),
			'vendor_avatar_side'    => 'left',
			'vendor_avatar_shape'   => 'circle',
			'vendor_avatar_border'  => '',

			// ── Price (v1.3.7: position key added) ───────────────────────
			'show_price'            => 'yes',
			'price_position'        => 'below_rating',

			// ── Rating & Sold Count (v1.3.7: layout + format keys added) ─
			'show_rating'           => 'yes',
			'show_sold_count'       => 'yes',
			'sold_count_format'     => 'sold_n',
			'meta_layout'           => 'inline',
			// v1.4.2: responsive meta_layout + show_sold_text defaults
			// matching the Elementor control defaults. Search page mirrors
			// the homepage UX (inline 5-star on desktop, indicator + no
			// "Sold" word on mobile).
			'meta_layout_tablet'    => 'inline',
			'meta_layout_mobile'    => 'count_indicator',
			'show_sold_text'        => 'yes',
			'show_sold_text_tablet' => 'yes',
			'show_sold_text_mobile' => '',
		);

		// Allow optional per-request settings override from the POST body.
		// The search page JS can pass settings[] to customise behaviour
		// without needing a code change here (Option B escape hatch).
		// Only keys already declared in $settings above are accepted.
		if ( ! empty( $_POST['settings'] ) && is_array( $_POST['settings'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
			$allowed = array_keys( $settings );
			foreach ( $_POST['settings'] as $key => $val ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
				if ( in_array( $key, $allowed, true ) ) {
					$settings[ $key ] = sanitize_text_field( wp_unslash( $val ) );
				}
			}
		}

		$html = '';
		foreach ( $product_ids as $product_id ) {
			$product = wc_get_product( $product_id );
			if ( ! $product instanceof \WC_Product || ! $product->is_visible() ) {
				continue;
			}
			$html .= Template_Loader::get_template_html(
				'grid/product-card.php',
				array(
					'product'   => $product,
					'settings'  => $settings,
					'widget_id' => 'zymarg-search-results',
				)
			);
		}

		if ( '' === $html ) {
			$this->send_error( __( 'No visible products found.', 'zymarg-wcpg' ), 404 );
		}

		$this->send_success( array( 'html' => $html ) );
	}
}
