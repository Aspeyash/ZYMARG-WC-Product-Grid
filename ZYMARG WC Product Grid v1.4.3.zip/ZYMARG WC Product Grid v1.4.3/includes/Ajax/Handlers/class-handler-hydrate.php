<?php
/**
 * Cache-safe state hydration.
 *
 * Returns the visitor-specific wishlist IDs (and recently-viewed IDs)
 * so client JS can hydrate icon state on cached pages where the
 * server-rendered HTML may have been generated for a different visitor.
 *
 * @package Zymarg\WCPG
 */

namespace Zymarg\WCPG\Ajax\Handlers;

defined( 'ABSPATH' ) || exit;

use Zymarg\WCPG\Ajax\Handler_Base;
use Zymarg\WCPG\Tracking\Recently_Viewed;
use Zymarg\WCPG\Wishlist\Wishlist_Store;

/**
 * Class Handler_Hydrate
 */
class Handler_Hydrate extends Handler_Base {

	/** @inheritDoc */
	public function action_key() {
		return 'hydrate';
	}

	/** @inheritDoc */
	protected function handle() {
		nocache_headers();
		header( 'Cache-Control: no-store, max-age=0, private', true );

		$wishlist = Wishlist_Store::get_ids();
		$recent   = Recently_Viewed::get_ids();

		$this->send_success(
			array(
				'wishlist_ids'   => array_map( 'intval', $wishlist ),
				'recent_ids'     => array_map( 'intval', $recent ),
				'wishlist_count' => count( $wishlist ),
			)
		);
	}
}
