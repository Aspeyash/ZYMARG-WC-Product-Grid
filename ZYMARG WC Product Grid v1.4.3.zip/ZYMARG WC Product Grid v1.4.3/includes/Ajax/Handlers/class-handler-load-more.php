<?php
/**
 * Load More pagination handler.
 *
 * Returns rendered card markup for the next page of a widget instance.
 *
 * @package Zymarg\WCPG
 */

namespace Zymarg\WCPG\Ajax\Handlers;

defined( 'ABSPATH' ) || exit;

use Zymarg\WCPG\Ajax\Handler_Base;
use Zymarg\WCPG\Query\Query_Builder;
use Zymarg\WCPG\Query\Source_Base;
use Zymarg\WCPG\Template_Loader;

/**
 * Class Handler_Load_More
 */
class Handler_Load_More extends Handler_Base {

	/** @inheritDoc */
	public function action_key() {
		return 'load_more';
	}

	/** @inheritDoc */
	protected function handle() {
		$page     = max( 2, $this->post_int( 'page' ) );
		$settings = $this->read_settings();

		$raw_total = isset( $settings['total_products'] ) ? (int) $settings['total_products'] : 8;

		// Unlimited mode (0) renders everything in one shot, so there is
		// nothing left to paginate. Return an empty payload so the JS
		// removes the Load More button cleanly.
		if ( $raw_total <= 0 ) {
			$this->send_success(
				array(
					'html'     => '',
					'page'     => $page,
					'has_more' => false,
				)
			);
		}

		$per_page            = max( 1, $raw_total );
		$settings['_offset'] = ( $page - 1 ) * $per_page;
		$settings['_paged']  = $page;

		// For Algolia source: pass the search query explicitly so Source_Algolia
		// can resolve it without relying on get_search_query() (which returns
		// empty in an AJAX context). The query is read from the POST payload
		// that the load-more button emits via data-algolia-query.
		if ( 'algolia' === ( $settings['source'] ?? '' ) ) {
			$algolia_query = isset( $_POST['algolia_query'] ) // phpcs:ignore WordPress.Security.NonceVerification.Missing
				? sanitize_text_field( wp_unslash( $_POST['algolia_query'] ) ) // phpcs:ignore WordPress.Security.NonceVerification.Missing
				: '';
			$settings['_algolia_query'] = $algolia_query;
		}

		// For Category source: pass the term ID explicitly so Source_Category
		// can resolve it without relying on get_queried_object() (which returns
		// nothing in an AJAX context). The term ID is read from the POST
		// payload that the load-more button emits via data-category-term-id.
		if ( 'category' === ( $settings['source'] ?? '' ) ) {
			$category_term_id = isset( $_POST['category_term_id'] ) // phpcs:ignore WordPress.Security.NonceVerification.Missing
				? absint( wp_unslash( $_POST['category_term_id'] ) ) // phpcs:ignore WordPress.Security.NonceVerification.Missing
				: 0;
			$settings['_category_term_id'] = $category_term_id;
		}

		// Add a transient filter so any source built on Source_All / WP_Query
		// honours the offset.
		$offset_filter = static function ( $args ) use ( $settings ) {
			$args['offset'] = (int) $settings['_offset'];
			return $args;
		};
		add_filter( 'zymarg_wcpg_query_args', $offset_filter );

		$result = Query_Builder::get_products( $settings );

		remove_filter( 'zymarg_wcpg_query_args', $offset_filter );

		// HIDE_WIDGET sentinel from sources like Similar/Vendor.
		if ( Source_Base::HIDE_WIDGET === $result || empty( $result ) ) {
			$this->send_success(
				array(
					'html'     => '',
					'page'     => $page,
					'has_more' => false,
				)
			);
		}

		$widget_id = (string) $this->post( 'widget_id' );

		ob_start();
		foreach ( $result as $product ) {
			if ( ! ( $product instanceof \WC_Product ) ) {
				continue;
			}
			Template_Loader::get_template(
				'grid/product-card.php',
				array(
					'product'   => $product,
					'settings'  => $settings,
					'widget_id' => $widget_id,
				)
			);
		}
		$html = (string) ob_get_clean();

		$this->send_success(
			array(
				'html'     => $html,
				'page'     => $page,
				'has_more' => $this->resolve_has_more( $settings, $result, $per_page, $page ),
			)
		);
	}

	/**
	 * Determine whether more pages exist.
	 *
	 * For Algolia source, use nb_hits from the filter rather than comparing
	 * the count of returned products (which would always equal per_page until
	 * the last page, hiding whether there really is a next page).
	 *
	 * @param array  $settings Widget settings.
	 * @param array  $result   Products returned by the source.
	 * @param int    $per_page Products per page.
	 * @param int    $page     Current (1-based) page number.
	 * @return bool
	 */
	private function resolve_has_more( array $settings, array $result, $per_page, $page ) {
		if ( 'algolia' === ( $settings['source'] ?? '' ) ) {
			$nb_hits = (int) apply_filters( 'zymarg_wcpg_algolia_nb_hits', 0 );
			if ( $nb_hits > 0 ) {
				return ( $page * $per_page ) < $nb_hits;
			}
		}
		return count( $result ) >= $per_page;
	}

	/**
	 * Read whitelisted settings keys from POST.
	 *
	 * Only keys that affect query shape and card rendering are accepted.
	 *
	 * @return array
	 */
	private function read_settings() {
		$allowed = array(
			'source',
			'total_products',
			'orderby',
			'order',
			'show_oos',
			'columns',
			'show_image',
			'show_discount_badge',
			'show_stock_badge',
			'show_wishlist',
			'show_quickview',
			'show_atc',
			'show_title',
			'show_rating',
			'show_sold_count',
			'show_price',
			'discount_badge_mode',
			'image_full_resolution',
			'image_hover_zoom',
			'show_stock_in',
			'show_stock_out',
			'title_lines',
			'sold_count_format',
			'algolia_query',       // passed by load-more button for Algolia source.
			'category_term_id',    // passed by load-more button for Category source.
		);

		$settings = array();
		foreach ( $allowed as $key ) {
			if ( ! isset( $_POST[ $key ] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
				continue;
			}
			$value            = wp_unslash( $_POST[ $key ] ); // phpcs:ignore WordPress.Security.NonceVerification.Missing
			$settings[ $key ] = is_array( $value )
				? array_map( 'sanitize_text_field', $value )
				: sanitize_text_field( $value );
		}

		// Allow 0 (= unlimited) to pass through; positive values capped at 100.
		if ( isset( $settings['total_products'] ) ) {
			$tp = (int) $settings['total_products'];
			$settings['total_products'] = $tp <= 0 ? 0 : min( 100, max( 1, $tp ) );
		} else {
			$settings['total_products'] = 8;
		}

		return $settings;
	}
}
