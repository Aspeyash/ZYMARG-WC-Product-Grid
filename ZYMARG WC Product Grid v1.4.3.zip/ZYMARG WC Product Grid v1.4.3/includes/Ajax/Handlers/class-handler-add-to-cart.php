<?php
/**
 * AJAX add-to-cart handler.
 *
 * Phase 4: simple products only.
 * Phase 5: extended to accept variation_id + variation attributes
 *          (used by the Quick View modal).
 *
 * @package Zymarg\WCPG
 */

namespace Zymarg\WCPG\Ajax\Handlers;

defined( 'ABSPATH' ) || exit;

use Zymarg\WCPG\Ajax\Handler_Base;
use Zymarg\WCPG\Trending\Event_Buffer;

/**
 * Class Handler_Add_To_Cart
 */
class Handler_Add_To_Cart extends Handler_Base {

	/** @inheritDoc */
	public function action_key() {
		return 'add_to_cart';
	}

	/** @inheritDoc */
	protected function handle() {
		$product_id   = $this->post_int( 'product_id' );
		$variation_id = $this->post_int( 'variation_id' );
		$quantity     = max( 1, $this->post_int( 'quantity' ) );
		$variation    = isset( $_POST['variation'] ) && is_array( $_POST['variation'] ) // phpcs:ignore WordPress.Security.NonceVerification.Missing
			? array_map( 'sanitize_text_field', wp_unslash( $_POST['variation'] ) ) // phpcs:ignore WordPress.Security.NonceVerification.Missing
			: array();

		// WooCommerce does not load the cart/session automatically for
		// AJAX requests in WC 7.0+ (especially with HPOS enabled).
		// wc_load_cart() initialises WC()->cart, WC()->customer, and
		// WC()->session so add_to_cart() works correctly outside of a
		// standard page load. Safe to call multiple times - WC guards it.
		if ( function_exists( 'wc_load_cart' ) ) {
			wc_load_cart();
		}

		if ( ! function_exists( 'WC' ) || ! WC() || ! WC()->cart ) {
			$this->send_error( __( 'Cart is not available.', 'zymarg-wcpg' ), 503 );
		}

		$product = wc_get_product( $product_id );
		if ( ! $product || ! $product->is_visible() ) {
			$this->send_error( __( 'Product not found.', 'zymarg-wcpg' ), 404 );
		}

		// Variable product: require a variation_id + attributes (from Quick View).
		if ( $product->is_type( 'variable' ) ) {
			if ( $variation_id <= 0 ) {
				$this->send_error( __( 'Please select all options.', 'zymarg-wcpg' ), 400 );
			}
			$variation_product = wc_get_product( $variation_id );
			if ( ! $variation_product || ! $variation_product->is_purchasable() || ! $variation_product->is_in_stock() ) {
				$this->send_error( __( 'Variation is not available.', 'zymarg-wcpg' ), 400 );
			}
		} else {
			if ( ! $product->is_type( 'simple' ) ) {
				$this->send_error( __( 'Please choose options on the product page.', 'zymarg-wcpg' ), 400 );
			}
			if ( ! $product->is_purchasable() ) {
				$this->send_error( __( 'This product cannot be purchased.', 'zymarg-wcpg' ), 400 );
			}
			if ( ! $product->is_in_stock() ) {
				$this->send_error( __( 'Out of stock.', 'zymarg-wcpg' ), 400 );
			}
		}

		$key = WC()->cart->add_to_cart( $product_id, $quantity, $variation_id, $variation );
		if ( ! $key ) {
			$this->send_error( __( 'Could not add to cart.', 'zymarg-wcpg' ), 400 );
		}

		Event_Buffer::push( $product_id, 'cart_add', self::ip_hash() );

		ob_start();
		woocommerce_mini_cart();
		$mini_cart = ob_get_clean();

		$fragments = apply_filters(
			'woocommerce_add_to_cart_fragments',
			array(
				'div.widget_shopping_cart_content' => '<div class="widget_shopping_cart_content">' . $mini_cart . '</div>',
			)
		);

		$this->send_success(
			array(
				'product_id' => $product_id,
				'cart_count' => WC()->cart->get_cart_contents_count(),
				'cart_total' => wp_kses_post( WC()->cart->get_cart_total() ),
				'cart_hash'  => WC()->cart->get_cart_hash(),
				'fragments'  => $fragments,
				'message'    => __( 'Added to cart', 'zymarg-wcpg' ),
			)
		);
	}
}
