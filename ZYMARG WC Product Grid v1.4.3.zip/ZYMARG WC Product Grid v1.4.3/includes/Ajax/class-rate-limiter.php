<?php
/**
 * Per-IP rate limiter using WordPress transients.
 *
 * @package Zymarg\WCPG
 */

namespace Zymarg\WCPG\Ajax;

defined( 'ABSPATH' ) || exit;

/**
 * Class Rate_Limiter
 */
class Rate_Limiter {

	const PREFIX = 'zymarg_rl_';

	/**
	 * Default per-action limits. Overridable via filter.
	 *
	 * @return array<string,array{window:int,max:int}>
	 */
	public static function defaults() {
		return array(
			'wishlist'    => array(
				'window' => 60,
				'max'    => 30,
			),
			'add_to_cart' => array(
				'window' => 60,
				'max'    => 20,
			),
			'quick_view'  => array(
				'window' => 60,
				'max'    => 60,
			),
			'buy_now'     => array(
				'window' => 60,
				'max'    => 10,
			),
			'track_click' => array(
				'window' => 60,
				'max'    => 120,
			),
			'hydrate'     => array(
				'window' => 60,
				'max'    => 60,
			),
			'load_more'   => array(
				'window' => 60,
				'max'    => 30,
			),
		);
	}

	/**
	 * Resolve the (window, max) tuple for an action.
	 *
	 * @param string $action Action key.
	 * @return array{window:int,max:int}
	 */
	public static function get_limit( $action ) {
		$defaults = self::defaults();
		$config   = apply_filters( 'zymarg_wcpg_rate_limits', $defaults, $action );
		if ( isset( $config[ $action ] ) && is_array( $config[ $action ] ) ) {
			return array_merge(
				array(
					'window' => 60,
					'max'    => 30,
				),
				$config[ $action ]
			);
		}
		return array(
			'window' => 60,
			'max'    => 30,
		);
	}

	/**
	 * Check whether a request is allowed; if so, increment the counter.
	 *
	 * @param string $action Action key.
	 * @param string $ip     Client IP.
	 * @return bool True when allowed.
	 */
	public static function consume( $action, $ip ) {
		$limit = self::get_limit( $action );
		$key   = self::PREFIX . $action . '_' . sha1( (string) $ip . self::daily_salt() );
		$count = (int) get_transient( $key );

		if ( $count >= (int) $limit['max'] ) {
			return false;
		}

		set_transient( $key, $count + 1, (int) $limit['window'] );
		return true;
	}

	/**
	 * Daily-rotating salt so day boundaries naturally roll the buckets.
	 *
	 * @return string
	 */
	private static function daily_salt() {
		$today = wp_date( 'Y-m-d' );
		$salt  = (string) get_option( 'zymarg_wcpg_daily_salt', '' );
		if ( '' === $salt || strpos( $salt, $today ) !== 0 ) {
			$salt = $today . '|' . wp_generate_password( 16, false, false );
			update_option( 'zymarg_wcpg_daily_salt', $salt, false );
		}
		return $salt;
	}
}
