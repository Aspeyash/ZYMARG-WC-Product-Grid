<?php
/**
 * Quick View product data builder.
 *
 * Builds a lightweight payload describing a product for the Quick View
 * modal: gallery URLs, attributes typed via Variation Swatches for
 * WooCommerce (Emran Ahmed) when present, with graceful fallbacks for
 * stores not running that plugin.
 *
 * Type detection (in priority order):
 *   1. wc_get_attribute_taxonomies()->attribute_type
 *      (set by Emran Ahmed plugin: color / image / label / button / select)
 *   2. Slug-based heuristic for "color" / "colour" / "pa_color" / "pa_colour"
 *      => color type with hex pulled from term meta if present
 *   3. Anything else => select (rounded dropdown)
 *
 * Term-meta keys consulted (in this order, first match wins):
 *   color: product_attribute_color, _color, color, swatch_color
 *   image: product_attribute_image (attachment ID), _image, image
 *
 * @package Zymarg\WCPG
 */

namespace Zymarg\WCPG\QuickView;

defined( 'ABSPATH' ) || exit;

/**
 * Class QuickView_Data
 */
class QuickView_Data {

	/**
	 * Slugs that we treat as colour swatches even without explicit type.
	 *
	 * @return string[]
	 */
	public static function color_attribute_slugs() {
		return apply_filters(
			'zymarg_wcpg_color_attribute_slugs',
			array( 'color', 'colour', 'pa_color', 'pa_colour' )
		);
	}

	/**
	 * Build the product payload.
	 *
	 * @param \WC_Product $product Product instance.
	 * @return array
	 */
	public static function build( \WC_Product $product ) {
		$gallery_ids = array();
		if ( $product->get_image_id() ) {
			$gallery_ids[] = (int) $product->get_image_id();
		}
		foreach ( (array) $product->get_gallery_image_ids() as $gid ) {
			$gallery_ids[] = (int) $gid;
		}
		$gallery = array();
		foreach ( array_unique( array_filter( $gallery_ids ) ) as $gid ) {
			$src   = wp_get_attachment_image_src( $gid, 'large' );
			$thumb = wp_get_attachment_image_src( $gid, 'thumbnail' );
			if ( $src ) {
				$gallery[] = array(
					'large' => $src[0],
					'thumb' => $thumb ? $thumb[0] : $src[0],
				);
			}
		}
		if ( empty( $gallery ) ) {
			$placeholder = wc_placeholder_img_src( 'large' );
			$gallery[]   = array(
				'large' => $placeholder,
				'thumb' => $placeholder,
			);
		}

		$payload = array(
			'id'           => (int) $product->get_id(),
			'type'         => $product->get_type(),
			'name'         => $product->get_name(),
			'permalink'    => $product->get_permalink(),
			'price_html'   => $product->get_price_html(),
			'excerpt'      => self::get_excerpt( $product ),
			'rating'       => (float) $product->get_average_rating(),
			'rating_count' => (int) $product->get_rating_count(),
			'sold'         => (int) $product->get_total_sales(),
			'sku'          => $product->get_sku(),
			'in_stock'     => $product->is_in_stock(),
			'purchasable'  => $product->is_purchasable(),
			'gallery'      => $gallery,
			'is_variable'  => $product->is_type( 'variable' ),
			'attributes'   => array(),
			'variations'   => array(),
			'min_qty'      => 1,
			'max_qty'      => $product->get_max_purchase_quantity(),
		);

		if ( $product->is_type( 'variable' ) ) {
			$payload['attributes'] = self::build_attributes( $product );
			$payload['variations'] = self::build_variation_matrix( $product );
		}

		return $payload;
	}

	/**
	 * Short excerpt (post excerpt -> first 200 chars of description).
	 *
	 * @param \WC_Product $product Product.
	 * @return string Plain text.
	 */
	private static function get_excerpt( \WC_Product $product ) {
		$excerpt = $product->get_short_description();
		if ( ! $excerpt ) {
			$excerpt = $product->get_description();
		}
		$excerpt = wp_strip_all_tags( (string) $excerpt );
		if ( strlen( $excerpt ) > 200 ) {
			$excerpt = mb_substr( $excerpt, 0, 197 ) . '...';
		}
		return $excerpt;
	}

	/**
	 * Resolve the rendering type for an attribute name.
	 *
	 * Maps Emran Ahmed Variation Swatches plugin types to our internal
	 * vocabulary. Unknown / missing types fall back to 'select'.
	 *
	 * @param string $attribute_name Attribute name (e.g. 'pa_color' or 'pa_size').
	 * @return string One of: color, image, label, button, select.
	 */
	private static function resolve_attribute_type( $attribute_name ) {
		// Local (non-taxonomy) attributes have no registered type.
		if ( strpos( $attribute_name, 'pa_' ) !== 0 ) {
			return self::is_known_color_slug( $attribute_name ) ? 'color' : 'select';
		}

		if ( ! function_exists( 'wc_get_attribute_taxonomies' ) ) {
			return self::is_known_color_slug( $attribute_name ) ? 'color' : 'select';
		}

		$slug       = substr( $attribute_name, 3 ); // strip 'pa_'
		$taxonomies = wc_get_attribute_taxonomies();
		$detected   = null;
		if ( is_array( $taxonomies ) ) {
			foreach ( $taxonomies as $tax ) {
				if ( isset( $tax->attribute_name ) && $tax->attribute_name === $slug ) {
					$detected = isset( $tax->attribute_type ) ? (string) $tax->attribute_type : '';
					break;
				}
			}
		}

		if ( null === $detected ) {
			return self::is_known_color_slug( $attribute_name ) ? 'color' : 'select';
		}

		switch ( strtolower( $detected ) ) {
			case 'color':
			case 'colour':
				return 'color';
			case 'image':
			case 'photo':
				return 'image';
			case 'label':
			case 'text':
				return 'label';
			case 'button':
			case 'radio':
				return 'button';
			default:
				// Includes 'select' and anything we do not explicitly handle.
				return self::is_known_color_slug( $attribute_name ) ? 'color' : 'select';
		}
	}

	/**
	 * Whether the attribute slug matches a known colour-style slug.
	 *
	 * @param string $name Attribute slug (e.g. 'pa_color').
	 * @return bool
	 */
	private static function is_known_color_slug( $name ) {
		$slugs = array_map( 'strtolower', self::color_attribute_slugs() );
		return in_array( strtolower( (string) $name ), $slugs, true );
	}

	/**
	 * Read swatch metadata for a single term.
	 *
	 * @param \WP_Term|null $term Term object.
	 * @param string        $type Resolved attribute type.
	 * @return array{color:string,image:string}
	 */
	private static function read_swatch_data( $term, $type ) {
		$out = array(
			'color' => '',
			'image' => '',
		);
		if ( ! $term || ! is_object( $term ) ) {
			return $out;
		}

		if ( 'color' === $type ) {
			$keys = array( 'product_attribute_color', '_color', 'color', 'swatch_color' );
			foreach ( $keys as $key ) {
				$val = get_term_meta( $term->term_id, $key, true );
				if ( is_string( $val ) && '' !== trim( $val ) ) {
					$val = trim( $val );
					if ( '#' !== $val[0] ) {
						$val = '#' . $val;
					}
					if ( preg_match( '/^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/', $val ) ) {
						$out['color'] = $val;
						break;
					}
				}
			}
			// Fallback: term description starting with #.
			if ( '' === $out['color'] ) {
				$desc = trim( (string) $term->description );
				if ( '' !== $desc && '#' === $desc[0] && preg_match( '/^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/', $desc ) ) {
					$out['color'] = $desc;
				}
			}
		}

		if ( 'image' === $type ) {
			$keys = array( 'product_attribute_image', '_image', 'image' );
			foreach ( $keys as $key ) {
				$val = get_term_meta( $term->term_id, $key, true );
				if ( $val ) {
					$src = wp_get_attachment_image_src( (int) $val, 'thumbnail' );
					if ( $src && ! empty( $src[0] ) ) {
						$out['image'] = $src[0];
						break;
					}
				}
			}
		}

		return $out;
	}

	/**
	 * Build the visible (variation-defining) attribute list with type info.
	 *
	 * @param \WC_Product_Variable $product Variable product.
	 * @return array
	 */
	private static function build_attributes( $product ) {
		$attributes = array();

		foreach ( $product->get_variation_attributes() as $name => $options ) {
			$slug     = sanitize_title( $name );
			$tax_name = strpos( $slug, 'pa_' ) === 0 ? $slug : '';
			$label    = wc_attribute_label( $name, $product );
			$type     = self::resolve_attribute_type( $tax_name ? $tax_name : $slug );

			$values = array();
			foreach ( (array) $options as $option_value ) {
				$term_label   = $option_value;
				$swatch_color = '';
				$swatch_image = '';

				if ( $tax_name && taxonomy_exists( $tax_name ) ) {
					$term = get_term_by( 'slug', $option_value, $tax_name );
					if ( $term && ! is_wp_error( $term ) ) {
						$term_label = $term->name;
						$swatch     = self::read_swatch_data( $term, $type );
						$swatch_color = $swatch['color'];
						$swatch_image = $swatch['image'];
					}
				}

				$values[] = array(
					'value'        => (string) $option_value,
					'label'        => (string) $term_label,
					'swatch_color' => (string) $swatch_color,
					'swatch_image' => (string) $swatch_image,
				);
			}

			$attributes[] = array(
				'name'   => 'attribute_' . $slug,
				'slug'   => $slug,
				'label'  => (string) $label,
				'type'   => $type,
				'values' => $values,
			);
		}

		return $attributes;
	}

	/**
	 * Build a flat variation matrix for client-side resolution.
	 *
	 * @param \WC_Product_Variable $product Variable product.
	 * @return array
	 */
	private static function build_variation_matrix( $product ) {
		$matrix = array();
		foreach ( $product->get_available_variations() as $variation ) {
			if ( empty( $variation['variation_id'] ) ) {
				continue;
			}
			$matrix[] = array(
				'variation_id' => (int) $variation['variation_id'],
				'attributes'   => isset( $variation['attributes'] ) ? (array) $variation['attributes'] : array(),
				'price_html'   => isset( $variation['price_html'] ) ? wp_kses_post( $variation['price_html'] ) : '',
				'image'        => isset( $variation['image']['src'] ) ? esc_url_raw( $variation['image']['src'] ) : '',
				'image_thumb'  => isset( $variation['image']['thumb_src'] ) ? esc_url_raw( $variation['image']['thumb_src'] ) : '',
				'in_stock'     => ! empty( $variation['is_in_stock'] ),
				'purchasable'  => ! empty( $variation['is_purchasable'] ),
				'max_qty'      => isset( $variation['max_qty'] ) ? (int) $variation['max_qty'] : 0,
				'sku'          => isset( $variation['sku'] ) ? (string) $variation['sku'] : '',
			);
		}
		return $matrix;
	}
}
