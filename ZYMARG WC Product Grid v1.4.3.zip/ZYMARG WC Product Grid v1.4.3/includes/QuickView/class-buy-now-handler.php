<?php
/**
 * Buy Now state machine.
 *
 * Locked flow:
 *   1. User clicks Buy Now in Quick View
 *   2. Server snapshots WC()->cart into session, empties cart, adds the
 *      chosen product/variation, returns checkout URL with a 15-min token
 *   3. On woocommerce_thankyou: restore the original cart minus the bought
 *      item; clear session keys
 *   4. On any non-checkout page load with active token: restore (abandon)
 *   5. On token expiry: restore on next request
 *
 * Storage: WC()->session keys (per locked decision).
 *
 * @package Zymarg\WCPG
 */

namespace Zymarg\WCPG\QuickView;

defined( 'ABSPATH' ) || exit;

/**
 * Class BuyNow_Handler
 */
class BuyNow_Handler {

	const SESSION_BACKUP = 'zymarg_cart_backup';
	const SESSION_TOKEN  = 'zymarg_buy_now_token';
	const SESSION_DONE   = 'zymarg_buy_now_completed';
	const TOKEN_TTL      = 900; // 15 minutes
	const URL_PARAM      = 'zymarg_bn';

	/**
	 * Wire restore + completion hooks.
	 */
	public function register() {
		add_action( 'woocommerce_thankyou', array( $this, 'on_order_complete' ), 5, 1 );
		add_action( 'template_redirect', array( $this, 'maybe_restore_on_abandon' ), 99 );
	}

	/**
	 * Initiate the Buy Now flow.
	 *
	 * @param int   $product_id      Product ID.
	 * @param int   $variation_id    Variation ID (0 for simple).
	 * @param array $variation_attrs Variation attributes.
	 * @param int   $quantity        Quantity.
	 * @return array|\WP_Error { token, redirect } on success.
	 */
	public function initiate( $product_id, $variation_id = 0, $variation_attrs = array(), $quantity = 1 ) {
		if ( ! function_exists( 'WC' ) || ! WC() || ! WC()->cart || ! WC()->session ) {
			return new \WP_Error( 'zymarg_no_cart', __( 'Cart is not available.', 'zymarg-wcpg' ) );
		}

		$product = wc_get_product( $product_id );
		if ( ! $product || ! $product->is_visible() || ! $product->is_purchasable() ) {
			return new \WP_Error( 'zymarg_invalid_product', __( 'Product is not purchasable.', 'zymarg-wcpg' ) );
		}

		// Stale prior buy-now state? Restore it before starting fresh.
		if ( $this->has_active_token() ) {
			$this->restore_now();
		}

		// Snapshot current cart.
		$backup = $this->snapshot_cart();
		WC()->session->set( self::SESSION_BACKUP, $backup );

		// Empty cart and add only the chosen item.
		WC()->cart->empty_cart();

		$key = WC()->cart->add_to_cart(
			(int) $product_id,
			max( 1, (int) $quantity ),
			(int) $variation_id,
			(array) $variation_attrs
		);

		if ( ! $key ) {
			$this->restore_from_backup( $backup );
			WC()->session->set( self::SESSION_BACKUP, null );
			return new \WP_Error( 'zymarg_add_failed', __( 'Could not add product to cart.', 'zymarg-wcpg' ) );
		}

		// Issue token.
		$token = wp_generate_password( 32, false, false );
		WC()->session->set(
			self::SESSION_TOKEN,
			array(
				'token'        => $token,
				'product_id'   => (int) $product_id,
				'variation_id' => (int) $variation_id,
				'expires_at'   => time() + self::TOKEN_TTL,
			)
		);
		WC()->session->set( self::SESSION_DONE, false );

		$url = add_query_arg( self::URL_PARAM, $token, wc_get_checkout_url() );
		return array(
			'token'    => $token,
			'redirect' => $url,
		);
	}

	/**
	 * Order completed via Buy Now: restore the original cart.
	 *
	 * @param int $order_id Order ID.
	 */
	public function on_order_complete( $order_id ) {
		if ( ! function_exists( 'WC' ) || ! WC()->session ) {
			return;
		}
		if ( ! $this->has_active_token() ) {
			return;
		}

		$backup = WC()->session->get( self::SESSION_BACKUP );
		if ( is_array( $backup ) ) {
			WC()->cart->empty_cart();
			$this->restore_from_backup( $backup );
		}

		WC()->session->set( self::SESSION_BACKUP, null );
		WC()->session->set( self::SESSION_TOKEN, null );
		WC()->session->set( self::SESSION_DONE, true );
	}

	/**
	 * On any non-checkout page load with an active token, restore the cart.
	 *
	 * Two restore triggers:
	 *   - User navigated away from checkout (abandon)
	 *   - Token expired (15-min TTL elapsed)
	 */
	public function maybe_restore_on_abandon() {
		if ( is_admin() || wp_doing_ajax() || wp_doing_cron() ) {
			return;
		}
		if ( ! function_exists( 'WC' ) || ! WC()->session ) {
			return;
		}

		$token = WC()->session->get( self::SESSION_TOKEN );
		if ( ! is_array( $token ) || empty( $token['token'] ) ) {
			return;
		}

		// On the order-received endpoint, on_order_complete handles cleanup.
		if ( function_exists( 'is_wc_endpoint_url' ) && is_wc_endpoint_url( 'order-received' ) ) {
			return;
		}

		// On the checkout page itself, do not restore - user is mid-purchase.
		if ( function_exists( 'is_checkout' ) && is_checkout() ) {
			return;
		}

		$expired = ! isset( $token['expires_at'] ) || time() > (int) $token['expires_at'];

		if ( $expired || ! $this->is_buy_now_url() ) {
			$this->restore_now();
		}
	}

	/**
	 * Restore + clear all Buy Now session keys.
	 */
	public function restore_now() {
		if ( ! WC()->cart || ! WC()->session ) {
			return;
		}
		$backup = WC()->session->get( self::SESSION_BACKUP );
		if ( is_array( $backup ) ) {
			WC()->cart->empty_cart();
			$this->restore_from_backup( $backup );
		}
		WC()->session->set( self::SESSION_BACKUP, null );
		WC()->session->set( self::SESSION_TOKEN, null );
	}

	/**
	 * Whether the current request URL carries a Buy Now token query param.
	 *
	 * @return bool
	 */
	private function is_buy_now_url() {
		return isset( $_GET[ self::URL_PARAM ] ) && '' !== sanitize_text_field( wp_unslash( $_GET[ self::URL_PARAM ] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	}

	/**
	 * Whether a valid Buy Now token exists in session.
	 *
	 * @return bool
	 */
	public function has_active_token() {
		if ( ! WC()->session ) {
			return false;
		}
		$token = WC()->session->get( self::SESSION_TOKEN );
		return is_array( $token ) && ! empty( $token['token'] );
	}

	/**
	 * Snapshot the current cart and applied coupons.
	 *
	 * @return array
	 */
	private function snapshot_cart() {
		$snapshot = array(
			'cart_contents'   => array(),
			'applied_coupons' => array(),
			'created_at'      => time(),
		);

		if ( ! WC()->cart ) {
			return $snapshot;
		}

		foreach ( WC()->cart->get_cart_contents() as $item ) {
			if ( empty( $item['product_id'] ) ) {
				continue;
			}
			$snapshot['cart_contents'][] = array(
				'product_id'     => (int) $item['product_id'],
				'variation_id'   => isset( $item['variation_id'] ) ? (int) $item['variation_id'] : 0,
				'variation'      => isset( $item['variation'] ) ? (array) $item['variation'] : array(),
				'quantity'       => isset( $item['quantity'] ) ? (int) $item['quantity'] : 1,
				'cart_item_data' => isset( $item['cart_item_data'] ) ? (array) $item['cart_item_data'] : array(),
			);
		}

		$coupons = WC()->cart->get_applied_coupons();
		if ( is_array( $coupons ) ) {
			$snapshot['applied_coupons'] = array_values( array_filter( array_map( 'sanitize_text_field', $coupons ) ) );
		}

		return $snapshot;
	}

	/**
	 * Restore cart contents from a snapshot.
	 *
	 * @param array $backup Snapshot array.
	 */
	private function restore_from_backup( array $backup ) {
		if ( ! WC()->cart ) {
			return;
		}
		if ( ! empty( $backup['cart_contents'] ) && is_array( $backup['cart_contents'] ) ) {
			foreach ( $backup['cart_contents'] as $item ) {
				if ( empty( $item['product_id'] ) ) {
					continue;
				}
				WC()->cart->add_to_cart(
					(int) $item['product_id'],
					isset( $item['quantity'] ) ? max( 1, (int) $item['quantity'] ) : 1,
					isset( $item['variation_id'] ) ? (int) $item['variation_id'] : 0,
					isset( $item['variation'] ) ? (array) $item['variation'] : array(),
					isset( $item['cart_item_data'] ) ? (array) $item['cart_item_data'] : array()
				);
			}
		}
		if ( ! empty( $backup['applied_coupons'] ) && is_array( $backup['applied_coupons'] ) ) {
			foreach ( $backup['applied_coupons'] as $code ) {
				WC()->cart->apply_coupon( (string) $code );
			}
		}
	}
}
