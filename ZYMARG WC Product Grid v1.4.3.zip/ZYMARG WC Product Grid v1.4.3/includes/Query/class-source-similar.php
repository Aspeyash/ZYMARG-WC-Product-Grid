<?php
/**
 * "Similar products" source.
 *
 * @package Zymarg\WCPG
 */

namespace Zymarg\WCPG\Query;

defined( 'ABSPATH' ) || exit;

/**
 * Class Source_Similar
 *
 * Scores candidate products against the current product on category, tag,
 * price, and stock signals. Returns the top N. Per locked spec, suppresses
 * the entire widget when no candidates clear the chosen strictness.
 *
 * Score:
 *   +3  shares parent category
 *   +2  per shared subcategory (max +6)
 *   +1  per shared tag         (max +5)
 *   +2  price within tolerance
 *   +2  in stock (when toggle on)
 *   +1  published in last 90 days (when toggle on)
 *
 * Strictness threshold:
 *   loose    -> 1
 *   balanced -> 3 (default)
 *   strict   -> 6
 */
class Source_Similar extends Source_Base {

	/**
	 * @inheritDoc
	 */
	public function get_products( array $settings ) {
		$current_id = $this->detect_current_product_id( $settings );
		if ( ! $current_id ) {
			// No context. Return empty so the editor admin notice can explain.
			return array();
		}

		$current = wc_get_product( $current_id );
		if ( ! $current instanceof \WC_Product ) {
			return array();
		}

		$cache_key = 'zymarg_similar_' . md5(
			wp_json_encode(
				array(
					'pid'     => $current_id,
					'limit'   => $this->get_limit( $settings ),
					'strict'  => $settings['similar_strictness'] ?? 'balanced',
					'tol'     => $settings['similar_price_tolerance'] ?? '25',
					'in'      => $settings['similar_prefer_in_stock'] ?? 'yes',
					'recent'  => $settings['similar_prefer_recent'] ?? 'yes',
					'incl'    => $settings['include_products'] ?? '',
					'excl'    => $settings['exclude_products'] ?? '',
					'inclcat' => $settings['include_categories'] ?? '',
					'exclcat' => $settings['exclude_categories'] ?? '',
				)
			)
		);

		$cached = get_transient( $cache_key );
		if ( is_array( $cached ) ) {
			if ( empty( $cached ) ) {
				return self::HIDE_WIDGET;
			}
			return $this->fetch_products_by_ids( $cached, $this->get_limit( $settings ) );
		}

		$candidates = $this->build_candidate_pool( $current );
		if ( empty( $candidates ) ) {
			set_transient( $cache_key, array(), HOUR_IN_SECONDS );
			return self::HIDE_WIDGET;
		}

		$threshold       = $this->resolve_strictness_threshold( $settings );
		$price_tolerance = isset( $settings['similar_price_tolerance'] ) ? (string) $settings['similar_price_tolerance'] : '25';
		$prefer_in       = ! isset( $settings['similar_prefer_in_stock'] ) || 'yes' === $settings['similar_prefer_in_stock'];
		$prefer_recent   = ! isset( $settings['similar_prefer_recent'] ) || 'yes' === $settings['similar_prefer_recent'];

		$cur_cats    = wp_get_post_terms( $current_id, 'product_cat', array( 'fields' => 'ids' ) );
		$cur_tags    = wp_get_post_terms( $current_id, 'product_tag', array( 'fields' => 'ids' ) );
		$cur_cats    = is_array( $cur_cats ) ? array_map( 'intval', $cur_cats ) : array();
		$cur_tags    = is_array( $cur_tags ) ? array_map( 'intval', $cur_tags ) : array();
		$cur_parents = $this->get_parent_category_ids( $cur_cats );
		$cur_price   = (float) $current->get_price();
		$now         = time();

		$scored = array();
		foreach ( $candidates as $candidate ) {
			$pid = (int) $candidate->get_id();
			if ( $pid === $current_id ) {
				continue;
			}

			$cat_ids = wp_get_post_terms( $pid, 'product_cat', array( 'fields' => 'ids' ) );
			$tag_ids = wp_get_post_terms( $pid, 'product_tag', array( 'fields' => 'ids' ) );
			$cat_ids = is_array( $cat_ids ) ? array_map( 'intval', $cat_ids ) : array();
			$tag_ids = is_array( $tag_ids ) ? array_map( 'intval', $tag_ids ) : array();
			$parents = $this->get_parent_category_ids( $cat_ids );

			$score = 0;
			if ( array_intersect( $cur_parents, $parents ) ) {
				$score += 3;
			}
			$score += min( 6, 2 * count( array_intersect( $cur_cats, $cat_ids ) ) );
			$score += min( 5, count( array_intersect( $cur_tags, $tag_ids ) ) );

			if ( 'any' === $price_tolerance ) {
				$score += 2;
			} elseif ( $cur_price > 0 ) {
				$tol = (float) $price_tolerance / 100;
				$cp  = (float) $candidate->get_price();
				if ( $cp > 0 && abs( $cp - $cur_price ) / $cur_price <= $tol ) {
					$score += 2;
				}
			}

			if ( $prefer_in && $candidate->is_in_stock() ) {
				$score += 2;
			}

			if ( $prefer_recent ) {
				$post_date_gmt = get_post_field( 'post_date_gmt', $pid );
				$post_date     = $post_date_gmt ? $post_date_gmt : get_post_field( 'post_date', $pid );
				$age_days      = max( 0, ( $now - (int) strtotime( (string) $post_date ) ) / DAY_IN_SECONDS );
				if ( $age_days <= 90 ) {
					$score += 1;
				}
			}

			if ( $score >= $threshold ) {
				$scored[] = array(
					'id'    => $pid,
					'score' => $score,
					'date'  => get_post_field( 'post_date', $pid ),
				);
			}
		}

		usort(
			$scored,
			static function ( $a, $b ) {
				if ( $a['score'] !== $b['score'] ) {
					return $b['score'] <=> $a['score'];
				}
				return strcmp( (string) $b['date'], (string) $a['date'] );
			}
		);

		$ids = array_column( $scored, 'id' );
		set_transient( $cache_key, $ids, HOUR_IN_SECONDS );

		if ( empty( $ids ) ) {
			return self::HIDE_WIDGET;
		}

		$products = $this->fetch_products_by_ids( $ids, $this->get_limit( $settings ) * 2 );
		$products = $this->apply_shared_filters( $products, $settings );
		$products = array_slice( $products, 0, $this->get_limit( $settings ) );

		return $products ? $products : self::HIDE_WIDGET;
	}

	/**
	 * Build the candidate pool: products sharing at least one category or tag.
	 *
	 * @param \WC_Product $current Current product.
	 * @return \WC_Product[]
	 */
	private function build_candidate_pool( \WC_Product $current ) {
		$pid     = (int) $current->get_id();
		$cat_ids = wp_get_post_terms( $pid, 'product_cat', array( 'fields' => 'ids' ) );
		$tag_ids = wp_get_post_terms( $pid, 'product_tag', array( 'fields' => 'ids' ) );
		$cat_ids = is_array( $cat_ids ) ? array_map( 'intval', $cat_ids ) : array();
		$tag_ids = is_array( $tag_ids ) ? array_map( 'intval', $tag_ids ) : array();

		if ( empty( $cat_ids ) && empty( $tag_ids ) ) {
			return array();
		}

		$tax_match = array( 'relation' => 'OR' ); // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query
		if ( $cat_ids ) {
			$tax_match[] = array(
				'taxonomy' => 'product_cat',
				'field'    => 'term_id',
				'terms'    => $cat_ids,
				'operator' => 'IN',
			);
		}
		if ( $tag_ids ) {
			$tax_match[] = array(
				'taxonomy' => 'product_tag',
				'field'    => 'term_id',
				'terms'    => $tag_ids,
				'operator' => 'IN',
			);
		}

		$visibility = $this->get_visibility_tax_clause();
		if ( $visibility ) {
			$tax_query = array(
				'relation' => 'AND',
				$tax_match,
				$visibility[0],
			);
		} else {
			$tax_query = $tax_match;
		}

		return $this->fetch_products_by_query(
			array(
				'posts_per_page' => 100,
				'orderby'        => 'date',
				'order'          => 'DESC',
				'post__not_in'   => array( $pid ),
				'tax_query'      => $tax_query, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query
			)
		);
	}

	/**
	 * Resolve the strictness threshold value from settings.
	 *
	 * @param array $settings Widget settings.
	 * @return int
	 */
	private function resolve_strictness_threshold( array $settings ) {
		$key = isset( $settings['similar_strictness'] ) ? (string) $settings['similar_strictness'] : 'balanced';
		switch ( $key ) {
			case 'loose':
				return 1;
			case 'strict':
				return 6;
			case 'balanced':
			default:
				return 3;
		}
	}

	/**
	 * Walk product_cat term IDs up to their root parent IDs.
	 *
	 * @param int[] $term_ids Term IDs.
	 * @return int[]
	 */
	private function get_parent_category_ids( array $term_ids ) {
		$parents = array();
		foreach ( $term_ids as $term_id ) {
			$term = get_term( $term_id, 'product_cat' );
			if ( ! $term || is_wp_error( $term ) ) {
				continue;
			}
			$parents[] = $term->parent ? (int) $term->parent : (int) $term->term_id;
		}
		return array_values( array_unique( $parents ) );
	}
}
