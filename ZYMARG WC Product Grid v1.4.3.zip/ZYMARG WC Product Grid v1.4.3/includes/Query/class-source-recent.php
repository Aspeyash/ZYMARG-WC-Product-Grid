<?php
/**
 * "Recently viewed" source.
 *
 * @package Zymarg\WCPG
 */

namespace Zymarg\WCPG\Query;

defined( 'ABSPATH' ) || exit;

use Zymarg\WCPG\Tracking\Recently_Viewed;

/**
 * Class Source_Recent
 *
 * Reads the visitor's recently-viewed product list from the tracker and
 * returns the products in recency order, optionally excluding the current
 * product if rendered on a single-product page.
 */
class Source_Recent extends Source_Base {

	/**
	 * @inheritDoc
	 */
	public function get_products( array $settings ) {
		$ids = Recently_Viewed::get_ids();

		if ( function_exists( 'is_product' ) && is_product() ) {
			$current = (int) get_queried_object_id();
			if ( $current ) {
				$ids = array_values( array_diff( $ids, array( $current ) ) );
			}
		}

		if ( empty( $ids ) ) {
			$mode = isset( $settings['recent_empty_mode'] ) ? (string) $settings['recent_empty_mode'] : 'message';
			return 'hide' === $mode ? self::HIDE_WIDGET : array();
		}

		$products = $this->fetch_products_by_ids( $ids, $this->get_limit( $settings ) * 2 );
		$products = $this->apply_shared_filters( $products, $settings );
		return array_slice( $products, 0, $this->get_limit( $settings ) );
	}
}
