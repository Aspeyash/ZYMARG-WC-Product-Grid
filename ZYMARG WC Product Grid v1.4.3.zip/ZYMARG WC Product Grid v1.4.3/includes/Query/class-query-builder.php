<?php
/**
 * Centralised product query builder / source dispatcher.
 *
 * @package Zymarg\WCPG
 */

namespace Zymarg\WCPG\Query;

defined( 'ABSPATH' ) || exit;

/**
 * Class Query_Builder
 *
 * Resolves the configured "source" setting to a Source_Base instance and
 * delegates the query. Registered sources:
 *   all      -> Source_All
 *   dynamic  -> Source_Dynamic
 *   featured -> Source_Featured
 *   similar  -> Source_Similar
 *   recent   -> Source_Recent
 *   wishlist -> Source_Wishlist
 *   trending -> Source_Trending
 *   vendor   -> Source_Vendor
 *   algolia  -> Source_Algolia  (Algolia-powered search results page)
 *   category -> Source_Category (auto-detected category/shop page)
 *   recommended -> Source_Recommended (per-visitor personalised feed)
 *
 * Source classes return either an array of \WC_Product OR the
 * Source_Base::HIDE_WIDGET sentinel. Callers (the widget) interpret
 * HIDE_WIDGET as "render no markup at all".
 */
class Query_Builder {

	/**
	 * Hard upper bound mirrors the widget control cap.
	 */
	const MAX_PRODUCTS = 100;

	/**
	 * Get products for a widget instance.
	 *
	 * @param array $settings Sanitized widget settings.
	 * @return \WC_Product[]|string Array of products, or Source_Base::HIDE_WIDGET.
	 */
	public static function get_products( array $settings ) {
		if ( ! function_exists( 'wc_get_product' ) ) {
			return array();
		}

		$source_key = isset( $settings['source'] ) ? sanitize_key( $settings['source'] ) : 'all';
		$source     = self::resolve_source( $source_key );

		return $source->get_products( $settings );
	}

	/**
	 * Resolve a source key to a Source_Base instance.
	 *
	 * Unknown keys (and Phase 3B sources before they ship) fall back to
	 * Source_All so the widget always renders something sensible.
	 *
	 * @param string $key Source key from settings.
	 * @return Source_Base
	 */
	public static function resolve_source( $key ) {
		/**
		 * Filter the source-key -> class-name registry.
		 *
		 * Plugins / Phase 3B can plug in by adding additional entries.
		 *
		 * @param array<string,string> $registry Map of source key -> FQCN.
		 */
		$registry = apply_filters(
			'zymarg_wcpg_source_registry',
			array(
				'all'         => Source_All::class,
				'dynamic'     => Source_Dynamic::class,
				'featured'    => Source_Featured::class,
				'similar'     => Source_Similar::class,
				'recent'      => Source_Recent::class,
				'wishlist'    => Source_Wishlist::class,
				'trending'    => Source_Trending::class,
				'vendor'      => Source_Vendor::class,
				'algolia'     => Source_Algolia::class,
				'category'    => Source_Category::class,
				'recommended' => Source_Recommended::class,
			)
		);

		$class = isset( $registry[ $key ] ) ? $registry[ $key ] : Source_All::class;
		if ( ! class_exists( $class ) ) {
			$class = Source_All::class;
		}
		return new $class();
	}
}
