<?php
/**
 * "Dynamic products" source.
 *
 * @package Zymarg\WCPG
 */

namespace Zymarg\WCPG\Query;

defined( 'ABSPATH' ) || exit;

/**
 * Class Source_Dynamic
 *
 * Builds a candidate pool of the latest products (cached) and scores each
 * with weighted recency / rating / sales signals plus a small jitter so
 * the visible top-N shifts subtly between page loads. This makes the grid
 * feel alive without thrashing the database.
 *
 *   score = (recency * W_recency)
 *         + (rating  * W_rating)
 *         + (sales   * W_sales)
 *         + jitter (-0.05 ... +0.05)
 */
class Source_Dynamic extends Source_Base {

	/** Maximum candidate pool size. */
	const POOL_SIZE = 200;

	/** Default cache TTL for the candidate pool, in seconds. */
	const POOL_TTL_DEFAULT = HOUR_IN_SECONDS;

	/**
	 * @inheritDoc
	 */
	public function get_products( array $settings ) {
		$pool = $this->get_candidate_pool( $settings );
		if ( empty( $pool ) ) {
			return array();
		}

		$weights   = $this->resolve_weights( $settings );
		$max_age   = max( 1, max( wp_list_pluck( $pool, 'age_days' ) ) );
		$max_sales = max( 1, max( wp_list_pluck( $pool, 'sales' ) ) );
		$scored    = array();

		foreach ( $pool as $entry ) {
			$recency = 1 - min( 1, $entry['age_days'] / $max_age );
			$rating  = min( 1, max( 0, $entry['rating'] / 5 ) );
			$sales   = min( 1, $entry['sales'] / $max_sales );
			$jitter  = ( wp_rand( 0, 100 ) - 50 ) / 1000;

			$scored[] = array(
				'id'    => $entry['id'],
				'score' => ( $weights['recency'] * $recency )
					+ ( $weights['rating'] * $rating )
					+ ( $weights['sales'] * $sales )
					+ $jitter,
			);
		}

		usort(
			$scored,
			static function ( $a, $b ) {
				if ( $a['score'] === $b['score'] ) {
					return 0;
				}
				return $a['score'] < $b['score'] ? 1 : -1;
			}
		);

		$ids      = array_column( $scored, 'id' );
		$products = $this->fetch_products_by_ids( $ids, self::POOL_SIZE );
		$products = $this->apply_shared_filters( $products, $settings );

		return array_slice( $products, 0, $this->get_limit( $settings ) );
	}

	/**
	 * Resolve scoring weights from settings, normalised to sum to 1.0.
	 *
	 * @param array $settings Widget settings.
	 * @return array{recency:float,rating:float,sales:float}
	 */
	private function resolve_weights( array $settings ) {
		$w_recency = isset( $settings['dynamic_w_recency'] ) ? max( 0, (int) $settings['dynamic_w_recency'] ) : 60;
		$w_rating  = isset( $settings['dynamic_w_rating'] ) ? max( 0, (int) $settings['dynamic_w_rating'] ) : 30;
		$w_sales   = isset( $settings['dynamic_w_sales'] ) ? max( 0, (int) $settings['dynamic_w_sales'] ) : 10;

		$total = $w_recency + $w_rating + $w_sales;
		if ( $total <= 0 ) {
			return array(
				'recency' => 0.6,
				'rating'  => 0.3,
				'sales'   => 0.1,
			);
		}
		return array(
			'recency' => $w_recency / $total,
			'rating'  => $w_rating / $total,
			'sales'   => $w_sales / $total,
		);
	}

	/**
	 * Get (and cache) the candidate pool.
	 *
	 * @param array $settings Widget settings.
	 * @return array<int,array{id:int,age_days:int,rating:float,sales:int}>
	 */
	private function get_candidate_pool( array $settings ) {
		$show_oos = isset( $settings['show_oos'] ) && 'yes' === $settings['show_oos'];
		$ttl      = $this->resolve_ttl( $settings );
		$key      = 'zymarg_dynamic_pool_' . md5( wp_json_encode( array( 'oos' => $show_oos ) ) );

		$cached = get_transient( $key );
		if ( is_array( $cached ) && ! empty( $cached ) ) {
			return $cached;
		}

		$args = array(
			'post_type'           => 'product',
			'post_status'         => 'publish',
			'ignore_sticky_posts' => true,
			'no_found_rows'       => true,
			'posts_per_page'      => self::POOL_SIZE,
			'orderby'             => 'date',
			'order'               => 'DESC',
			'fields'              => 'ids',
		);

		$meta_query = array(); // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
		if ( ! $show_oos ) {
			$meta_query[] = array(
				'key'   => '_stock_status',
				'value' => 'instock',
			);
			$args['meta_query'] = $meta_query; // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
		}
		$tax_query = $this->get_visibility_tax_clause();
		if ( $tax_query ) {
			$args['tax_query'] = $tax_query; // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query
		}

		$query = new \WP_Query( $args );
		$pool  = array();
		$now   = time();

		foreach ( $query->posts as $post_id ) {
			$post_id = (int) $post_id;
			$post    = get_post( $post_id );
			if ( ! $post ) {
				continue;
			}
			$ts          = strtotime( $post->post_date_gmt ? $post->post_date_gmt : $post->post_date );
			$age_seconds = max( 0, $now - (int) $ts );
			$age_days    = (int) floor( $age_seconds / DAY_IN_SECONDS );

			$pool[] = array(
				'id'       => $post_id,
				'age_days' => $age_days,
				'rating'   => (float) get_post_meta( $post_id, '_wc_average_rating', true ),
				'sales'    => (int) get_post_meta( $post_id, 'total_sales', true ),
			);
		}

		set_transient( $key, $pool, $ttl );
		return $pool;
	}

	/**
	 * Resolve the candidate-pool TTL from settings.
	 *
	 * @param array $settings Widget settings.
	 * @return int Seconds.
	 */
	private function resolve_ttl( array $settings ) {
		$mode = isset( $settings['dynamic_refresh'] ) ? (string) $settings['dynamic_refresh'] : 'hour';
		switch ( $mode ) {
			case 'page':
				return 60;
			case 'day':
				return DAY_IN_SECONDS;
			case 'hour':
			default:
				return self::POOL_TTL_DEFAULT;
		}
	}
}
