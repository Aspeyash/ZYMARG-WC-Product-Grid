<?php
/**
 * "More From Seller" (Dokan vendor) source.
 *
 * @package Zymarg\WCPG
 */

namespace Zymarg\WCPG\Query;

defined( 'ABSPATH' ) || exit;

use Zymarg\WCPG\Vendor\Vendor_Cache;
use Zymarg\WCPG\Vendor\Vendor_Resolver;

/**
 * Class Source_Vendor
 *
 * On a single-product page (or with a manual product ID), show other
 * products from the same vendor. Per locked spec: HIDE_WIDGET when no
 * vendor is resolved or when the vendor has no other products.
 */
class Source_Vendor extends Source_Base {

	/**
	 * @inheritDoc
	 */
	public function get_products( array $settings ) {
		if ( ! Vendor_Resolver::is_supported() ) {
			return self::HIDE_WIDGET;
		}

		$current_pid = $this->detect_vendor_context_product_id( $settings );
		if ( $current_pid <= 0 ) {
			return self::HIDE_WIDGET;
		}

		$vendor_id = Vendor_Resolver::resolve( $current_pid );
		if ( $vendor_id <= 0 ) {
			return self::HIDE_WIDGET;
		}

		$status = Vendor_Resolver::check_vendor_status( $vendor_id );
		if ( empty( $status['ok'] ) ) {
			return self::HIDE_WIDGET;
		}

		$variant = wp_json_encode(
			array(
				'order_by' => $settings['vendor_order_by'] ?? 'rating',
				'in_stock' => $settings['vendor_in_stock'] ?? 'yes',
				'limit'    => $this->get_limit( $settings ),
				'exclude'  => $current_pid,
			)
		);

		$cached_ids = Vendor_Cache::get( $vendor_id, $variant );
		if ( false === $cached_ids ) {
			$cached_ids = $this->query_vendor_product_ids( $vendor_id, $current_pid, $settings );
			Vendor_Cache::set( $vendor_id, $cached_ids, $variant );
		}

		if ( empty( $cached_ids ) ) {
			return self::HIDE_WIDGET;
		}

		$products = $this->fetch_products_by_ids( $cached_ids, $this->get_limit( $settings ) * 2 );
		$products = $this->apply_shared_filters( $products, $settings );
		$products = array_slice( $products, 0, $this->get_limit( $settings ) );

		return $products ? $products : self::HIDE_WIDGET;
	}

	/**
	 * Identify the product context for vendor lookup.
	 *
	 * @param array $settings Widget settings.
	 * @return int
	 */
	private function detect_vendor_context_product_id( array $settings ) {
		$auto = ! isset( $settings['vendor_auto_detect'] ) || 'yes' === $settings['vendor_auto_detect'];
		if ( ! $auto ) {
			return isset( $settings['vendor_product_id'] ) ? max( 0, (int) $settings['vendor_product_id'] ) : 0;
		}
		if ( function_exists( 'is_product' ) && is_product() ) {
			return (int) get_queried_object_id();
		}
		global $post;
		if ( $post instanceof \WP_Post && 'product' === $post->post_type ) {
			return (int) $post->ID;
		}
		return 0;
	}

	/**
	 * Query the vendor's other products honouring Dokan's Staff module.
	 *
	 * @param int   $vendor_id   Vendor user ID.
	 * @param int   $exclude_pid Current product to exclude.
	 * @param array $settings    Widget settings.
	 * @return int[]
	 */
	private function query_vendor_product_ids( $vendor_id, $exclude_pid, array $settings ) {
		$author_ids = Vendor_Resolver::get_vendor_author_ids( $vendor_id );
		if ( empty( $author_ids ) ) {
			return array();
		}

		$prefer_in = ! isset( $settings['vendor_in_stock'] ) || 'yes' === $settings['vendor_in_stock'];
		$order_by  = isset( $settings['vendor_order_by'] ) ? sanitize_key( $settings['vendor_order_by'] ) : 'rating';

		$args = array(
			'post_type'      => 'product',
			'post_status'    => 'publish',
			'author__in'     => $author_ids,
			'post__not_in'   => array( (int) $exclude_pid ),
			'posts_per_page' => 60,
			'no_found_rows'  => true,
			'fields'         => 'ids',
		);

		switch ( $order_by ) {
			case 'date':
				$args['orderby'] = 'date';
				$args['order']   = 'DESC';
				break;
			case 'sales':
				$args['meta_key'] = 'total_sales'; // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
				$args['orderby']  = 'meta_value_num';
				$args['order']    = 'DESC';
				break;
			case 'price':
				$args['meta_key'] = '_price'; // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
				$args['orderby']  = 'meta_value_num';
				$args['order']    = 'ASC';
				break;
			case 'random':
				$args['orderby'] = 'rand';
				break;
			case 'rating':
			default:
				$args['meta_key'] = '_wc_average_rating'; // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
				$args['orderby']  = 'meta_value_num';
				$args['order']    = 'DESC';
				break;
		}

		$meta_query = array(); // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
		if ( $prefer_in ) {
			$meta_query[] = array(
				'key'   => '_stock_status',
				'value' => 'instock',
			);
		}
		if ( $meta_query ) {
			$args['meta_query'] = $meta_query; // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
		}

		$tax_query = $this->get_visibility_tax_clause();
		if ( $tax_query ) {
			$args['tax_query'] = $tax_query; // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query
		}

		$query = new \WP_Query( $args );
		$ids   = is_array( $query->posts ) ? array_map( 'intval', $query->posts ) : array();

		// Final visibility filter using each product's is_visible() method.
		$visible = array();
		foreach ( $ids as $pid ) {
			$product = wc_get_product( $pid );
			if ( $product && $product->is_visible() ) {
				$visible[] = (int) $pid;
			}
		}
		return $visible;
	}
}
