<?php
/**
 * Algolia-powered search results source.
 *
 * When source = 'algolia' the widget queries Algolia's REST API instead of
 * the local MySQL database, then fetches the matching WC_Products by ID so
 * every existing card feature (badges, wishlist, quick-view, trending, etc.)
 * works without any changes.
 *
 * Flow:
 *   1. Read get_search_query() from the current URL (or AJAX post payload).
 *   2. Read Algolia credentials from zymarg_algolia_settings option.
 *   3. Check a short-lived transient cache keyed on query + page + per-page.
 *   4. POST to Algolia (/1/indexes/{index}/queries) - products index only.
 *   5. Extract ranked objectID list + nbHits + queryID.
 *   6. Cache result.
 *   7. Fetch WC_Products via post__in + orderby=post__in to honour ranking.
 *   8. Expose nbHits + queryID via filters for pagination & click-analytics.
 *
 * Fallback: any failure (empty query, missing creds, HTTP error) falls
 * through to Source_All so the widget always renders something sensible.
 *
 * @package Zymarg\WCPG
 */

namespace Zymarg\WCPG\Query;

defined( 'ABSPATH' ) || exit;

/**
 * Class Source_Algolia
 */
class Source_Algolia extends Source_Base {

	/* ------------------------------------------------------------------ */
	/* Constants                                                            */
	/* ------------------------------------------------------------------ */

	/** Transient TTL in seconds (5 minutes). */
	const CACHE_TTL = 300;

	/** Transient key prefix. */
	const CACHE_PREFIX = 'awcpg_alg_';

	/** Algolia settings option name (written by Zymarg Algolia plugin). */
	const OPTION_KEY = 'zymarg_algolia_settings';

	/** HTTP timeout for Algolia API calls in seconds. */
	const HTTP_TIMEOUT = 5;

	/* ------------------------------------------------------------------ */
	/* Runtime state (populated during get_products, read via filters)     */
	/* ------------------------------------------------------------------ */

	/** @var int Total hits Algolia reported for the query. */
	private $nb_hits = 0;

	/** @var int Hits per page used in the last Algolia call. */
	private $hits_per_page = 8;

	/** @var string|null Algolia queryID for click-analytics (null when unavailable). */
	private $query_id = null;

	/** @var int Zero-based Algolia page index used in the last call. */
	private $algolia_page = 0;

	/* ------------------------------------------------------------------ */
	/* Public API                                                           */
	/* ------------------------------------------------------------------ */

	/**
	 * Return products for this source.
	 *
	 * @param array $settings Sanitized widget settings.
	 * @return \WC_Product[]|string Array of products, or HIDE_WIDGET sentinel.
	 */
	public function get_products( array $settings ) {

		// --- 1. Resolve search query ----------------------------------------
		$query = $this->resolve_query( $settings );
		if ( '' === $query ) {
			// Not on a search page - fall back to all products.
			return ( new Source_All() )->get_products( $settings );
		}

		// --- 2. Read credentials --------------------------------------------
		$creds = $this->get_algolia_creds();
		if ( ! $creds ) {
			$this->log_warn( 'Algolia credentials missing. Falling back to Source_All.' );
			return ( new Source_All() )->get_products( $settings );
		}

		// --- 3. Pagination --------------------------------------------------
		$per_page           = $this->get_limit( $settings );
		$this->hits_per_page = $per_page;

		// WordPress page number: from _paged (AJAX load-more) or query var.
		$wp_page            = isset( $settings['_paged'] ) ? max( 1, (int) $settings['_paged'] ) : max( 1, (int) get_query_var( 'paged', 1 ) );
		$this->algolia_page = $wp_page - 1; // Algolia is zero-based.

		// --- 4. Filters (stock) ---------------------------------------------
		$filters = '';
		$show_oos = isset( $settings['show_oos'] ) && 'yes' === $settings['show_oos'];
		if ( ! $show_oos ) {
			$filters = 'in_stock:true';
		}

		// --- 5. Cache lookup ------------------------------------------------
		$cache_key = $this->build_cache_key( $query, $this->algolia_page, $per_page, $filters );
		$cached    = $this->get_cache( $cache_key );

		if ( null !== $cached ) {
			$ids            = $cached['ids'];
			$this->nb_hits  = $cached['nb_hits'];
			$this->query_id = $cached['query_id'];
		} else {
			// --- 6. Call Algolia --------------------------------------------
			$algolia_result = $this->call_algolia( $creds, $query, $per_page, $this->algolia_page, $filters );

			if ( null === $algolia_result ) {
				$this->log_warn( 'Algolia API call failed. Falling back to Source_All.' );
				return ( new Source_All() )->get_products( $settings );
			}

			$ids            = $algolia_result['ids'];
			$this->nb_hits  = $algolia_result['nb_hits'];
			$this->query_id = $algolia_result['query_id'];

			// --- 7. Cache result --------------------------------------------
			$this->set_cache(
				$cache_key,
				array(
					'ids'      => $ids,
					'nb_hits'  => $this->nb_hits,
					'query_id' => $this->query_id,
				)
			);
		}

		// --- 8. Expose metadata via filters ---------------------------------
		$this->register_metadata_filters();

		// --- 9. Empty result ------------------------------------------------
		if ( empty( $ids ) ) {
			return array();
		}

		// --- 10. Fetch WC_Products in Algolia's ranked order ----------------
		return $this->fetch_products_by_query(
			array(
				'post__in'       => $ids,
				'orderby'        => 'post__in',   // preserve Algolia ranking.
				'posts_per_page' => count( $ids ),
				'no_found_rows'  => true,
			)
		);
	}

	/* ------------------------------------------------------------------ */
	/* Getters for external use                                             */
	/* ------------------------------------------------------------------ */

	/** @return int */
	public function get_nb_hits() {
		return $this->nb_hits;
	}

	/** @return int */
	public function get_hits_per_page() {
		return $this->hits_per_page;
	}

	/** @return string|null */
	public function get_query_id() {
		return $this->query_id;
	}

	/* ------------------------------------------------------------------ */
	/* Private helpers                                                      */
	/* ------------------------------------------------------------------ */

	/**
	 * Resolve the search query string.
	 *
	 * Priority:
	 *  1. settings['_algolia_query'] - set by Handler_Load_More for AJAX requests.
	 *  2. get_search_query()          - standard WordPress search context.
	 *
	 * @param array $settings Widget settings.
	 * @return string Empty string when not in a search context.
	 */
	private function resolve_query( array $settings ) {
		// AJAX load-more passes the query explicitly.
		if ( ! empty( $settings['_algolia_query'] ) ) {
			return sanitize_text_field( wp_unslash( $settings['_algolia_query'] ) );
		}

		$q = get_search_query();
		return is_string( $q ) ? trim( $q ) : '';
	}

	/**
	 * Load Algolia credentials from the Zymarg Algolia plugin's saved option.
	 *
	 * @return array|null Array with keys app_id, search_key, index_name - or null.
	 */
	private function get_algolia_creds() {
		$opts = get_option( self::OPTION_KEY, array() );

		$app_id     = isset( $opts['app_id'] )         ? trim( (string) $opts['app_id'] )         : '';
		$search_key = isset( $opts['search_api_key'] ) ? trim( (string) $opts['search_api_key'] ) : '';
		$prefix     = isset( $opts['index_prefix'] )   ? trim( (string) $opts['index_prefix'] )   : 'zymarg_';

		if ( '' === $app_id || '' === $search_key ) {
			return null;
		}

		return array(
			'app_id'     => $app_id,
			'search_key' => $search_key,
			'index_name' => $prefix . 'products',
		);
	}

	/**
	 * POST a single-index search to Algolia and return normalised result.
	 *
	 * @param array  $creds      Credentials from get_algolia_creds().
	 * @param string $query      Search query string.
	 * @param int    $per_page   Number of hits to request.
	 * @param int    $page       Zero-based page index.
	 * @param string $filters    Algolia filter string (may be empty).
	 * @return array|null Array with keys ids, nb_hits, query_id - or null on failure.
	 */
	private function call_algolia( array $creds, $query, $per_page, $page, $filters ) {
		$host = 'https://' . rawurlencode( $creds['app_id'] ) . '-dsn.algolia.net';
		$url  = $host . '/1/indexes/*/queries';

		$request_body = array(
			'requests' => array(
				array(
					'indexName'            => $creds['index_name'],
					'params'               => $this->build_params_string( $query, $per_page, $page, $filters ),
				),
			),
		);

		$response = wp_remote_post(
			$url,
			array(
				'timeout'     => self::HTTP_TIMEOUT,
				'headers'     => array(
					'X-Algolia-Application-Id' => $creds['app_id'],
					'X-Algolia-API-Key'        => $creds['search_key'],
					'Content-Type'             => 'application/json',
				),
				'body'        => wp_json_encode( $request_body ),
				'data_format' => 'body',
			)
		);

		if ( is_wp_error( $response ) ) {
			$this->log_warn( 'wp_remote_post error: ' . $response->get_error_message() );
			return null;
		}

		$code = wp_remote_retrieve_response_code( $response );
		if ( $code < 200 || $code >= 300 ) {
			$this->log_warn( 'Algolia returned HTTP ' . $code );
			return null;
		}

		$body = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( ! is_array( $body ) || empty( $body['results'] ) ) {
			$this->log_warn( 'Unexpected Algolia response body.' );
			return null;
		}

		$result   = $body['results'][0];
		$hits     = isset( $result['hits'] ) && is_array( $result['hits'] ) ? $result['hits'] : array();
		$nb_hits  = isset( $result['nbHits'] ) ? (int) $result['nbHits'] : count( $hits );
		$query_id = isset( $result['queryID'] ) ? (string) $result['queryID'] : null;

		// Extract product IDs in Algolia's ranked order.
		$ids = array();
		foreach ( $hits as $hit ) {
			$oid = isset( $hit['objectID'] ) ? (int) $hit['objectID'] : 0;
			if ( $oid > 0 ) {
				$ids[] = $oid;
			}
		}

		return array(
			'ids'      => $ids,
			'nb_hits'  => $nb_hits,
			'query_id' => $query_id,
		);
	}

	/**
	 * Build the URL-encoded params string Algolia expects inside `params`.
	 *
	 * @param string $query    Search query.
	 * @param int    $per_page Hits per page.
	 * @param int    $page     Zero-based page.
	 * @param string $filters  Algolia filter expression.
	 * @return string
	 */
	private function build_params_string( $query, $per_page, $page, $filters ) {
		$params = array(
			'query'                => $query,
			'hitsPerPage'          => (int) $per_page,
			'page'                 => (int) $page,
			'clickAnalytics'       => 'true',
			'attributesToRetrieve' => 'objectID',
		);

		if ( '' !== $filters ) {
			$params['filters'] = $filters;
		}

		$parts = array();
		foreach ( $params as $k => $v ) {
			$parts[] = rawurlencode( $k ) . '=' . rawurlencode( (string) $v );
		}

		return implode( '&', $parts );
	}

	/**
	 * Build transient cache key.
	 *
	 * @param string $query    Search query.
	 * @param int    $page     Zero-based page.
	 * @param int    $per_page Hits per page.
	 * @param string $filters  Algolia filter string.
	 * @return string
	 */
	private function build_cache_key( $query, $page, $per_page, $filters ) {
		return self::CACHE_PREFIX . md5( $query . '|' . $page . '|' . $per_page . '|' . $filters );
	}

	/**
	 * Read a cached result. Returns null on miss.
	 *
	 * @param string $key Transient key.
	 * @return array|null
	 */
	private function get_cache( $key ) {
		$value = get_transient( $key );
		return ( false === $value || ! is_array( $value ) ) ? null : $value;
	}

	/**
	 * Write a result to cache.
	 *
	 * @param string $key   Transient key.
	 * @param array  $value Data to cache.
	 */
	private function set_cache( $key, array $value ) {
		set_transient( $key, $value, self::CACHE_TTL );
	}

	/**
	 * Register one-time filters that expose nb_hits and query_id to templates
	 * and the load-more handler.
	 *
	 * Filters fire once and remove themselves to avoid leaking across multiple
	 * widget renders on the same page.
	 */
	private function register_metadata_filters() {
		$nb_hits  = $this->nb_hits;
		$query_id = $this->query_id;
		$per_page = $this->hits_per_page;

		/**
		 * Total number of Algolia hits for the current search query.
		 * Used by the grid wrapper to decide whether to show the Load More button.
		 *
		 * @param int $nb_hits
		 */
		add_filter(
			'zymarg_wcpg_algolia_nb_hits',
			static function () use ( $nb_hits ) {
				return $nb_hits;
			}
		);

		/**
		 * Algolia queryID for click-analytics.
		 * Output as data-algolia-query-id on product cards when non-null.
		 *
		 * @param string|null $query_id
		 */
		add_filter(
			'zymarg_wcpg_algolia_query_id',
			static function () use ( $query_id ) {
				return $query_id;
			}
		);

		/**
		 * Hits per page used in the Algolia call.
		 *
		 * @param int $per_page
		 */
		add_filter(
			'zymarg_wcpg_algolia_hits_per_page',
			static function () use ( $per_page ) {
				return $per_page;
			}
		);
	}

	/**
	 * Conditional debug log - only writes when WP_DEBUG is on.
	 *
	 * @param string $message
	 */
	private function log_warn( $message ) {
		if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
			// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
			error_log( '[ZYMARG WCPG / Source_Algolia] ' . $message );
		}
	}
}
