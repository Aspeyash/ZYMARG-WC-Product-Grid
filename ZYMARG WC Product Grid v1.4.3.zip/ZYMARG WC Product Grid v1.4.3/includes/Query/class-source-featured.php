<?php
/**
 * "Featured products" source.
 *
 * @package Zymarg\WCPG
 */

namespace Zymarg\WCPG\Query;

defined( 'ABSPATH' ) || exit;

/**
 * Class Source_Featured
 *
 * Returns products with the WooCommerce "featured" flag.
 */
class Source_Featured extends Source_All {

	/**
	 * @inheritDoc
	 */
	protected function build_args( array $settings ) {
		$args = parent::build_args( $settings );

		if ( function_exists( 'wc_get_product_visibility_term_ids' ) ) {
			$visibility = wc_get_product_visibility_term_ids();
			if ( ! empty( $visibility['featured'] ) ) {
				$existing = isset( $args['tax_query'] ) && is_array( $args['tax_query'] ) ? $args['tax_query'] : array();
				unset( $existing['relation'] );
				$existing[] = array(
					'taxonomy' => 'product_visibility',
					'field'    => 'term_taxonomy_id',
					'terms'    => array( (int) $visibility['featured'] ),
					'operator' => 'IN',
				);
				if ( count( $existing ) > 1 ) {
					$existing['relation'] = 'AND';
				}
				$args['tax_query'] = $existing; // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query
			}
		}
		return $args;
	}
}
