<?php
/**
 * Source-specific layout controls.
 *
 * Each active source can have its own collapsible section with knobs that
 * only make sense for that source (Dynamic weights, Similar strictness,
 * Recently Viewed empty mode, Wishlist empty mode, etc.). All sections are
 * conditionally hidden by `source` so the editor only sees the relevant set.
 *
 * @package Zymarg\WCPG
 */

namespace Zymarg\WCPG\Elementor\Traits;

defined( 'ABSPATH' ) || exit;

/**
 * Trait Controls_Source
 *
 * Phase 3A: ships sections for Dynamic, Similar, Recently Viewed, Wishlist.
 * Featured needs no extra controls beyond the shared layout. Trending and
 * Vendor sections land in Phase 3B.
 */
trait Controls_Source {

	/**
	 * Register all source-specific sections.
	 */
	protected function register_source_sections() {
		$this->register_source_algolia_section();
		$this->register_source_dynamic_section();
		$this->register_source_trending_section();
		$this->register_source_recommended_section();
		$this->register_source_similar_section();
		$this->register_source_vendor_section();
		$this->register_source_recent_section();
		$this->register_source_wishlist_section();
		$this->register_source_category_section();
	}

	/**
	 * Category source: subcategory toggle, shop page behavior, orderby.
	 */
	private function register_source_category_section() {
		$this->start_controls_section(
			'section_source_category',
			array(
				'label'     => __( 'Category page settings', 'zymarg-wcpg' ),
				'condition' => array( 'source' => 'category' ),
			)
		);

		$this->add_control(
			'cat_info_notice',
			array(
				'type'    => \Elementor\Controls_Manager::RAW_HTML,
				'default' => '',
				'raw'     => '<div class="elementor-panel-alert elementor-panel-alert-info">'
					. '<strong>' . esc_html__( 'How this works', 'zymarg-wcpg' ) . '</strong><br>'
					. esc_html__( 'This source reads the current category from the URL automatically. Place this widget on your Product Category archive template in Elementor Theme Builder.', 'zymarg-wcpg' )
					. '<br><br>'
					. esc_html__( 'On all non-category pages it falls back to All Products automatically - so the widget is safe to place anywhere.', 'zymarg-wcpg' )
					. '<br><br>'
					. esc_html__( 'In the Elementor editor preview, all products are shown as a placeholder - the actual category filter only activates on the live page.', 'zymarg-wcpg' )
					. '</div>',
			)
		);

		$this->add_control(
			'cat_include_subcategories',
			array(
				'label'        => __( 'Include subcategories', 'zymarg-wcpg' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default'      => 'yes',
				'description'  => __( 'When on, products from all child and descendant categories are also shown (up to 5 levels deep).', 'zymarg-wcpg' ),
			)
		);

		$this->add_control(
			'cat_shop_behavior',
			array(
				'label'       => __( 'On the main shop page', 'zymarg-wcpg' ),
				'type'        => \Elementor\Controls_Manager::SELECT,
				'default'     => 'all',
				'options'     => array(
					'all'      => __( 'Show all products', 'zymarg-wcpg' ),
					'fallback' => __( 'Fall back to All Products source', 'zymarg-wcpg' ),
				),
				'description' => __( 'Controls what shows on /shop/ when no specific category is active in the URL.', 'zymarg-wcpg' ),
			)
		);

		$this->add_control(
			'cat_orderby',
			array(
				'label'       => __( 'Order by', 'zymarg-wcpg' ),
				'type'        => \Elementor\Controls_Manager::SELECT,
				'default'     => 'popularity',
				'options'     => array(
					'popularity' => __( 'Popularity (best selling first)', 'zymarg-wcpg' ),
					'rating'     => __( 'Rating (highest rated first)', 'zymarg-wcpg' ),
					'date'       => __( 'Date (newest first)', 'zymarg-wcpg' ),
					'price'      => __( 'Price (lowest first)', 'zymarg-wcpg' ),
					'price-desc' => __( 'Price (highest first)', 'zymarg-wcpg' ),
					'menu_order' => __( 'Menu order (manually sorted)', 'zymarg-wcpg' ),
					'rand'       => __( 'Random', 'zymarg-wcpg' ),
				),
				'description' => __( 'The WooCommerce sort dropdown on the page overrides this when used by the customer.', 'zymarg-wcpg' ),
			)
		);

		$this->add_control(
			'cat_orderby_notice',
			array(
				'type'    => \Elementor\Controls_Manager::RAW_HTML,
				'default' => '',
				'raw'     => '<div class="elementor-panel-alert elementor-panel-alert-warning">'
					. esc_html__( 'When a customer uses the WooCommerce sort dropdown on the page, their chosen order overrides the setting above automatically.', 'zymarg-wcpg' )
					. '</div>',
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Algolia source: informational notice only - no extra query knobs needed.
	 * The existing total_products + show_oos controls drive hitsPerPage and
	 * the stock filter respectively.
	 */
	private function register_source_algolia_section() {
		$this->start_controls_section(
			'section_source_algolia',
			array(
				'label'     => __( 'Algolia search settings', 'zymarg-wcpg' ),
				'condition' => array( 'source' => 'algolia' ),
			)
		);

		$this->add_control(
			'algolia_info_notice',
			array(
				'type' => \Elementor\Controls_Manager::RAW_HTML,
				'raw'  => '<div class="elementor-panel-alert elementor-panel-alert-info">'
					. '<strong>' . esc_html__( 'How this works', 'zymarg-wcpg' ) . '</strong><br>'
					. esc_html__( 'This source reads the search term from the URL and queries Algolia for ranked results. Place this widget on your Search Results page template in Elementor Theme Builder.', 'zymarg-wcpg' )
					. '<br><br>'
					. esc_html__( 'On all non-search pages it falls back to All Products automatically - so the widget is safe to place anywhere.', 'zymarg-wcpg' )
					. '<br><br>'
					. esc_html__( 'Requires the ZYMARG Algolia Search plugin to be active and configured.', 'zymarg-wcpg' )
					. '</div>',
			)
		);

		$this->add_control(
			'algolia_fallback_notice',
			array(
				'type' => \Elementor\Controls_Manager::RAW_HTML,
				'raw'  => '<div class="elementor-panel-alert elementor-panel-alert-warning">'
					. esc_html__( 'The Order by and Order controls above are ignored for this source - Algolia controls ranking. Use the Total products control to set results per page.', 'zymarg-wcpg' )
					. '</div>',
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Trending source: weights, window, sampling.
	 */
	private function register_source_trending_section() {
		$this->start_controls_section(
			'section_source_trending',
			array(
				'label'     => __( 'Trending source settings', 'zymarg-wcpg' ),
				'condition' => array( 'source' => 'trending' ),
			)
		);

		$this->add_control(
			'trending_window',
			array(
				'label'   => __( 'Time window (days)', 'zymarg-wcpg' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => '7',
				'options' => array(
					'7'  => __( 'Last 7 days', 'zymarg-wcpg' ),
					'14' => __( 'Last 14 days', 'zymarg-wcpg' ),
					'30' => __( 'Last 30 days', 'zymarg-wcpg' ),
				),
			)
		);

		$this->add_control(
			'trending_w_sales',
			array(
				'label'   => __( 'Sales weight', 'zymarg-wcpg' ),
				'type'    => \Elementor\Controls_Manager::SLIDER,
				'range'   => array(
					'px' => array(
						'min' => 0,
						'max' => 100,
					),
				),
				'default' => array(
					'size' => 50,
					'unit' => 'px',
				),
			)
		);

		$this->add_control(
			'trending_w_engagement',
			array(
				'label'   => __( 'Engagement weight', 'zymarg-wcpg' ),
				'type'    => \Elementor\Controls_Manager::SLIDER,
				'range'   => array(
					'px' => array(
						'min' => 0,
						'max' => 100,
					),
				),
				'default' => array(
					'size' => 30,
					'unit' => 'px',
				),
			)
		);

		$this->add_control(
			'trending_w_recency',
			array(
				'label'   => __( 'Recency weight', 'zymarg-wcpg' ),
				'type'    => \Elementor\Controls_Manager::SLIDER,
				'range'   => array(
					'px' => array(
						'min' => 0,
						'max' => 100,
					),
				),
				'default' => array(
					'size' => 20,
					'unit' => 'px',
				),
			)
		);

		$this->add_control(
			'trending_sampling',
			array(
				'label'        => __( 'Sample tracking (large stores)', 'zymarg-wcpg' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default'      => '',
				'description'  => __( 'When on, only 1-in-N events are tracked to reduce DB load. Off by default.', 'zymarg-wcpg' ),
			)
		);

		$this->add_control(
			'trending_sampling_n',
			array(
				'label'     => __( 'Sampling rate (1-in-N)', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::NUMBER,
				'min'       => 2,
				'max'       => 1000,
				'default'   => 10,
				'condition' => array( 'trending_sampling' => 'yes' ),
			)
		);

		$this->add_control(
			'trending_diag_notice',
			array(
				'type' => \Elementor\Controls_Manager::RAW_HTML,
				'raw'  => '<div class="elementor-panel-alert elementor-panel-alert-info">'
					. esc_html__( 'A diagnostics panel with Recompute / Flush / Reset buttons appears in the editor preview when this source is active.', 'zymarg-wcpg' )
					. '</div>',
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Vendor (Dokan) source: order-by, in-stock preference, auto-detect.
	 */
	private function register_source_vendor_section() {
		$this->start_controls_section(
			'section_source_vendor',
			array(
				'label'     => __( 'More From Seller settings', 'zymarg-wcpg' ),
				'condition' => array( 'source' => 'vendor' ),
			)
		);

		$this->add_control(
			'vendor_order_by',
			array(
				'label'   => __( 'Order by', 'zymarg-wcpg' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => 'rating',
				'options' => array(
					'rating' => __( 'Rating (highest first)', 'zymarg-wcpg' ),
					'sales'  => __( 'Sales (best-selling first)', 'zymarg-wcpg' ),
					'date'   => __( 'Date (newest first)', 'zymarg-wcpg' ),
					'price'  => __( 'Price (lowest first)', 'zymarg-wcpg' ),
					'random' => __( 'Random', 'zymarg-wcpg' ),
				),
			)
		);

		$this->add_control(
			'vendor_in_stock',
			array(
				'label'        => __( 'Show only in-stock', 'zymarg-wcpg' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'vendor_auto_detect',
			array(
				'label'        => __( 'Auto-detect product ID', 'zymarg-wcpg' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default'      => 'yes',
				'description'  => __( 'On a single-product page, the current product is used to find its vendor. Disable to specify a product manually.', 'zymarg-wcpg' ),
			)
		);

		$this->add_control(
			'vendor_product_id',
			array(
				'label'     => __( 'Manual product ID', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::NUMBER,
				'min'       => 0,
				'condition' => array( 'vendor_auto_detect!' => 'yes' ),
			)
		);

		$this->add_control(
			'vendor_hide_notice',
			array(
				'type' => \Elementor\Controls_Manager::RAW_HTML,
				'raw'  => '<div class="elementor-panel-alert elementor-panel-alert-info">'
					. esc_html__( 'When the vendor has no other products (or Dokan is not active), the entire widget is hidden.', 'zymarg-wcpg' )
					. '</div>',
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Dynamic source weights + refresh frequency.
	 */
	private function register_source_dynamic_section() {
		$this->start_controls_section(
			'section_source_dynamic',
			array(
				'label'     => __( 'Dynamic source settings', 'zymarg-wcpg' ),
				'condition' => array( 'source' => 'dynamic' ),
			)
		);

		$this->add_control(
			'dynamic_w_recency',
			array(
				'label'   => __( 'Recency weight', 'zymarg-wcpg' ),
				'type'    => \Elementor\Controls_Manager::SLIDER,
				'range'   => array(
					'px' => array(
						'min' => 0,
						'max' => 100,
					),
				),
				'default' => array(
					'size' => 60,
					'unit' => 'px',
				),
			)
		);

		$this->add_control(
			'dynamic_w_rating',
			array(
				'label'   => __( 'Rating weight', 'zymarg-wcpg' ),
				'type'    => \Elementor\Controls_Manager::SLIDER,
				'range'   => array(
					'px' => array(
						'min' => 0,
						'max' => 100,
					),
				),
				'default' => array(
					'size' => 30,
					'unit' => 'px',
				),
			)
		);

		$this->add_control(
			'dynamic_w_sales',
			array(
				'label'   => __( 'Sales weight', 'zymarg-wcpg' ),
				'type'    => \Elementor\Controls_Manager::SLIDER,
				'range'   => array(
					'px' => array(
						'min' => 0,
						'max' => 100,
					),
				),
				'default' => array(
					'size' => 10,
					'unit' => 'px',
				),
			)
		);

		$this->add_control(
			'dynamic_refresh',
			array(
				'label'   => __( 'Refresh frequency', 'zymarg-wcpg' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => 'hour',
				'options' => array(
					'page' => __( 'Per page load (no cache)', 'zymarg-wcpg' ),
					'hour' => __( 'Per hour', 'zymarg-wcpg' ),
					'day'  => __( 'Per day', 'zymarg-wcpg' ),
				),
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Recommended For You source: per-visitor personalised feed.
	 *
	 * Surfaces five weight sliders (category, purchase, brand, seller,
	 * trending) plus behavioural controls (recency penalty, vendor cap,
	 * exclude-already-purchased toggle, cold-start strategy). All weights
	 * are auto-normalised at runtime - their absolute values don't
	 * matter, only the ratio between them does.
	 */
	private function register_source_recommended_section() {
		$this->start_controls_section(
			'section_source_recommended',
			array(
				'label'     => __( 'Recommended For You settings', 'zymarg-wcpg' ),
				'condition' => array( 'source' => 'recommended' ),
			)
		);

		$this->add_control(
			'recommended_info_notice',
			array(
				'type' => \Elementor\Controls_Manager::RAW_HTML,
				'raw'  => '<div class="elementor-panel-alert elementor-panel-alert-info">'
					. '<strong>' . esc_html__( 'How this works', 'zymarg-wcpg' ) . '</strong><br>'
					. esc_html__( 'Builds a per-visitor taste profile from their wishlist, recently-viewed items, purchase history, and engagement events. Each candidate product is scored against the profile across five dimensions. Products viewed in the last 24h get a soft recency penalty so the feed never feels repetitive. Vendor diversity is enforced so a single seller never fills the grid.', 'zymarg-wcpg' )
					. '<br><br>'
					. '<strong>' . esc_html__( 'Cold start', 'zymarg-wcpg' ) . '</strong>: '
					. esc_html__( 'When a visitor has no history yet (brand-new guest, fresh install) the widget falls back to a sensible blend of trending + best-sellers + similar-to-viewed instead of rendering empty.', 'zymarg-wcpg' )
					. '</div>',
			)
		);

		$this->add_control(
			'recommended_weights_heading',
			array(
				'type'      => \Elementor\Controls_Manager::HEADING,
				'label'     => __( 'Scoring weights', 'zymarg-wcpg' ),
				'separator' => 'before',
			)
		);

		$this->add_control(
			'recommended_w_category',
			array(
				'label'       => __( 'Category affinity weight', 'zymarg-wcpg' ),
				'description' => __( 'How strongly we favour products in categories the visitor already engages with.', 'zymarg-wcpg' ),
				'type'        => \Elementor\Controls_Manager::SLIDER,
				'range'       => array(
					'px' => array(
						'min' => 0,
						'max' => 100,
					),
				),
				'default'     => array(
					'size' => 40,
					'unit' => 'px',
				),
			)
		);

		$this->add_control(
			'recommended_w_purchase',
			array(
				'label'       => __( 'Purchase history weight', 'zymarg-wcpg' ),
				'description' => __( 'Boost for items in categories the visitor has actually bought from before. Falls back to category affinity for guests.', 'zymarg-wcpg' ),
				'type'        => \Elementor\Controls_Manager::SLIDER,
				'range'       => array(
					'px' => array(
						'min' => 0,
						'max' => 100,
					),
				),
				'default'     => array(
					'size' => 30,
					'unit' => 'px',
				),
			)
		);

		$this->add_control(
			'recommended_w_brand',
			array(
				'label'       => __( 'Brand affinity weight', 'zymarg-wcpg' ),
				'description' => __( 'Boost for products in brands the visitor engages with. Auto-redistributes to category + purchase weights when no brand taxonomy is detected (product_brand, pwb-brand, or yith_product_brand).', 'zymarg-wcpg' ),
				'type'        => \Elementor\Controls_Manager::SLIDER,
				'range'       => array(
					'px' => array(
						'min' => 0,
						'max' => 100,
					),
				),
				'default'     => array(
					'size' => 15,
					'unit' => 'px',
				),
			)
		);

		$this->add_control(
			'recommended_w_seller',
			array(
				'label'       => __( 'Seller affinity weight', 'zymarg-wcpg' ),
				'description' => __( 'Boost for products from Dokan vendors the visitor engages with. Auto-redistributes to category weight when Dokan is not active.', 'zymarg-wcpg' ),
				'type'        => \Elementor\Controls_Manager::SLIDER,
				'range'       => array(
					'px' => array(
						'min' => 0,
						'max' => 100,
					),
				),
				'default'     => array(
					'size' => 10,
					'unit' => 'px',
				),
			)
		);

		$this->add_control(
			'recommended_w_trending',
			array(
				'label'       => __( 'Trending weight', 'zymarg-wcpg' ),
				'description' => __( 'How much site-wide popularity influences ranking. Small by design — personalisation should beat popularity.', 'zymarg-wcpg' ),
				'type'        => \Elementor\Controls_Manager::SLIDER,
				'range'       => array(
					'px' => array(
						'min' => 0,
						'max' => 100,
					),
				),
				'default'     => array(
					'size' => 5,
					'unit' => 'px',
				),
			)
		);

		$this->add_control(
			'recommended_behaviour_heading',
			array(
				'type'      => \Elementor\Controls_Manager::HEADING,
				'label'     => __( 'Behaviour', 'zymarg-wcpg' ),
				'separator' => 'before',
			)
		);

		$this->add_control(
			'recommended_recency_penalty',
			array(
				'label'        => __( 'Penalise recently-seen products', 'zymarg-wcpg' ),
				'description'  => __( 'Soft penalty (decays over 24 hours) on items the visitor just viewed. Stops the feed from re-showing the same product the user just looked at.', 'zymarg-wcpg' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'recommended_vendor_cap',
			array(
				'label'       => __( 'Max products per vendor in result', 'zymarg-wcpg' ),
				'description' => __( 'Prevents one favourite seller from filling the grid. Set to 0 to disable the cap. Only applies when Dokan is active.', 'zymarg-wcpg' ),
				'type'        => \Elementor\Controls_Manager::NUMBER,
				'min'         => 0,
				'max'         => 20,
				'step'        => 1,
				'default'     => 3,
			)
		);

		$this->add_control(
			'recommended_exclude_purchased',
			array(
				'label'        => __( 'Hide already-purchased products', 'zymarg-wcpg' ),
				'description'  => __( 'When on, items in the visitor\'s recent order history (last 180 days) are excluded. Off for replenishment / consumables stores.', 'zymarg-wcpg' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'recommended_cold_start',
			array(
				'label'       => __( 'Cold-start strategy', 'zymarg-wcpg' ),
				'description' => __( 'What to show when the visitor has no engagement history yet.', 'zymarg-wcpg' ),
				'type'        => \Elementor\Controls_Manager::SELECT,
				'default'     => 'hybrid',
				'options'     => array(
					'hybrid'      => __( 'Hybrid (similar-to-recent + trending + best-sellers)', 'zymarg-wcpg' ),
					'trending'    => __( 'Trending only', 'zymarg-wcpg' ),
					'featured'    => __( 'Featured products', 'zymarg-wcpg' ),
					'bestsellers' => __( 'Best-sellers (lifetime)', 'zymarg-wcpg' ),
				),
			)
		);

		$this->add_control(
			'recommended_diag_notice',
			array(
				'type'      => \Elementor\Controls_Manager::RAW_HTML,
				'raw'       => '<div class="elementor-panel-alert elementor-panel-alert-info">'
					. esc_html__( 'In the Elementor editor preview this source shows a generic placeholder. Personalisation only activates on the live front-end where the visitor\'s cookies, session, and user meta are available.', 'zymarg-wcpg' )
					. '</div>',
				'separator' => 'before',
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Similar source: strictness, price tolerance, in-stock + recency preferences.
	 */
	private function register_source_similar_section() {
		$this->start_controls_section(
			'section_source_similar',
			array(
				'label'     => __( 'Similar source settings', 'zymarg-wcpg' ),
				'condition' => array( 'source' => 'similar' ),
			)
		);

		$this->add_control(
			'similar_strictness',
			array(
				'label'   => __( 'Match strictness', 'zymarg-wcpg' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => 'balanced',
				'options' => array(
					'loose'    => __( 'Loose', 'zymarg-wcpg' ),
					'balanced' => __( 'Balanced', 'zymarg-wcpg' ),
					'strict'   => __( 'Strict', 'zymarg-wcpg' ),
				),
			)
		);

		$this->add_control(
			'similar_price_tolerance',
			array(
				'label'   => __( 'Price tolerance', 'zymarg-wcpg' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => '25',
				'options' => array(
					'10'  => __( '+/- 10%', 'zymarg-wcpg' ),
					'25'  => __( '+/- 25%', 'zymarg-wcpg' ),
					'50'  => __( '+/- 50%', 'zymarg-wcpg' ),
					'any' => __( 'Any price', 'zymarg-wcpg' ),
				),
			)
		);

		$this->add_control(
			'similar_prefer_in_stock',
			array(
				'label'        => __( 'Prefer in-stock', 'zymarg-wcpg' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'similar_prefer_recent',
			array(
				'label'        => __( 'Prefer newer products', 'zymarg-wcpg' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'similar_auto_detect',
			array(
				'label'        => __( 'Auto-detect product ID', 'zymarg-wcpg' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default'      => 'yes',
				'description'  => __( 'On a single-product page, the current product is used. Disable to specify manually.', 'zymarg-wcpg' ),
			)
		);

		$this->add_control(
			'similar_product_id',
			array(
				'label'     => __( 'Manual product ID', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::NUMBER,
				'min'       => 0,
				'condition' => array( 'similar_auto_detect!' => 'yes' ),
			)
		);

		$this->add_control(
			'similar_hide_notice',
			array(
				'type' => \Elementor\Controls_Manager::RAW_HTML,
				'raw'  => '<div class="elementor-panel-alert elementor-panel-alert-info">'
					. esc_html__( 'When no similar products are found, the entire widget is hidden (per locked spec).', 'zymarg-wcpg' )
					. '</div>',
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Recently viewed: empty-state behavior.
	 */
	private function register_source_recent_section() {
		$this->start_controls_section(
			'section_source_recent',
			array(
				'label'     => __( 'Recently viewed settings', 'zymarg-wcpg' ),
				'condition' => array( 'source' => 'recent' ),
			)
		);

		$this->add_control(
			'recent_empty_mode',
			array(
				'label'   => __( 'When empty', 'zymarg-wcpg' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => 'message',
				'options' => array(
					'message' => __( 'Show empty-state message', 'zymarg-wcpg' ),
					'hide'    => __( 'Hide widget entirely', 'zymarg-wcpg' ),
				),
			)
		);

		$this->add_control(
			'recent_track_notice',
			array(
				'type' => \Elementor\Controls_Manager::RAW_HTML,
				'raw'  => '<div class="elementor-panel-alert elementor-panel-alert-info">'
					. esc_html__( 'Every product page view is tracked automatically. Cached pages may need a refresh after viewing a new product.', 'zymarg-wcpg' )
					. '</div>',
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Wishlist: empty-state behavior.
	 */
	private function register_source_wishlist_section() {
		$this->start_controls_section(
			'section_source_wishlist',
			array(
				'label'     => __( 'Wishlist source settings', 'zymarg-wcpg' ),
				'condition' => array( 'source' => 'wishlist' ),
			)
		);

		$this->add_control(
			'wishlist_empty_mode',
			array(
				'label'   => __( 'When empty', 'zymarg-wcpg' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => 'message',
				'options' => array(
					'message' => __( 'Show empty-state message', 'zymarg-wcpg' ),
					'hide'    => __( 'Hide widget entirely', 'zymarg-wcpg' ),
				),
			)
		);

		$this->add_control(
			'wishlist_phase_notice_3a',
			array(
				'type' => \Elementor\Controls_Manager::RAW_HTML,
				'raw'  => '<div class="elementor-panel-alert elementor-panel-alert-info">'
					. esc_html__( 'Wishlist source reads existing wishlist data now. The heart-button toggle that lets visitors add/remove items lands in Phase 4.', 'zymarg-wcpg' )
					. '</div>',
			)
		);

		$this->end_controls_section();
	}
}
