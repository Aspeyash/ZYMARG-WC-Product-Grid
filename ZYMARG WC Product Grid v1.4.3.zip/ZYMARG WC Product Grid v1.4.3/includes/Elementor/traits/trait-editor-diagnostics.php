<?php
/**
 * Editor-preview diagnostics for Trending and More From Seller widgets.
 *
 * Renders an admin-only info panel (with action buttons) inside the
 * Elementor editor preview when these sources are selected. Buttons
 * post to admin-only AJAX endpoints in Admin\Editor_Ajax.
 *
 * @package Zymarg\WCPG
 */

namespace Zymarg\WCPG\Elementor\Traits;

defined( 'ABSPATH' ) || exit;

use Zymarg\WCPG\Trending\Engagement_Store;
use Zymarg\WCPG\Trending\Event_Buffer;
use Zymarg\WCPG\Trending\Trending_Calculator;
use Zymarg\WCPG\Vendor\Vendor_Cache;
use Zymarg\WCPG\Vendor\Vendor_Resolver;

/**
 * Trait Editor_Diagnostics
 */
trait Editor_Diagnostics {

	/**
	 * Render the trending diagnostics panel inside the editor preview.
	 *
	 * Output is scoped to the editor (admin only); it never reaches the
	 * front end because callers gate this behind is_editor_mode().
	 *
	 * @param array $settings Widget settings.
	 */
	protected function render_trending_diagnostics( array $settings ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$meta   = Trending_Calculator::get_meta();
		$cached = Trending_Calculator::get_cached_ids();
		$totals = Engagement_Store::get_window_totals( 7 );
		$buffer = count( Event_Buffer::read() );
		$pruned = Engagement_Store::was_recently_pruned();

		$total_events = 0;
		foreach ( $totals as $t ) {
			$total_events += (int) $t['events'];
		}
		$maturity = (int) min( 100, ( $total_events / max( 1, Trending_Calculator::COLD_START_THRESHOLD ) ) * 100 );
		$last_run = isset( $meta['recomputed_at'] ) ? human_time_diff( (int) $meta['recomputed_at'], time() ) : __( 'never', 'zymarg-wcpg' );

		$top_label = __( '(none yet)', 'zymarg-wcpg' );
		if ( ! empty( $cached[0] ) ) {
			$top_product = wc_get_product( (int) $cached[0] );
			if ( $top_product ) {
				$top_label = $top_product->get_name();
			}
		}

		$nonce = wp_create_nonce( \Zymarg\WCPG\Admin\Editor_Ajax::NONCE_ACTION );
		?>
		<div class="zymarg-wcpg__editor-diag" data-zymarg-diag="trending" data-nonce="<?php echo esc_attr( $nonce ); ?>">
			<div class="zymarg-wcpg__editor-diag-row">
				<strong><?php esc_html_e( 'Trending data status', 'zymarg-wcpg' ); ?></strong>
			</div>
			<ul class="zymarg-wcpg__editor-diag-list">
				<li>
				<?php
					/* translators: %d: percentage of data maturity */
					printf( esc_html__( 'Data maturity: %d%%', 'zymarg-wcpg' ), (int) $maturity );
				?>
					</li>
				<li>
				<?php
					/* translators: %s: number of events */
					printf( esc_html__( 'Events captured (7d): %s', 'zymarg-wcpg' ), esc_html( number_format_i18n( $total_events ) ) );
				?>
					</li>
				<li>
				<?php
					/* translators: %s: human-readable time */
					printf( esc_html__( 'Last recompute: %s ago', 'zymarg-wcpg' ), esc_html( $last_run ) );
				?>
					</li>
				<li>
				<?php
					/* translators: %d: number of buffered events */
					printf( esc_html__( 'Buffered events: %d', 'zymarg-wcpg' ), (int) $buffer );
				?>
					</li>
				<li>
				<?php
					/* translators: %s: top product name */
					printf( esc_html__( 'Top product: %s', 'zymarg-wcpg' ), esc_html( $top_label ) );
				?>
					</li>
				<?php if ( ! empty( $meta['cold_start'] ) ) : ?>
					<li class="is-warn"><?php esc_html_e( 'Cold-start fallback active (using lifetime sales).', 'zymarg-wcpg' ); ?></li>
				<?php endif; ?>
				<?php if ( $pruned ) : ?>
					<li class="is-warn"><?php esc_html_e( 'Engagement aggregate auto-pruned recently. Consider enabling sampling.', 'zymarg-wcpg' ); ?></li>
				<?php endif; ?>
			</ul>
			<div class="zymarg-wcpg__editor-diag-buttons">
				<button type="button" class="zymarg-wcpg__editor-diag-btn" data-action="recompute_trending"><?php esc_html_e( 'Recompute now', 'zymarg-wcpg' ); ?></button>
				<button type="button" class="zymarg-wcpg__editor-diag-btn" data-action="flush_buffer"><?php esc_html_e( 'Flush event buffer', 'zymarg-wcpg' ); ?></button>
				<button type="button" class="zymarg-wcpg__editor-diag-btn is-danger" data-action="reset_trending" data-confirm="<?php esc_attr_e( 'This will wipe all engagement data. Continue?', 'zymarg-wcpg' ); ?>"><?php esc_html_e( 'Reset trending data', 'zymarg-wcpg' ); ?></button>
			</div>
		</div>
		<?php
	}

	/**
	 * Render the vendor diagnostics panel inside the editor preview.
	 *
	 * @param array $settings Widget settings.
	 */
	protected function render_vendor_diagnostics( array $settings ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$detected_ver = Vendor_Resolver::detected_version();
		$supported    = Vendor_Resolver::is_supported();
		$pid          = $this->resolve_vendor_diag_product_id( $settings );
		$vendor_id    = $pid ? Vendor_Resolver::resolve( $pid ) : 0;
		$status       = $vendor_id ? Vendor_Resolver::check_vendor_status( $vendor_id ) : array( 'ok' => false );
		$count        = $vendor_id ? Vendor_Resolver::count_vendor_products( $vendor_id ) : 0;
		$cache_age    = $vendor_id ? Vendor_Cache::age_seconds( $vendor_id ) : null;

		$nonce = wp_create_nonce( \Zymarg\WCPG\Admin\Editor_Ajax::NONCE_ACTION );
		?>
		<div class="zymarg-wcpg__editor-diag" data-zymarg-diag="vendor" data-nonce="<?php echo esc_attr( $nonce ); ?>" data-product-id="<?php echo esc_attr( (int) $pid ); ?>">
			<div class="zymarg-wcpg__editor-diag-row">
				<strong><?php esc_html_e( 'More From Seller status', 'zymarg-wcpg' ); ?></strong>
			</div>
			<ul class="zymarg-wcpg__editor-diag-list">
				<li>
				<?php
					/* translators: %s: detected Dokan version */
					printf( esc_html__( 'Dokan: %s', 'zymarg-wcpg' ), $detected_ver ? esc_html( $detected_ver ) : esc_html__( 'not detected', 'zymarg-wcpg' ) );
					echo $supported ? ' <span class="is-ok">&#10003;</span>' : ' <span class="is-warn">&#9888;</span>';
				?>
					</li>
				<?php if ( $pid <= 0 ) : ?>
					<li class="is-warn"><?php esc_html_e( 'No product context. Place this widget on a single-product page or set a manual product ID.', 'zymarg-wcpg' ); ?></li>
				<?php else : ?>
					<li>
					<?php
						/* translators: %d: product ID being inspected */
						printf( esc_html__( 'Product context: %d', 'zymarg-wcpg' ), (int) $pid );
					?>
						</li>
					<?php if ( $vendor_id ) : ?>
						<?php
						$user = get_user_by( 'id', $vendor_id );
						$name = $user ? $user->display_name : (string) $vendor_id;
						?>
						<li>
						<?php
							/* translators: 1: vendor display name, 2: vendor user ID */
							printf( esc_html__( 'Vendor: %1$s (ID %2$d)', 'zymarg-wcpg' ), esc_html( $name ), (int) $vendor_id );
						?>
							</li>
						<li>
						<?php
							/* translators: %d: number of vendor products */
							printf( esc_html__( 'Products available: %d', 'zymarg-wcpg' ), (int) $count );
						?>
							</li>
						<li>
							<?php
							if ( null === $cache_age ) {
								esc_html_e( 'Cache: none yet', 'zymarg-wcpg' );
							} else {
								/* translators: %d: cache age in seconds */
								printf( esc_html__( 'Cache age: %ds', 'zymarg-wcpg' ), (int) $cache_age );
							}
							?>
						</li>
						<?php if ( empty( $status['ok'] ) && ! empty( $status['reason'] ) ) : ?>
							<li class="is-warn"><?php echo esc_html( $status['reason'] ); ?></li>
						<?php endif; ?>
					<?php else : ?>
						<li class="is-warn"><?php esc_html_e( 'No vendor resolved. Widget will be hidden on the front end.', 'zymarg-wcpg' ); ?></li>
					<?php endif; ?>
				<?php endif; ?>
			</ul>
			<div class="zymarg-wcpg__editor-diag-buttons">
				<button type="button" class="zymarg-wcpg__editor-diag-btn" data-action="clear_vendor_cache"><?php esc_html_e( 'Clear vendor cache', 'zymarg-wcpg' ); ?></button>
				<button type="button" class="zymarg-wcpg__editor-diag-btn" data-action="test_vendor"><?php esc_html_e( 'Test vendor resolution', 'zymarg-wcpg' ); ?></button>
			</div>
		</div>
		<?php
	}

	/**
	 * Resolve which product the vendor diagnostics should target.
	 *
	 * @param array $settings Widget settings.
	 * @return int
	 */
	private function resolve_vendor_diag_product_id( array $settings ) {
		$auto = ! isset( $settings['vendor_auto_detect'] ) || 'yes' === $settings['vendor_auto_detect'];
		if ( ! $auto ) {
			return isset( $settings['vendor_product_id'] ) ? max( 0, (int) $settings['vendor_product_id'] ) : 0;
		}
		if ( function_exists( 'is_product' ) && is_product() ) {
			return (int) get_queried_object_id();
		}
		global $post;
		if ( $post instanceof \WP_Post && 'product' === $post->post_type ) {
			return (int) $post->ID;
		}
		return 0;
	}
}
