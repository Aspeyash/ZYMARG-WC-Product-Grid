<?php
/**
 * Style tab controls. Comprehensive Elementor styling per element.
 *
 * Phase 1 additions:
 *   - Card: hover transition, hover border color, min height, OOS opacity
 *   - Image: aspect ratio, border radius, hover overlay, object fit
 *   - Title: alignment, line height, hover text decoration
 *   - Rating/Sold: star size, divider dimensions, row alignment
 *   - Price: old price typography, alignment, sale price color, price gap
 *   - Vendor: full new style section
 *   - ATC: border, hover border, transition, transform origin, scale slider
 *   - Responsive: atc_size and icon_btn_size converted to responsive
 *   - Per-row: padding and margin controls for all 4 rows
 *
 * @package Zymarg\WCPG
 */

namespace Zymarg\WCPG\Elementor\Traits;

defined( 'ABSPATH' ) || exit;

/**
 * Trait Controls_Style
 */
trait Controls_Style {

	protected function register_style_sections() {
		$this->register_style_card();
		$this->register_style_image();
		$this->register_style_discount_badge();
		$this->register_style_stock_badge();
		$this->register_style_icon_buttons();
		$this->register_style_title();
		$this->register_style_rating_sold();
		$this->register_style_price();
		$this->register_style_vendor();
		$this->register_style_atc();
		$this->register_style_row_spacing();
		$this->register_style_content_layout();
		$this->register_style_empty_state();
	}

	// ----------------------------------------------------------------
	// Card
	// ----------------------------------------------------------------
	private function register_style_card() {
		$this->start_controls_section(
			'section_style_card',
			array(
				'label' => __( 'Card', 'zymarg-wcpg' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			array(
				'name'     => 'card_background',
				'types'    => array( 'classic', 'gradient' ),
				'selector' => '{{WRAPPER}} .zymarg-wcpg__card',
			)
		);

		$this->add_responsive_control(
			'card_min_height',
			array(
				'label'      => __( 'Minimum card height', 'zymarg-wcpg' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array( 'min' => 0, 'max' => 600 ),
				),
				'selectors'  => array(
					'{{WRAPPER}} .zymarg-wcpg__card' => 'min-height: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'card_radius',
			array(
				'label'      => __( 'Border radius', 'zymarg-wcpg' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} .zymarg-wcpg__card' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			array(
				'name'     => 'card_border',
				'selector' => '{{WRAPPER}} .zymarg-wcpg__card',
			)
		);

		$this->add_control(
			'card_border_hover_color',
			array(
				'label'     => __( 'Hover border color', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .zymarg-wcpg__card:hover' => 'border-color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			array(
				'name'     => 'card_shadow',
				'selector' => '{{WRAPPER}} .zymarg-wcpg__card',
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			array(
				'name'     => 'card_shadow_hover',
				'label'    => __( 'Hover shadow', 'zymarg-wcpg' ),
				'selector' => '{{WRAPPER}} .zymarg-wcpg__card:hover',
			)
		);

		$this->add_control(
			'card_transition_duration',
			array(
				'label'      => __( 'Hover transition duration', 'zymarg-wcpg' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => array( 's' ),
				'range'      => array(
					's' => array( 'min' => 0, 'max' => 1, 'step' => 0.05 ),
				),
				'default'    => array( 'size' => 0.2, 'unit' => 's' ),
				'selectors'  => array(
					'{{WRAPPER}} .zymarg-wcpg__card' => 'transition-duration: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'card_transition_easing',
			array(
				'label'     => __( 'Hover transition easing', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::SELECT,
				'default'   => 'ease',
				'options'   => array(
					'ease'        => 'Ease',
					'ease-in'     => 'Ease In',
					'ease-out'    => 'Ease Out',
					'ease-in-out' => 'Ease In Out',
					'linear'      => 'Linear',
				),
				'selectors' => array(
					'{{WRAPPER}} .zymarg-wcpg__card' => 'transition-timing-function: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'card_oos_opacity',
			array(
				'label'     => __( 'Out of stock opacity', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::SLIDER,
				'range'     => array(
					'px' => array( 'min' => 0.1, 'max' => 1, 'step' => 0.05 ),
				),
				'default'   => array( 'size' => 0.6, 'unit' => 'px' ),
				'selectors' => array(
					'{{WRAPPER}} .zymarg-wcpg__card.is-oos' => 'opacity: {{SIZE}};',
				),
			)
		);

		$this->add_responsive_control(
			'card_padding',
			array(
				'label'      => __( 'Content box padding', 'zymarg-wcpg' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px' ),
				'selectors'  => array(
					'{{WRAPPER}} .zymarg-wcpg__content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'grid_gap',
			array(
				'label'     => __( 'Grid gap', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::SLIDER,
				'range'     => array(
					'px' => array( 'min' => 0, 'max' => 60 ),
				),
				'default'   => array( 'size' => 20, 'unit' => 'px' ),
				'selectors' => array(
					'{{WRAPPER}} .zymarg-wcpg__grid' => 'gap: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'content_row_gap',
			array(
				'label'     => __( 'Row gap (between rows)', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::SLIDER,
				'range'     => array(
					'px' => array( 'min' => 0, 'max' => 32 ),
				),
				'default'   => array( 'size' => 8, 'unit' => 'px' ),
				'selectors' => array(
					'{{WRAPPER}} .zymarg-wcpg__content' => 'gap: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();
	}

	// ----------------------------------------------------------------
	// Image
	// ----------------------------------------------------------------
	private function register_style_image() {
		$this->start_controls_section(
			'section_style_image',
			array(
				'label'     => __( 'Image', 'zymarg-wcpg' ),
				'tab'       => \Elementor\Controls_Manager::TAB_STYLE,
				'condition' => array( 'show_image' => 'yes' ),
			)
		);

		$this->add_control(
			'image_aspect_ratio',
			array(
				'label'     => __( 'Aspect ratio', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::SELECT,
				'default'   => '1 / 1',
				'options'   => array(
					'1 / 1'  => '1:1 Square (default)',
					'4 / 3'  => '4:3 Landscape',
					'3 / 4'  => '3:4 Portrait',
					'16 / 9' => '16:9 Widescreen',
					'custom' => __( 'Custom height', 'zymarg-wcpg' ),
				),
				'selectors' => array(
					'{{WRAPPER}} .zymarg-wcpg__image-container' => 'aspect-ratio: {{VALUE}};',
				),
				'description' => __( '"Custom height" is ignored by the browser as an aspect-ratio value; the Custom height control below then sets the height directly.', 'zymarg-wcpg' ),
			)
		);

		$this->add_responsive_control(
			'image_custom_height',
			array(
				'label'      => __( 'Custom height', 'zymarg-wcpg' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => array( 'px', 'vw' ),
				'range'      => array(
					'px'  => array( 'min' => 50, 'max' => 600 ),
					'vw'  => array( 'min' => 5,  'max' => 100 ),
				),
				'condition'  => array( 'image_aspect_ratio' => 'custom' ),
				'selectors'  => array(
					'{{WRAPPER}} .zymarg-wcpg__image-container' => 'aspect-ratio: unset; height: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'image_border_radius',
			array(
				'label'      => __( 'Image border radius', 'zymarg-wcpg' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} .zymarg-wcpg__image-container' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .zymarg-wcpg__image'           => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'image_object_fit',
			array(
				'label'     => __( 'Object fit', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::SELECT,
				'default'   => 'cover',
				'options'   => array(
					'cover'   => 'Cover (default)',
					'contain' => 'Contain',
					'fill'    => 'Fill',
				),
				'selectors' => array(
					'{{WRAPPER}} .zymarg-wcpg__image' => 'object-fit: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'image_zoom_scale',
			array(
				'label'     => __( 'Hover zoom scale', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::SLIDER,
				'range'     => array(
					'px' => array( 'min' => 1, 'max' => 1.5, 'step' => 0.01 ),
				),
				'default'   => array( 'size' => 1.06, 'unit' => 'px' ),
				'selectors' => array(
					'{{WRAPPER}} .zymarg-wcpg__image-container.has-zoom:hover .zymarg-wcpg__image' => 'transform: scale({{SIZE}});',
				),
				'condition' => array( 'image_hover_zoom' => 'yes' ),
			)
		);

		$this->add_control(
			'image_overlay_color',
			array(
				'label'     => __( 'Hover overlay color', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}} .zymarg-wcpg__image-container::after' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'image_overlay_opacity',
			array(
				'label'     => __( 'Hover overlay opacity', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::SLIDER,
				'range'     => array(
					'px' => array( 'min' => 0, 'max' => 1, 'step' => 0.05 ),
				),
				'default'   => array( 'size' => 0.3, 'unit' => 'px' ),
				'selectors' => array(
					'{{WRAPPER}} .zymarg-wcpg__image-container::after' => 'opacity: {{SIZE}};',
				),
				'condition' => array( 'image_overlay_color[color]!' => '' ),
			)
		);

		$this->end_controls_section();
	}

	// ----------------------------------------------------------------
	// Discount badge
	// ----------------------------------------------------------------
	private function register_style_discount_badge() {
		$this->start_controls_section(
			'section_style_discount',
			array(
				'label'     => __( 'Discount badge', 'zymarg-wcpg' ),
				'tab'       => \Elementor\Controls_Manager::TAB_STYLE,
				'condition' => array( 'show_discount_badge' => 'yes' ),
			)
		);

		$this->add_control(
			'discount_bg',
			array(
				'label'     => __( 'Background', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#e53935',
				'selectors' => array(
					'{{WRAPPER}} .zymarg-wcpg__badge--discount' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'discount_color',
			array(
				'label'     => __( 'Text color', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => array(
					'{{WRAPPER}} .zymarg-wcpg__badge--discount' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			array(
				'name'     => 'discount_typography',
				'selector' => '{{WRAPPER}} .zymarg-wcpg__badge--discount',
			)
		);

		$this->end_controls_section();
	}

	// ----------------------------------------------------------------
	// Stock badge
	// ----------------------------------------------------------------
	private function register_style_stock_badge() {
		$this->start_controls_section(
			'section_style_stock',
			array(
				'label'     => __( 'Stock badge', 'zymarg-wcpg' ),
				'tab'       => \Elementor\Controls_Manager::TAB_STYLE,
				'condition' => array( 'show_stock_badge' => 'yes' ),
			)
		);

		$this->add_control(
			'stock_in_bg',
			array(
				'label'     => __( 'In-stock background', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#43a047',
				'selectors' => array(
					'{{WRAPPER}} .zymarg-wcpg__badge--stock-in' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'stock_in_color',
			array(
				'label'     => __( 'In-stock text', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => array(
					'{{WRAPPER}} .zymarg-wcpg__badge--stock-in' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'stock_out_bg',
			array(
				'label'     => __( 'Out-of-stock background', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#757575',
				'selectors' => array(
					'{{WRAPPER}} .zymarg-wcpg__badge--stock-out' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'stock_out_color',
			array(
				'label'     => __( 'Out-of-stock text', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => array(
					'{{WRAPPER}} .zymarg-wcpg__badge--stock-out' => 'color: {{VALUE}};',
				),
			)
		);

		// v1.3.26: typography group control for the stock badge.
		// Targets both in-stock and out-of-stock variants so they stay
		// visually consistent.
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			array(
				'name'     => 'stock_badge_typography',
				'label'    => __( 'Typography', 'zymarg-wcpg' ),
				'selector' => '{{WRAPPER}} .zymarg-wcpg__badge--stock-in, {{WRAPPER}} .zymarg-wcpg__badge--stock-out',
			)
		);

		$this->end_controls_section();
	}

	// ----------------------------------------------------------------
	// Icon buttons (wishlist + quick view)
	// ----------------------------------------------------------------
	private function register_style_icon_buttons() {
		$this->start_controls_section(
			'section_style_icons',
			array(
				'label' => __( 'Icon buttons (wishlist & quick view)', 'zymarg-wcpg' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_responsive_control(
			'icon_btn_size',
			array(
				'label'     => __( 'Button size', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::SLIDER,
				'range'     => array(
					'px' => array( 'min' => 24, 'max' => 64 ),
				),
				'default'   => array( 'size' => 36, 'unit' => 'px' ),
				'selectors' => array(
					'{{WRAPPER}} .zymarg-wcpg__icon-btn--wishlist, {{WRAPPER}} .zymarg-wcpg__icon-btn--quickview' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'icon_btn_bg',
			array(
				'label'     => __( 'Background', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => array(
					'{{WRAPPER}} .zymarg-wcpg__icon-btn--wishlist, {{WRAPPER}} .zymarg-wcpg__icon-btn--quickview' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'icon_btn_color',
			array(
				'label'     => __( 'Icon color', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#333333',
				'selectors' => array(
					'{{WRAPPER}} .zymarg-wcpg__icon-btn--wishlist, {{WRAPPER}} .zymarg-wcpg__icon-btn--quickview' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'icon_btn_hover_bg',
			array(
				'label'     => __( 'Hover background', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .zymarg-wcpg__icon-btn--wishlist:hover, {{WRAPPER}} .zymarg-wcpg__icon-btn--quickview:hover' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'icon_btn_hover_color',
			array(
				'label'     => __( 'Hover icon color', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .zymarg-wcpg__icon-btn--wishlist:hover, {{WRAPPER}} .zymarg-wcpg__icon-btn--quickview:hover' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'wishlist_active_color',
			array(
				'label'     => __( 'Wishlist active color', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#e53935',
				'selectors' => array(
					'{{WRAPPER}} .zymarg-wcpg__icon-btn--wishlist[aria-pressed="true"]' => 'color: {{VALUE}};',
				),
				'condition' => array( 'show_wishlist' => 'yes' ),
			)
		);

		$this->end_controls_section();
	}

	// ----------------------------------------------------------------
	// Title
	// ----------------------------------------------------------------
	private function register_style_title() {
		$this->start_controls_section(
			'section_style_title',
			array(
				'label'     => __( 'Title', 'zymarg-wcpg' ),
				'tab'       => \Elementor\Controls_Manager::TAB_STYLE,
				'condition' => array( 'show_title' => 'yes' ),
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			array(
				'name'     => 'title_typography',
				'selector' => '{{WRAPPER}} .zymarg-wcpg__title',
			)
		);

		$this->add_control(
			'title_color',
			array(
				'label'     => __( 'Color', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#1a1a1a',
				'selectors' => array(
					'{{WRAPPER}} .zymarg-wcpg__title' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'title_hover_color',
			array(
				'label'     => __( 'Hover color', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .zymarg-wcpg__title-link:hover .zymarg-wcpg__title' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_responsive_control(
			'title_alignment',
			array(
				'label'     => __( 'Alignment', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::CHOOSE,
				'options'   => array(
					'left'   => array( 'title' => __( 'Left', 'zymarg-wcpg' ),   'icon' => 'eicon-text-align-left' ),
					'center' => array( 'title' => __( 'Center', 'zymarg-wcpg' ), 'icon' => 'eicon-text-align-center' ),
					'right'  => array( 'title' => __( 'Right', 'zymarg-wcpg' ),  'icon' => 'eicon-text-align-right' ),
				),
				'default'   => 'left',
				'selectors' => array(
					'{{WRAPPER}} .zymarg-wcpg__title' => 'text-align: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'title_hover_decoration',
			array(
				'label'     => __( 'Hover text decoration', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::SELECT,
				'default'   => 'none',
				'options'   => array(
					'none'      => __( 'None', 'zymarg-wcpg' ),
					'underline' => __( 'Underline', 'zymarg-wcpg' ),
				),
				'selectors' => array(
					'{{WRAPPER}} .zymarg-wcpg__title-link:hover .zymarg-wcpg__title' => 'text-decoration: {{VALUE}};',
				),
			)
		);

		$this->end_controls_section();
	}

	// ----------------------------------------------------------------
	// Rating + sold count
	// ----------------------------------------------------------------
	private function register_style_rating_sold() {
		$this->start_controls_section(
			'section_style_rating',
			array(
				'label' => __( 'Rating & sold count', 'zymarg-wcpg' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'rating_star_size',
			array(
				'label'     => __( 'Star size', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::SLIDER,
				'range'     => array(
					'px' => array( 'min' => 10, 'max' => 30 ),
				),
				'default'   => array( 'size' => 14, 'unit' => 'px' ),
				'selectors' => array(
					'{{WRAPPER}} .zymarg-wcpg__rating-stars' => 'font-size: {{SIZE}}{{UNIT}}; width: calc({{SIZE}}{{UNIT}} * 5.5); height: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'rating_color',
			array(
				'label'     => __( 'Star color', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#fbc02d',
				'selectors' => array(
					'{{WRAPPER}} .zymarg-wcpg__rating-fill' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'rating_empty_color',
			array(
				'label'     => __( 'Empty star color', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#e0e0e0',
				'selectors' => array(
					'{{WRAPPER}} .zymarg-wcpg__rating-stars' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'divider_width',
			array(
				'label'     => __( 'Divider width', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::SLIDER,
				'range'     => array(
					'px' => array( 'min' => 1, 'max' => 4 ),
				),
				'default'   => array( 'size' => 1, 'unit' => 'px' ),
				'selectors' => array(
					'{{WRAPPER}} .zymarg-wcpg__divider' => 'width: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'divider_height',
			array(
				'label'     => __( 'Divider height', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::SLIDER,
				'range'     => array(
					'px' => array( 'min' => 6, 'max' => 24 ),
				),
				'default'   => array( 'size' => 12, 'unit' => 'px' ),
				'selectors' => array(
					'{{WRAPPER}} .zymarg-wcpg__divider' => 'height: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'divider_color',
			array(
				'label'     => __( 'Divider color', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#e0e0e0',
				'selectors' => array(
					'{{WRAPPER}} .zymarg-wcpg__divider' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			array(
				'name'     => 'sold_typography',
				'selector' => '{{WRAPPER}} .zymarg-wcpg__sold',
			)
		);

		$this->add_control(
			'sold_color',
			array(
				'label'     => __( 'Sold count color', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#666666',
				'selectors' => array(
					'{{WRAPPER}} .zymarg-wcpg__sold' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_responsive_control(
			'meta_row_alignment',
			array(
				'label'     => __( 'Row alignment', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::CHOOSE,
				'options'   => array(
					'flex-start' => array( 'title' => __( 'Left', 'zymarg-wcpg' ),   'icon' => 'eicon-text-align-left' ),
					'center'     => array( 'title' => __( 'Center', 'zymarg-wcpg' ), 'icon' => 'eicon-text-align-center' ),
					'flex-end'   => array( 'title' => __( 'Right', 'zymarg-wcpg' ),  'icon' => 'eicon-text-align-right' ),
				),
				'default'   => 'flex-start',
				'selectors' => array(
					'{{WRAPPER}} .zymarg-wcpg__meta' => 'justify-content: {{VALUE}};',
				),
			)
		);

		$this->end_controls_section();
	}

	// ----------------------------------------------------------------
	// Price
	// ----------------------------------------------------------------
	private function register_style_price() {
		$this->start_controls_section(
			'section_style_price',
			array(
				'label'     => __( 'Price', 'zymarg-wcpg' ),
				'tab'       => \Elementor\Controls_Manager::TAB_STYLE,
				'condition' => array( 'show_price' => 'yes' ),
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			array(
				'name'     => 'price_typography',
				'selector' => '{{WRAPPER}} .zymarg-wcpg__price-current',
			)
		);

		$this->add_control(
			'price_color',
			array(
				'label'     => __( 'Current price color', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#1a1a1a',
				'selectors' => array(
					'{{WRAPPER}} .zymarg-wcpg__price-current' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'price_sale_color',
			array(
				'label'     => __( 'Sale price color', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .zymarg-wcpg__card.is-on-sale .zymarg-wcpg__price-current' => 'color: {{VALUE}};',
				),
				'description' => __( 'Overrides current price color when the product is on sale.', 'zymarg-wcpg' ),
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			array(
				'name'     => 'price_old_typography',
				'label'    => __( 'Old price typography', 'zymarg-wcpg' ),
				'selector' => '{{WRAPPER}} .zymarg-wcpg__price-old',
			)
		);

		$this->add_control(
			'price_old_color',
			array(
				'label'     => __( 'Old price color', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#999999',
				'selectors' => array(
					'{{WRAPPER}} .zymarg-wcpg__price-old' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'price_gap',
			array(
				'label'     => __( 'Gap between current and old price', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::SLIDER,
				'range'     => array(
					'px' => array( 'min' => 0, 'max' => 24 ),
				),
				'default'   => array( 'size' => 6, 'unit' => 'px' ),
				'selectors' => array(
					'{{WRAPPER}} .zymarg-wcpg__price' => 'gap: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'price_alignment',
			array(
				'label'     => __( 'Alignment', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::CHOOSE,
				'options'   => array(
					'flex-start' => array( 'title' => __( 'Left', 'zymarg-wcpg' ),   'icon' => 'eicon-text-align-left' ),
					'center'     => array( 'title' => __( 'Center', 'zymarg-wcpg' ), 'icon' => 'eicon-text-align-center' ),
					'flex-end'   => array( 'title' => __( 'Right', 'zymarg-wcpg' ),  'icon' => 'eicon-text-align-right' ),
				),
				'default'   => 'flex-start',
				'selectors' => array(
					'{{WRAPPER}} .zymarg-wcpg__price' => 'justify-content: {{VALUE}};',
				),
			)
		);

		$this->end_controls_section();
	}

	// ----------------------------------------------------------------
	// Vendor (new section - was missing entirely)
	// ----------------------------------------------------------------
	private function register_style_vendor() {
		$this->start_controls_section(
			'section_style_vendor',
			array(
				'label'     => __( 'Vendor profile', 'zymarg-wcpg' ),
				'tab'       => \Elementor\Controls_Manager::TAB_STYLE,
				'condition' => array( 'show_vendor' => 'yes' ),
			)
		);

		$this->add_control(
			'vendor_row_bg',
			array(
				'label'     => __( 'Row background', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .zymarg-wcpg__row--vendor' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			array(
				'name'     => 'vendor_name_typography',
				'label'    => __( 'Store name typography', 'zymarg-wcpg' ),
				'selector' => '{{WRAPPER}} .zymarg-wcpg__vendor-name',
			)
		);

		$this->add_control(
			'vendor_name_color',
			array(
				'label'     => __( 'Store name color', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#534152',
				'selectors' => array(
					'{{WRAPPER}} .zymarg-wcpg__vendor-name' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'vendor_name_hover_color',
			array(
				'label'     => __( 'Store name hover color', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#6833EA',
				'selectors' => array(
					'{{WRAPPER}} a.zymarg-wcpg__vendor-inner:hover .zymarg-wcpg__vendor-name' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			array(
				'name'     => 'vendor_location_typography',
				'label'    => __( 'Location typography', 'zymarg-wcpg' ),
				'selector' => '{{WRAPPER}} .zymarg-wcpg__vendor-location',
			)
		);

		$this->add_control(
			'vendor_location_color',
			array(
				'label'     => __( 'Location color', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#999999',
				'selectors' => array(
					'{{WRAPPER}} .zymarg-wcpg__vendor-location' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_responsive_control(
			'vendor_avatar_border_radius',
			array(
				'label'      => __( 'Avatar border radius', 'zymarg-wcpg' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} .zymarg-wcpg__vendor-avatar' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
				'description' => __( 'Overrides the shape setting (circle/rounded/square).', 'zymarg-wcpg' ),
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			array(
				'name'     => 'vendor_avatar_border',
				'label'    => __( 'Avatar border', 'zymarg-wcpg' ),
				'selector' => '{{WRAPPER}} .zymarg-wcpg__vendor-avatar',
			)
		);

		$this->end_controls_section();
	}

	// ----------------------------------------------------------------
	// ATC button
	// ----------------------------------------------------------------
	private function register_style_atc() {
		$this->start_controls_section(
			'section_style_atc',
			array(
				'label'     => __( 'Add to cart button', 'zymarg-wcpg' ),
				'tab'       => \Elementor\Controls_Manager::TAB_STYLE,
				'condition' => array( 'show_atc' => 'yes' ),
			)
		);

		$this->add_responsive_control(
			'atc_size',
			array(
				'label'     => __( 'Size', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::SLIDER,
				'range'     => array(
					'px' => array( 'min' => 28, 'max' => 64 ),
				),
				'default'   => array( 'size' => 40, 'unit' => 'px' ),
				'selectors' => array(
					'{{WRAPPER}} .zymarg-wcpg__icon-btn--atc' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'atc_bg',
			array(
				'label'     => __( 'Background', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#1a1a1a',
				'selectors' => array(
					'{{WRAPPER}} .zymarg-wcpg__icon-btn--atc' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'atc_color',
			array(
				'label'     => __( 'Icon color', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => array(
					'{{WRAPPER}} .zymarg-wcpg__icon-btn--atc' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			array(
				'name'     => 'atc_border',
				'selector' => '{{WRAPPER}} .zymarg-wcpg__icon-btn--atc',
			)
		);

		$this->add_control(
			'atc_radius',
			array(
				'label'      => __( 'Border radius', 'zymarg-wcpg' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} .zymarg-wcpg__icon-btn--atc' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'atc_hover_bg',
			array(
				'label'     => __( 'Hover background', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .zymarg-wcpg__icon-btn--atc:hover' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'atc_hover_color',
			array(
				'label'     => __( 'Hover icon color', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .zymarg-wcpg__icon-btn--atc:hover' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'atc_hover_border_color',
			array(
				'label'     => __( 'Hover border color', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .zymarg-wcpg__icon-btn--atc:hover' => 'border-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'atc_transition_duration',
			array(
				'label'      => __( 'Transition duration', 'zymarg-wcpg' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => array( 's' ),
				'range'      => array(
					's' => array( 'min' => 0, 'max' => 1, 'step' => 0.05 ),
				),
				'default'    => array( 'size' => 0.2, 'unit' => 's' ),
				'selectors'  => array(
					'{{WRAPPER}} .zymarg-wcpg__icon-btn--atc' => 'transition-duration: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();
	}

	// ----------------------------------------------------------------
	// Per-row spacing (padding + margin for all 4 rows)
	// ----------------------------------------------------------------
	private function register_style_row_spacing() {
		$this->start_controls_section(
			'section_style_row_spacing',
			array(
				'label' => __( 'Row spacing (padding & margin)', 'zymarg-wcpg' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		// Row 1 - Title
		$this->add_control(
			'row_title_heading',
			array(
				'label' => __( 'Row 1 - Title', 'zymarg-wcpg' ),
				'type'  => \Elementor\Controls_Manager::HEADING,
			)
		);

		$this->add_responsive_control(
			'row_title_padding',
			array(
				'label'      => __( 'Padding', 'zymarg-wcpg' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'em' ),
				'selectors'  => array(
					'{{WRAPPER}} .zymarg-wcpg__row--title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'row_title_margin',
			array(
				'label'      => __( 'Margin', 'zymarg-wcpg' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'em' ),
				'selectors'  => array(
					'{{WRAPPER}} .zymarg-wcpg__row--title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'row_meta_heading',
			array(
				'label'     => __( 'Row 2 - Rating & Sold Count', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			)
		);

		$this->add_responsive_control(
			'row_meta_padding',
			array(
				'label'      => __( 'Padding', 'zymarg-wcpg' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'em' ),
				'selectors'  => array(
					'{{WRAPPER}} .zymarg-wcpg__row--meta' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'row_meta_margin',
			array(
				'label'      => __( 'Margin', 'zymarg-wcpg' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'em' ),
				'selectors'  => array(
					'{{WRAPPER}} .zymarg-wcpg__row--meta' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'row_price_heading',
			array(
				'label'     => __( 'Row 3 - Price & Add to Cart', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			)
		);

		$this->add_responsive_control(
			'row_price_padding',
			array(
				'label'      => __( 'Padding', 'zymarg-wcpg' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'em' ),
				'selectors'  => array(
					'{{WRAPPER}} .zymarg-wcpg__row--price' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'row_price_margin',
			array(
				'label'      => __( 'Margin', 'zymarg-wcpg' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'em' ),
				'selectors'  => array(
					'{{WRAPPER}} .zymarg-wcpg__row--price' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'row_vendor_heading',
			array(
				'label'     => __( 'Vendor Profile', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			)
		);

		$this->add_responsive_control(
			'row_vendor_padding',
			array(
				'label'      => __( 'Padding', 'zymarg-wcpg' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'em' ),
				'selectors'  => array(
					'{{WRAPPER}} .zymarg-wcpg__row--vendor' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'row_vendor_margin',
			array(
				'label'      => __( 'Margin', 'zymarg-wcpg' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'em' ),
				'selectors'  => array(
					'{{WRAPPER}} .zymarg-wcpg__row--vendor' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();
	}

	// ----------------------------------------------------------------
	// Content Box Spacing (v1.3.26, simplified in v1.3.27)
	//
	// Per-row gap controls for every row in the content box. All
	// controls are responsive (separate values per desktop / tablet /
	// mobile breakpoint). Defaults match the base CSS so a fresh
	// install renders identically - controls only kick in when the
	// user sets a value.
	//
	// v1.3.27: per-element max-width controls were removed in favour
	// of a simpler gap-only spec. If you need per-element width
	// control later, restore the controls registered between
	// register_style_row_spacing() and here in v1.3.26 git history.
	// ----------------------------------------------------------------
	private function register_style_content_layout() {
		$this->start_controls_section(
			'section_style_content_layout',
			array(
				'label' => __( 'Content Box Spacing', 'zymarg-wcpg' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		// ── Content rows ─────────────────────────────────────────────
		$this->add_control(
			'cbl_heading_rows',
			array(
				'label' => __( 'Content rows', 'zymarg-wcpg' ),
				'type'  => \Elementor\Controls_Manager::HEADING,
			)
		);

		$this->add_responsive_control(
			'cbl_rows_gap',
			array(
				'label'      => __( 'Gap between rows', 'zymarg-wcpg' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array( 'px' => array( 'min' => 0, 'max' => 40 ) ),
				'selectors'  => array(
					'{{WRAPPER}} .zymarg-wcpg__content' => 'gap: {{SIZE}}{{UNIT}};',
				),
			)
		);

		// ── Meta row ─────────────────────────────────────────────────
		$this->add_control(
			'cbl_heading_meta',
			array(
				'label'     => __( 'Meta row (stock badge / rating / sold count)', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			)
		);

		$this->add_responsive_control(
			'cbl_meta_gap',
			array(
				'label'      => __( 'Gap between elements', 'zymarg-wcpg' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array( 'px' => array( 'min' => 0, 'max' => 30 ) ),
				'selectors'  => array(
					'{{WRAPPER}} .zymarg-wcpg__meta' => 'gap: {{SIZE}}{{UNIT}};',
				),
			)
		);

		// ── Price row ────────────────────────────────────────────────
		$this->add_control(
			'cbl_heading_price',
			array(
				'label'     => __( 'Price row (price / discount badge / ATC)', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			)
		);

		$this->add_responsive_control(
			'cbl_price_gap',
			array(
				'label'      => __( 'Gap between elements', 'zymarg-wcpg' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array( 'px' => array( 'min' => 0, 'max' => 30 ) ),
				'selectors'  => array(
					'{{WRAPPER}} .zymarg-wcpg__row--price' => 'gap: {{SIZE}}{{UNIT}};',
				),
			)
		);

		// ── Vendor row ───────────────────────────────────────────────
		$this->add_control(
			'cbl_heading_vendor',
			array(
				'label'     => __( 'Vendor row (avatar / name / location)', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			)
		);

		$this->add_responsive_control(
			'cbl_vendor_gap',
			array(
				'label'      => __( 'Gap between elements', 'zymarg-wcpg' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array( 'px' => array( 'min' => 0, 'max' => 30 ) ),
				'selectors'  => array(
					'{{WRAPPER}} .zymarg-wcpg__vendor-inner' => 'gap: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();
	}

	// ----------------------------------------------------------------
	// Empty state
	// ----------------------------------------------------------------
	private function register_style_empty_state() {
		$this->start_controls_section(
			'section_style_empty',
			array(
				'label' => __( 'Empty state', 'zymarg-wcpg' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			array(
				'name'     => 'empty_typography',
				'selector' => '{{WRAPPER}} .zymarg-wcpg__empty',
			)
		);

		$this->add_control(
			'empty_color',
			array(
				'label'     => __( 'Color', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#666666',
				'selectors' => array(
					'{{WRAPPER}} .zymarg-wcpg__empty' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'empty_bg',
			array(
				'label'     => __( 'Background', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#f9f9f9',
				'selectors' => array(
					'{{WRAPPER}} .zymarg-wcpg__empty' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->end_controls_section();
	}
}
