<?php
/**
 * Settings tab controls (Tab 2). One section per card element with toggle.
 *
 * @package Zymarg\WCPG
 */

namespace Zymarg\WCPG\Elementor\Traits;

defined( 'ABSPATH' ) || exit;

/**
 * Trait Controls_Settings
 *
 * Each card element gets its own collapsible section in the Content tab so
 * editors can toggle elements independently and configure per-element options
 * (icon picker, mode, etc.) without scrolling through one giant section.
 */
trait Controls_Settings {

	/**
	 * Register all element-toggle sections.
	 */
	protected function register_settings_sections() {
		$this->register_image_settings();
		$this->register_discount_badge_settings();
		$this->register_stock_badge_settings();
		$this->register_wishlist_settings();
		$this->register_quickview_settings();
		$this->register_title_settings();
		$this->register_vendor_settings();
		$this->register_rating_sold_settings();
		$this->register_price_settings();
		$this->register_atc_settings();
	}

	/**
	 * Image settings.
	 */
	private function register_image_settings() {
		$this->start_controls_section(
			'section_settings_image',
			array(
				'label' => __( 'Image', 'zymarg-wcpg' ),
			)
		);

		$this->add_control(
			'show_image',
			array(
				'label'        => __( 'Show image', 'zymarg-wcpg' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'image_full_resolution',
			array(
				'label'        => __( 'Use full resolution', 'zymarg-wcpg' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default'      => '',
				'description'  => __( 'May increase page load time on large grids.', 'zymarg-wcpg' ),
				'condition'    => array( 'show_image' => 'yes' ),
			)
		);

		$this->add_control(
			'image_hover_zoom',
			array(
				'label'        => __( 'Hover zoom', 'zymarg-wcpg' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default'      => 'yes',
				'condition'    => array( 'show_image' => 'yes' ),
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Discount badge settings.
	 */
	private function register_discount_badge_settings() {
		$this->start_controls_section(
			'section_settings_discount',
			array(
				'label' => __( 'Discount badge', 'zymarg-wcpg' ),
			)
		);

		$this->add_control(
			'show_discount_badge',
			array(
				'label'        => __( 'Show discount badge', 'zymarg-wcpg' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'discount_badge_mode',
			array(
				'label'     => __( 'Mode', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::SELECT,
				'default'   => 'percent',
				'options'   => array(
					'percent' => __( 'Percentage', 'zymarg-wcpg' ),
					'amount'  => __( 'Amount', 'zymarg-wcpg' ),
					'both'    => __( 'Both', 'zymarg-wcpg' ),
				),
				'condition' => array( 'show_discount_badge' => 'yes' ),
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Stock badge settings.
	 */
	private function register_stock_badge_settings() {
		$this->start_controls_section(
			'section_settings_stock',
			array(
				'label' => __( 'Stock badge', 'zymarg-wcpg' ),
			)
		);

		$this->add_control(
			'show_stock_badge',
			array(
				'label'        => __( 'Show stock badge', 'zymarg-wcpg' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'show_stock_in',
			array(
				'label'        => __( 'Show "In stock"', 'zymarg-wcpg' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default'      => '',
				'condition'    => array( 'show_stock_badge' => 'yes' ),
			)
		);

		$this->add_control(
			'show_stock_out',
			array(
				'label'        => __( 'Show "Out of stock"', 'zymarg-wcpg' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default'      => 'yes',
				'condition'    => array( 'show_stock_badge' => 'yes' ),
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Wishlist CTA settings.
	 */
	private function register_wishlist_settings() {
		$this->start_controls_section(
			'section_settings_wishlist',
			array(
				'label' => __( 'Wishlist CTA', 'zymarg-wcpg' ),
			)
		);

		$this->add_control(
			'show_wishlist',
			array(
				'label'        => __( 'Show wishlist', 'zymarg-wcpg' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'wishlist_icon',
			array(
				'label'     => __( 'Idle icon', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::ICONS,
				'default'   => array(
					'value'   => 'far fa-heart',
					'library' => 'fa-regular',
				),
				'condition' => array( 'show_wishlist' => 'yes' ),
			)
		);

		$this->add_control(
			'wishlist_icon_active',
			array(
				'label'     => __( 'Active icon', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::ICONS,
				'default'   => array(
					'value'   => 'fas fa-heart',
					'library' => 'fa-solid',
				),
				'condition' => array( 'show_wishlist' => 'yes' ),
			)
		);

		$this->add_control(
			'wishlist_phase_notice',
			array(
				'type' => \Elementor\Controls_Manager::RAW_HTML,
				'raw'  => '<div class="elementor-panel-alert elementor-panel-alert-info">'
					. esc_html__( 'Wishlist storage and AJAX toggle ship in Phases 4 + 7. The icon renders and is fully styleable now.', 'zymarg-wcpg' )
					. '</div>',
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Quick view CTA settings.
	 */
	private function register_quickview_settings() {
		$this->start_controls_section(
			'section_settings_quickview',
			array(
				'label' => __( 'Quick view CTA', 'zymarg-wcpg' ),
			)
		);

		$this->add_control(
			'show_quickview',
			array(
				'label'        => __( 'Show quick view', 'zymarg-wcpg' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'quickview_visibility',
			array(
				'label'       => __( 'Visible on', 'zymarg-wcpg' ),
				'type'        => \Elementor\Controls_Manager::SELECT,
				'default'     => 'desktop',
				'options'     => array(
					'desktop'         => __( 'Desktop only  (>=1025px)', 'zymarg-wcpg' ),
					'tablet'          => __( 'Tablet only   (768px - 1024px)', 'zymarg-wcpg' ),
					'mobile'          => __( 'Mobile only   (<=767px)', 'zymarg-wcpg' ),
					'desktop_tablet'  => __( 'Desktop & Tablet  (>=768px)', 'zymarg-wcpg' ),
					'tablet_mobile'   => __( 'Tablet & Mobile   (<=1024px)', 'zymarg-wcpg' ),
					'all'             => __( 'All devices', 'zymarg-wcpg' ),
				),
				'description' => __( 'Choose which screen sizes show the quick view button. Uses CSS breakpoints: mobile <=767px, tablet 768-1024px, desktop >=1025px.', 'zymarg-wcpg' ),
				'condition'   => array( 'show_quickview' => 'yes' ),
			)
		);

		$this->add_control(
			'quickview_display',
			array(
				'label'       => __( 'Display style', 'zymarg-wcpg' ),
				'type'        => \Elementor\Controls_Manager::SELECT,
				'default'     => 'hover_only',
				'options'     => array(
					'hover_only' => __( 'Hover only', 'zymarg-wcpg' ),
					'always'     => __( 'Always visible', 'zymarg-wcpg' ),
				),
				'description' => __( 'Hover only: icon is hidden until the user hovers the card (desktop only). On touch devices the icon stays visible because hover is not available.', 'zymarg-wcpg' ),
				'condition'   => array( 'show_quickview' => 'yes' ),
			)
		);

		$this->add_control(
			'quickview_icon',
			array(
				'label'     => __( 'Icon', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::ICONS,
				'default'   => array(
					'value'   => 'far fa-eye',
					'library' => 'fa-regular',
				),
				'condition' => array( 'show_quickview' => 'yes' ),
			)
		);

		$this->add_control(
			'quickview_phase_notice',
			array(
				'type' => \Elementor\Controls_Manager::RAW_HTML,
				'raw'  => '<div class="elementor-panel-alert elementor-panel-alert-info">'
					. esc_html__( 'Quick view modal ships in Phase 5. The icon renders and is fully styleable now.', 'zymarg-wcpg' )
					. '</div>',
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Add to cart CTA settings.
	 */
	private function register_atc_settings() {
		$this->start_controls_section(
			'section_settings_atc',
			array(
				'label' => __( 'Add to cart CTA', 'zymarg-wcpg' ),
			)
		);

		$this->add_control(
			'show_atc',
			array(
				'label'        => __( 'Show add to cart', 'zymarg-wcpg' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'atc_icon',
			array(
				'label'     => __( 'Icon', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::ICONS,
				'default'   => array(
					'value'   => 'fas fa-plus',
					'library' => 'fa-solid',
				),
				'condition' => array( 'show_atc' => 'yes' ),
			)
		);

		$this->add_control(
			'show_view_cart_link',
			array(
				'label'        => __( 'Show "View cart" link after add', 'zymarg-wcpg' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default'      => 'yes',
				'description'  => __( 'When enabled (default), WooCommerce displays a "View cart" link beside the add-to-cart button after a product is added. Disable to keep the button in place with no layout shift.', 'zymarg-wcpg' ),
				'condition'    => array( 'show_atc' => 'yes' ),
			)
		);

		$this->add_control(
			'atc_phase_notice',
			array(
				'type'    => \Elementor\Controls_Manager::RAW_HTML,
				'default' => '',
				'raw'     => '<div class="elementor-panel-alert elementor-panel-alert-info">'
					. esc_html__( 'In Phase 2, simple-product Add-to-Cart links to the product page; AJAX add-to-cart ships in Phase 4. Variable products always link to the product page.', 'zymarg-wcpg' )
					. '</div>',
			)
		);

		$this->add_control(
			'atc_position',
			array(
				'label'       => __( 'Position', 'zymarg-wcpg' ),
				'type'        => \Elementor\Controls_Manager::SELECT,
				'default'     => 'with_price',
				'options'     => array(
					'standalone'  => __( 'Individual row (below everything)', 'zymarg-wcpg' ),
					'with_meta'   => __( 'With rating & sold count', 'zymarg-wcpg' ),
					'with_price'  => __( 'With price (default)', 'zymarg-wcpg' ),
					'with_vendor' => __( 'With vendor profile', 'zymarg-wcpg' ),
				),
				'description' => __( 'The button is always pushed to the far-right edge of the row it pairs with. If "With vendor profile" is chosen but vendor is hidden, this falls back to "With price".', 'zymarg-wcpg' ),
				'condition'   => array( 'show_atc' => 'yes' ),
			)
		);

		// ------------------------------------------------------------------
		// Static position - ALWAYS applied (independent of hover transform
		// below). Use this to permanently move/rotate/scale the button away
		// from its default position within the row it pairs with. Applied
		// to the wrapper, so any hover transform below composes on top of
		// this new "home" position.
		// ------------------------------------------------------------------
		$this->add_control(
			'atc_static_heading',
			array(
				'label'     => __( 'Static position', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => array( 'show_atc' => 'yes' ),
			)
		);

		$this->add_control(
			'atc_static_notice',
			array(
				'type'      => \Elementor\Controls_Manager::RAW_HTML,
				'default'   => '',
				'raw'       => '<div class="elementor-panel-alert elementor-panel-alert-info">'
					. esc_html__( 'Always applied. Moves the button to a new permanent position - the hover transform below then applies on top of this.', 'zymarg-wcpg' )
					. '</div>',
				'condition' => array( 'show_atc' => 'yes' ),
			)
		);

		$this->add_control(
			'atc_static_rotate',
			array(
				'label'      => __( 'Rotate', 'zymarg-wcpg' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => array( 'deg' ),
				'range'      => array(
					'deg' => array( 'min' => -45, 'max' => 45, 'step' => 1 ),
				),
				'default'    => array( 'size' => 0, 'unit' => 'deg' ),
				'selectors'  => array(
					'{{WRAPPER}} .zymarg-wcpg__atc-wrap' => '--zymarg-atc-static-rotate: {{SIZE}}{{UNIT}};',
				),
				'condition'  => array( 'show_atc' => 'yes' ),
			)
		);

		$this->add_control(
			'atc_static_offset_x',
			array(
				'label'      => __( 'Offset X', 'zymarg-wcpg' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array( 'min' => -100, 'max' => 100, 'step' => 1 ),
				),
				'default'    => array( 'size' => 0, 'unit' => 'px' ),
				'selectors'  => array(
					'{{WRAPPER}} .zymarg-wcpg__atc-wrap' => '--zymarg-atc-static-x: {{SIZE}}{{UNIT}};',
				),
				'condition'  => array( 'show_atc' => 'yes' ),
			)
		);

		$this->add_control(
			'atc_static_offset_y',
			array(
				'label'      => __( 'Offset Y', 'zymarg-wcpg' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array( 'min' => -200, 'max' => 200, 'step' => 1 ),
				),
				'default'    => array( 'size' => 0, 'unit' => 'px' ),
				'selectors'  => array(
					'{{WRAPPER}} .zymarg-wcpg__atc-wrap' => '--zymarg-atc-static-y: {{SIZE}}{{UNIT}};',
				),
				'description' => __( 'Negative values move the button up - useful for floating it over rows above (e.g. into the image area).', 'zymarg-wcpg' ),
				'condition'  => array( 'show_atc' => 'yes' ),
			)
		);

		$this->add_control(
			'atc_static_scale',
			array(
				'label'     => __( 'Scale', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::SLIDER,
				'range'     => array(
					'px' => array( 'min' => 0.5, 'max' => 2.0, 'step' => 0.05 ),
				),
				'default'   => array( 'size' => 1.0, 'unit' => 'px' ),
				'selectors' => array(
					'{{WRAPPER}} .zymarg-wcpg__atc-wrap' => '--zymarg-atc-static-scale: {{SIZE}};',
				),
				'condition' => array( 'show_atc' => 'yes' ),
			)
		);

		// ------------------------------------------------------------------
		// Hover transform - independent layer, applied to the inner button.
		// Composes on top of the static position above (e.g. static moves
		// the button to the top-right corner; hover then scales it up from
		// that new spot).
		// ------------------------------------------------------------------
		$this->add_control(
			'atc_hover_heading',
			array(
				'label'     => __( 'Hover transform', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => array( 'show_atc' => 'yes' ),
			)
		);

		$this->add_control(
			'atc_transform',
			array(
				'label'       => __( 'Hover transform', 'zymarg-wcpg' ),
				'label_block' => true,
				'type'        => \Elementor\Controls_Manager::SELECT,
				'default'     => 'none',
				'options'     => array(
					'none'     => __( 'None', 'zymarg-wcpg' ),
					'scale'    => __( 'Scale up', 'zymarg-wcpg' ),
					'slide_up' => __( 'Slide up', 'zymarg-wcpg' ),
					'slide_in' => __( 'Slide in from right', 'zymarg-wcpg' ),
					'custom'   => __( 'Custom (rotate / offset / scale)', 'zymarg-wcpg' ),
				),
				'description' => __( 'Animation applied to the button on hover, on top of the static position above.', 'zymarg-wcpg' ),
				'condition'   => array( 'show_atc' => 'yes' ),
			)
		);

		$this->add_control(
			'atc_transform_scale_amount',
			array(
				'label'     => __( 'Scale amount', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::SLIDER,
				'range'     => array(
					'px' => array(
						'min'  => 1.0,
						'max'  => 1.5,
						'step' => 0.05,
					),
				),
				'default'   => array(
					'size' => 1.1,
					'unit' => 'px',
				),
				'selectors' => array(
					'{{WRAPPER}} .zymarg-wcpg__atc-wrap--scale' => '--zymarg-atc-scale: {{SIZE}};',
				),
				'condition' => array(
					'show_atc'      => 'yes',
					'atc_transform' => 'scale',
				),
			)
		);

		// -- Custom hover transform (rotate / offset / scale) --------------
		$this->add_control(
			'atc_custom_rotate',
			array(
				'label'      => __( 'Rotate', 'zymarg-wcpg' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => array( 'deg' ),
				'range'      => array(
					'deg' => array( 'min' => -45, 'max' => 45, 'step' => 1 ),
				),
				'default'    => array( 'size' => 0, 'unit' => 'deg' ),
				'selectors'  => array(
					'{{WRAPPER}} .zymarg-wcpg__atc-wrap--custom' => '--zymarg-atc-hover-rotate: {{SIZE}}{{UNIT}};',
				),
				'condition'  => array(
					'show_atc'      => 'yes',
					'atc_transform' => 'custom',
				),
			)
		);

		$this->add_control(
			'atc_custom_offset_x',
			array(
				'label'      => __( 'Offset X', 'zymarg-wcpg' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array( 'min' => -50, 'max' => 50, 'step' => 1 ),
				),
				'default'    => array( 'size' => 0, 'unit' => 'px' ),
				'selectors'  => array(
					'{{WRAPPER}} .zymarg-wcpg__atc-wrap--custom' => '--zymarg-atc-hover-x: {{SIZE}}{{UNIT}};',
				),
				'condition'  => array(
					'show_atc'      => 'yes',
					'atc_transform' => 'custom',
				),
			)
		);

		$this->add_control(
			'atc_custom_offset_y',
			array(
				'label'      => __( 'Offset Y', 'zymarg-wcpg' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array( 'min' => -50, 'max' => 50, 'step' => 1 ),
				),
				'default'    => array( 'size' => 0, 'unit' => 'px' ),
				'selectors'  => array(
					'{{WRAPPER}} .zymarg-wcpg__atc-wrap--custom' => '--zymarg-atc-hover-y: {{SIZE}}{{UNIT}};',
				),
				'condition'  => array(
					'show_atc'      => 'yes',
					'atc_transform' => 'custom',
				),
			)
		);

		$this->add_control(
			'atc_custom_scale',
			array(
				'label'     => __( 'Scale', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::SLIDER,
				'range'     => array(
					'px' => array( 'min' => 1.0, 'max' => 1.5, 'step' => 0.05 ),
				),
				'default'   => array( 'size' => 1.0, 'unit' => 'px' ),
				'selectors' => array(
					'{{WRAPPER}} .zymarg-wcpg__atc-wrap--custom' => '--zymarg-atc-hover-scale: {{SIZE}};',
				),
				'condition' => array(
					'show_atc'      => 'yes',
					'atc_transform' => 'custom',
				),
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Title settings.
	 */
	private function register_title_settings() {
		$this->start_controls_section(
			'section_settings_title',
			array(
				'label' => __( 'Title', 'zymarg-wcpg' ),
			)
		);

		$this->add_control(
			'show_title',
			array(
				'label'        => __( 'Show title', 'zymarg-wcpg' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'title_lines',
			array(
				'label'     => __( 'Title lines', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::SELECT,
				'default'   => '2',
				'options'   => array(
					'1' => '1',
					'2' => '2',
					'3' => '3',
				),
				'selectors' => array(
					'{{WRAPPER}} .zymarg-wcpg__title' => '-webkit-line-clamp: {{VALUE}};',
				),
				'condition' => array( 'show_title' => 'yes' ),
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Vendor profile settings.
	 */
	private function register_vendor_settings() {
		$this->start_controls_section(
			'section_settings_vendor',
			array(
				'label' => __( 'Vendor profile', 'zymarg-wcpg' ),
			)
		);

		$this->add_control(
			'show_vendor',
			array(
				'label'        => __( 'Show vendor', 'zymarg-wcpg' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default'      => '',
				'description'  => __( 'Requires Dokan Lite or Pro 3.10+. Hidden automatically when vendor cannot be resolved.', 'zymarg-wcpg' ),
			)
		);

		$this->add_control(
			'vendor_position',
			array(
				'label'       => __( 'Position', 'zymarg-wcpg' ),
				'type'        => \Elementor\Controls_Manager::SELECT,
				'default'     => 'below_price',
				'options'     => array(
					'above_title' => __( 'Above title', 'zymarg-wcpg' ),
					'below_meta'  => __( 'Below rating & sold count', 'zymarg-wcpg' ),
					'below_price' => __( 'Below price (default)', 'zymarg-wcpg' ),
				),
				'condition'   => array( 'show_vendor' => 'yes' ),
			)
		);

		$this->add_control(
			'vendor_display',
			array(
				'label'     => __( 'Display style', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::SELECT,
				'default'   => 'avatar_name',
				'options'   => array(
					'name_only'            => __( 'Name only', 'zymarg-wcpg' ),
					'avatar_name'          => __( 'Avatar + Name', 'zymarg-wcpg' ),
					'avatar_name_location' => __( 'Avatar + Name + Location', 'zymarg-wcpg' ),
				),
				'condition' => array( 'show_vendor' => 'yes' ),
			)
		);

		$this->add_control(
			'vendor_link',
			array(
				'label'        => __( 'Link to vendor store', 'zymarg-wcpg' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default'      => 'yes',
				'description'  => __( 'Wraps the vendor row in a link to their Dokan store page.', 'zymarg-wcpg' ),
				'condition'    => array( 'show_vendor' => 'yes' ),
			)
		);

		$this->add_control(
			'vendor_avatar_size',
			array(
				'label'      => __( 'Avatar size', 'zymarg-wcpg' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array(
						'min'  => 12,
						'max'  => 80,
						'step' => 1,
					),
				),
				'default'    => array( 'size' => 24, 'unit' => 'px' ),
				'selectors'  => array(
					'{{WRAPPER}} .zymarg-wcpg__vendor-avatar' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}}; min-width: {{SIZE}}{{UNIT}};',
				),
				'condition'  => array(
					'show_vendor'    => 'yes',
					'vendor_display' => array( 'avatar_name', 'avatar_name_location' ),
				),
			)
		);

		$this->add_control(
			'vendor_avatar_side',
			array(
				'label'     => __( 'Avatar side', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::CHOOSE,
				'options'   => array(
					'left'  => array(
						'title' => __( 'Left', 'zymarg-wcpg' ),
						'icon'  => 'eicon-h-align-left',
					),
					'right' => array(
						'title' => __( 'Right', 'zymarg-wcpg' ),
						'icon'  => 'eicon-h-align-right',
					),
				),
				'default'   => 'left',
				'toggle'    => false,
				'condition' => array(
					'show_vendor'    => 'yes',
					'vendor_display' => array( 'avatar_name', 'avatar_name_location' ),
				),
			)
		);

		$this->add_control(
			'vendor_avatar_shape',
			array(
				'label'     => __( 'Avatar shape', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::SELECT,
				'default'   => 'circle',
				'options'   => array(
					'circle'  => __( 'Circle', 'zymarg-wcpg' ),
					'rounded' => __( 'Rounded square', 'zymarg-wcpg' ),
					'square'  => __( 'Square', 'zymarg-wcpg' ),
				),
				'condition' => array(
					'show_vendor'    => 'yes',
					'vendor_display' => array( 'avatar_name', 'avatar_name_location' ),
				),
			)
		);

		$this->add_control(
			'vendor_avatar_border',
			array(
				'label'        => __( 'Show border', 'zymarg-wcpg' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default'      => '',
				'condition'    => array(
					'show_vendor'    => 'yes',
					'vendor_display' => array( 'avatar_name', 'avatar_name_location' ),
				),
			)
		);

		$this->add_control(
			'vendor_avatar_border_color',
			array(
				'label'     => __( 'Border color', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '#e0e0e0',
				'selectors' => array(
					'{{WRAPPER}} .zymarg-wcpg__vendor-avatar' => 'border: 2px solid {{VALUE}};',
				),
				'condition' => array(
					'show_vendor'          => 'yes',
					'vendor_display'       => array( 'avatar_name', 'avatar_name_location' ),
					'vendor_avatar_border' => 'yes',
				),
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Rating + sold count settings.
	 */
	private function register_rating_sold_settings() {
		$this->start_controls_section(
			'section_settings_rating',
			array(
				'label' => __( 'Rating & sold count', 'zymarg-wcpg' ),
			)
		);

		$this->add_control(
			'show_rating',
			array(
				'label'        => __( 'Show rating', 'zymarg-wcpg' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default'      => 'yes',
				'description'  => __( 'Auto-hides when product has zero ratings.', 'zymarg-wcpg' ),
			)
		);

		$this->add_control(
			'show_sold_count',
			array(
				'label'        => __( 'Show sold count', 'zymarg-wcpg' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default'      => 'yes',
				'description'  => __( 'Auto-hides when product has zero sales.', 'zymarg-wcpg' ),
			)
		);

		$this->add_control(
			'sold_count_format',
			array(
				'label'     => __( 'Sold count format', 'zymarg-wcpg' ),
				'type'      => \Elementor\Controls_Manager::SELECT,
				'default'   => 'sold_n',
				'options'   => array(
					'sold_n'      => __( 'Sold {n}', 'zymarg-wcpg' ),
					'n_sold'      => __( '{n} sold', 'zymarg-wcpg' ),
					'sold_n_plus' => __( 'Sold {n}+', 'zymarg-wcpg' ),
				),
				'condition' => array( 'show_sold_count' => 'yes' ),
			)
		);

		$this->add_responsive_control(
			'show_sold_text',
			array(
				'label'          => __( 'Show "Sold" word', 'zymarg-wcpg' ),
				'description'    => __( 'When off, renders just the number (e.g. "120" instead of "Sold 120"). Useful on narrow mobile cards. Set independently per device.', 'zymarg-wcpg' ),
				'type'           => \Elementor\Controls_Manager::SWITCHER,
				'label_on'       => __( 'Show', 'zymarg-wcpg' ),
				'label_off'      => __( 'Hide', 'zymarg-wcpg' ),
				'return_value'   => 'yes',
				'default'        => 'yes',
				'tablet_default' => 'yes',
				'mobile_default' => '',
				'condition'      => array( 'show_sold_count' => 'yes' ),
			)
		);

		$this->add_responsive_control(
			'meta_layout',
			array(
				'label'          => __( 'Layout', 'zymarg-wcpg' ),
				'type'           => \Elementor\Controls_Manager::SELECT,
				'default'        => 'inline',
				'tablet_default' => 'inline',
				'mobile_default' => 'count_indicator',
				'options'        => array(
					'inline'          => __( 'Inline - Stars | Sold count', 'zymarg-wcpg' ),
					'count_first'     => __( 'Count first - Sold count | Stars', 'zymarg-wcpg' ),
					'count_indicator' => __( 'Indicator - ★ 4.5 | Sold count', 'zymarg-wcpg' ),
				),
				'description'    => __( 'How rating and sold count are arranged. Indicator mode replaces the 5-star graphic with a single star icon and the numeric rating value - recommended for narrow mobile cards. Set independently per device.', 'zymarg-wcpg' ),
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Price settings.
	 */
	private function register_price_settings() {
		$this->start_controls_section(
			'section_settings_price',
			array(
				'label' => __( 'Price', 'zymarg-wcpg' ),
			)
		);

		$this->add_control(
			'show_price',
			array(
				'label'        => __( 'Show price', 'zymarg-wcpg' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'price_position',
			array(
				'label'       => __( 'Price position', 'zymarg-wcpg' ),
				'type'        => \Elementor\Controls_Manager::SELECT,
				'default'     => 'below_rating',
				'options'     => array(
					'above_title'  => __( 'Above title', 'zymarg-wcpg' ),
					'above_rating' => __( 'Row 3 - above rating & sold count', 'zymarg-wcpg' ),
					'below_rating' => __( 'Row 3 - below rating & sold count (default)', 'zymarg-wcpg' ),
				),
				'condition'   => array( 'show_price' => 'yes' ),
				'description' => __( 'Choose where the price appears on the card. "Above title" places price before all rows.', 'zymarg-wcpg' ),
			)
		);

		$this->end_controls_section();
	}
}

