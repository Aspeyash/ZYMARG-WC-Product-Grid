<?php
/**
 * Elementor integration loader.
 *
 * @package Zymarg\WCPG
 */

namespace Zymarg\WCPG\Elementor;

defined( 'ABSPATH' ) || exit;

/**
 * Class ElementorLoader
 *
 * Registers the widget category and our widget classes with Elementor.
 */
class ElementorLoader {

	const CATEGORY_SLUG = 'zymarg-wcpg';

	/**
	 * Hook into Elementor's lifecycle.
	 */
	public function register() {
		add_action( 'elementor/elements/categories_registered', array( $this, 'register_category' ) );
		add_action( 'elementor/widgets/register', array( $this, 'register_widgets' ) );
	}

	/**
	 * Add a dedicated widget category so all our widgets group together.
	 *
	 * @param \Elementor\Elements_Manager $elements_manager Manager instance.
	 */
	public function register_category( $elements_manager ) {
		$elements_manager->add_category(
			self::CATEGORY_SLUG,
			array(
				'title' => __( 'ZYMARG WooCommerce', 'zymarg-wcpg' ),
				'icon'  => 'eicon-products',
			)
		);
	}

	/**
	 * Register widget classes.
	 *
	 * Trait files are loaded explicitly because the plugin's PSR-4 SPL
	 * autoloader maps StudlyCaps/Snake_Case classes to `class-*.php` files,
	 * while our trait files use the `trait-*.php` WordPress convention.
	 *
	 * @param \Elementor\Widgets_Manager $widgets_manager Manager instance.
	 */
	public function register_widgets( $widgets_manager ) {
		$traits_dir = ZYMARG_WCPG_DIR . 'includes/Elementor/traits/';
		require_once $traits_dir . 'trait-controls-heading.php';
		require_once $traits_dir . 'trait-controls-layout.php';
		require_once $traits_dir . 'trait-controls-settings.php';
		require_once $traits_dir . 'trait-controls-style.php';
		require_once $traits_dir . 'trait-controls-source.php';
		require_once $traits_dir . 'trait-controls-slider.php';
		require_once $traits_dir . 'trait-editor-diagnostics.php';

		$widgets_manager->register( new Widget_Product_Grid() );

		/**
		 * Fires after the plugin has registered its core widgets, allowing
		 * extensions to register additional widgets in the same category.
		 *
		 * @param \Elementor\Widgets_Manager $widgets_manager
		 */
		do_action( 'zymarg_wcpg_register_widgets', $widgets_manager );
	}
}
