<?php
/**
 * Per-visitor recommendation result cache.
 *
 * Caches the final scored ID list returned by Source_Recommended so we
 * don't rebuild the profile + rescore the candidate pool on every page
 * load. Cache layers:
 *
 *   Logged-in: transient keyed by user_id + settings hash (1h TTL).
 *   Guest:     transient keyed by RV/wishlist cookie hash (15min TTL).
 *              Guest data is small (cookie-bound) so we keep the TTL
 *              short and don't lose much by recomputing.
 *
 * Auto-invalidation hooks:
 *   - Wishlist add / remove
 *   - Cart add (via woocommerce_add_to_cart)
 *   - Order completed / processing transition
 *
 * Invalidation always targets the CURRENT visitor only — we don't bust
 * the entire cache space, just the touched user/guest bucket.
 *
 * @package Zymarg\WCPG
 */

namespace Zymarg\WCPG\Recommendations;

defined( 'ABSPATH' ) || exit;

use Zymarg\WCPG\Tracking\Recently_Viewed;
use Zymarg\WCPG\Wishlist\Wishlist_Store;

/**
 * Class Affinity_Cache
 */
class Affinity_Cache {

	/** Transient key prefix. */
	const PREFIX = 'zymarg_recomm_';

	/** Transient TTL for logged-in users. */
	const TTL_USER = HOUR_IN_SECONDS;

	/** Transient TTL for guests (kept short on purpose). */
	const TTL_GUEST = 15 * MINUTE_IN_SECONDS;

	/** Option that holds the per-user invalidation salt. */
	const SALT_USER_META = '_zymarg_recomm_salt';

	/**
	 * Wire invalidation hooks. Called once at plugin boot.
	 */
	public function register() {
		add_action( 'zymarg_wcpg_wishlist_changed', array( __CLASS__, 'invalidate_current_visitor' ) );
		add_action( 'woocommerce_add_to_cart', array( __CLASS__, 'invalidate_current_visitor' ) );
		add_action( 'woocommerce_order_status_completed', array( __CLASS__, 'invalidate_for_order' ) );
		add_action( 'woocommerce_order_status_processing', array( __CLASS__, 'invalidate_for_order' ) );
	}

	/**
	 * Read a cached result set, or false on miss.
	 *
	 * @param string $key Cache key (from make_key()).
	 * @return int[]|false
	 */
	public static function get( $key ) {
		$value = get_transient( self::PREFIX . $key );
		if ( ! is_array( $value ) ) {
			return false;
		}
		return array_values( array_filter( array_map( 'intval', $value ) ) );
	}

	/**
	 * Persist a result set.
	 *
	 * @param string $key     Cache key.
	 * @param int[]  $ids     Product IDs in scored order.
	 * @param bool   $is_guest Whether the visitor is a guest.
	 */
	public static function set( $key, array $ids, $is_guest = false ) {
		$ids = array_values( array_filter( array_map( 'intval', $ids ) ) );
		$ttl = $is_guest ? self::TTL_GUEST : self::TTL_USER;
		set_transient( self::PREFIX . $key, $ids, $ttl );
	}

	/**
	 * Compute the cache key for the current visitor + widget settings.
	 *
	 * The key includes a per-user "salt" that we rotate on invalidation
	 * events. This effectively invalidates all of the visitor's cached
	 * variants (different widgets, different weights) in O(1) without
	 * scanning the transients table.
	 *
	 * @param array $settings Widget settings (only the recommend-relevant
	 *                        keys are hashed, to keep the key stable when
	 *                        unrelated style toggles change).
	 * @return string
	 */
	public static function make_key( array $settings ) {
		$salt    = self::get_visitor_salt();
		$visitor = self::visitor_token();
		$payload = wp_json_encode(
			array(
				's'  => $salt,
				'v'  => $visitor,
				'wc' => (int) ( $settings['recommended_w_category'] ?? 40 ),
				'wp' => (int) ( $settings['recommended_w_purchase'] ?? 30 ),
				'wb' => (int) ( $settings['recommended_w_brand'] ?? 15 ),
				'ws' => (int) ( $settings['recommended_w_seller'] ?? 10 ),
				'wt' => (int) ( $settings['recommended_w_trending'] ?? 5 ),
				'rp' => isset( $settings['recommended_recency_penalty'] ) ? (string) $settings['recommended_recency_penalty'] : 'yes',
				'vd' => (int) ( $settings['recommended_vendor_cap'] ?? 3 ),
				'ex' => isset( $settings['recommended_exclude_purchased'] ) ? (string) $settings['recommended_exclude_purchased'] : 'yes',
				'cs' => (string) ( $settings['recommended_cold_start'] ?? 'hybrid' ),
				'oos' => isset( $settings['show_oos'] ) ? (string) $settings['show_oos'] : '',
				'lim' => (int) ( $settings['total_products'] ?? 8 ),
			)
		);
		return md5( $payload );
	}

	/**
	 * Stable identity token for the current visitor.
	 *
	 * Logged-in: their user ID.
	 * Guest:     a hash of the RV/Wishlist cookie state so two different
	 *            browsers without history produce different keys. When the
	 *            guest has no signals at all, we collapse to a single
	 *            "anonymous" bucket so cold-start results are reused.
	 *
	 * @return string
	 */
	private static function visitor_token() {
		if ( is_user_logged_in() ) {
			return 'u-' . (int) get_current_user_id();
		}

		$wishlist = Wishlist_Store::get_ids();
		$recent   = Recently_Viewed::get_ids();

		if ( empty( $wishlist ) && empty( $recent ) ) {
			return 'g-anon';
		}

		return 'g-' . substr(
			md5(
				wp_json_encode(
					array(
						'w' => $wishlist,
						'r' => $recent,
					)
				)
			),
			0,
			12
		);
	}

	/**
	 * Get (and lazily create) the per-user invalidation salt.
	 *
	 * @return string
	 */
	private static function get_visitor_salt() {
		if ( is_user_logged_in() ) {
			$uid  = get_current_user_id();
			$salt = (string) get_user_meta( $uid, self::SALT_USER_META, true );
			if ( '' === $salt ) {
				$salt = wp_generate_password( 8, false, false );
				update_user_meta( $uid, self::SALT_USER_META, $salt );
			}
			return $salt;
		}
		// Guests rotate their salt by changing their cookie state, which
		// naturally changes the visitor_token() above. No separate salt
		// needed for guests.
		return '0';
	}

	/**
	 * Rotate the current visitor's salt (effectively invalidates all of
	 * their cached recommendation variants without touching the DB-wide
	 * transient store).
	 */
	public static function invalidate_current_visitor() {
		if ( is_user_logged_in() ) {
			update_user_meta(
				get_current_user_id(),
				self::SALT_USER_META,
				wp_generate_password( 8, false, false )
			);
		}
		// Guests get fresh tokens automatically when their cookies change.
	}

	/**
	 * Invalidate cache for the user who placed an order.
	 *
	 * @param int $order_id Order ID.
	 */
	public static function invalidate_for_order( $order_id ) {
		$order_id = (int) $order_id;
		if ( $order_id <= 0 || ! function_exists( 'wc_get_order' ) ) {
			return;
		}
		$order = wc_get_order( $order_id );
		if ( ! $order instanceof \WC_Order ) {
			return;
		}
		$uid = (int) $order->get_user_id();
		if ( $uid <= 0 ) {
			return;
		}
		update_user_meta( $uid, self::SALT_USER_META, wp_generate_password( 8, false, false ) );
	}
}
