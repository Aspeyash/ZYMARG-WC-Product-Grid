<?php
/**
 * Product data helpers (price rendering, discount badges, icon rendering).
 *
 * @package Zymarg\WCPG
 */

namespace Zymarg\WCPG;

defined( 'ABSPATH' ) || exit;

/**
 * Class Product_Data
 *
 * Stateless helpers for rendering individual product UI fragments.
 * All output is escaped at the boundary; callers can echo directly.
 */
class Product_Data {

	/**
	 * Render an icon picked via Elementor's icons control.
	 *
	 * Falls back to a Font Awesome class name when no icon is configured.
	 *
	 * @param mixed  $icon_setting   Elementor icons control value (array) or null.
	 * @param string $fallback_class Font Awesome class to use when no value is set.
	 */
	public static function render_icon( $icon_setting, $fallback_class = '' ) {
		if ( is_array( $icon_setting ) && ! empty( $icon_setting['value'] ) && class_exists( '\Elementor\Icons_Manager' ) ) {
			\Elementor\Icons_Manager::render_icon( $icon_setting, array( 'aria-hidden' => 'true' ) );
			return;
		}

		if ( $fallback_class ) {
			printf( '<i class="%s" aria-hidden="true"></i>', esc_attr( $fallback_class ) );
		}
	}

	/**
	 * Render a discount badge for a product on sale.
	 *
	 * Modes:
	 *   percent -> "-25%"
	 *   amount  -> "-$10.00"
	 *   both    -> "-25% / -$10.00"
	 *
	 * Returns empty string when the product is not on sale or pricing is invalid.
	 *
	 * @param \WC_Product $product Product instance.
	 * @param string      $mode    'percent' | 'amount' | 'both'.
	 * @return string Already-escaped HTML.
	 */
	public static function get_discount_badge_html( \WC_Product $product, $mode = 'percent' ) {
		list( $regular, $current ) = self::get_compare_prices( $product );

		if ( $regular <= 0 || $current <= 0 || $current >= $regular ) {
			return '';
		}

		$diff        = $regular - $current;
		$percent     = (int) round( ( $diff / $regular ) * 100 );
		$amount_html = wp_kses_post( wc_price( $diff ) );

		switch ( $mode ) {
			case 'amount':
				/* translators: %s: amount of discount, e.g. -$10 */
				$inner = sprintf( esc_html__( '-%s', 'zymarg-wcpg' ), $amount_html );
				break;
			case 'both':
				$inner = sprintf( '-%d%% / -%s', $percent, $amount_html );
				break;
			case 'percent':
			default:
				$inner = sprintf( '-%d%%', $percent );
				break;
		}

		return '<span class="zymarg-wcpg__badge zymarg-wcpg__badge--discount">' . $inner . '</span>';
	}

	/**
	 * Echo the price block with the locked rules:
	 *   Simple on sale       : <current bold> <small><strike>regular</strike></small>
	 *   Simple no sale       : <regular bold>
	 *   Variable on sale     : lowest sale bold + lowest regular strikethrough subscript
	 *   Variable no sale all : single price bold
	 *   Variable no sale mix : "From {min}" bold
	 *   Out-of-stock products are wrapped in .is-oos by the card, no extra logic needed here.
	 *
	 * @param \WC_Product $product Product instance.
	 */
	public static function render_price( \WC_Product $product ) {
		echo '<div class="zymarg-wcpg__price">';

		if ( $product->is_type( 'variable' ) ) {
			self::render_variable_price( $product );
		} else {
			self::render_simple_price( $product );
		}

		echo '</div>';
	}

	/**
	 * Get (regular, effective) prices in a comparable scalar form for badge math.
	 *
	 * Variable products use the minimum across variations so the discount
	 * badge reflects the cheapest savings shown on the card.
	 *
	 * @param \WC_Product $product Product instance.
	 * @return array{0:float,1:float} [regular, current]
	 */
	private static function get_compare_prices( \WC_Product $product ) {
		if ( $product->is_type( 'variable' ) ) {
			$prices  = $product->get_variation_prices( true );
			$regular = ! empty( $prices['regular_price'] ) ? (float) min( $prices['regular_price'] ) : 0.0;
			$current = ! empty( $prices['price'] ) ? (float) min( $prices['price'] ) : 0.0;
			return array( $regular, $current );
		}

		$regular = (float) $product->get_regular_price();
		$current = (float) $product->get_price();
		return array( $regular, $current );
	}

	/**
	 * Render simple-product price.
	 *
	 * @param \WC_Product $product Product instance.
	 */
	private static function render_simple_price( \WC_Product $product ) {
		$regular = (float) $product->get_regular_price();
		$current = (float) $product->get_price();
		$on_sale = $product->is_on_sale() && $current > 0 && $regular > 0 && $current < $regular;

		echo '<span class="zymarg-wcpg__price-current">' . wp_kses_post( wc_price( $current > 0 ? $current : $regular ) ) . '</span>';

		if ( $on_sale ) {
			echo '<sub class="zymarg-wcpg__price-old"><del>' . wp_kses_post( wc_price( $regular ) ) . '</del></sub>';
		}
	}

	/**
	 * Render variable-product price with left-aligned lowest-sale + lowest-regular strikethrough.
	 *
	 * @param \WC_Product $product Product instance.
	 */
	private static function render_variable_price( \WC_Product $product ) {
		$prices = $product->get_variation_prices( true );

		// Defensive fallback: empty variation prices -> use Woo's price html.
		if ( empty( $prices['price'] ) ) {
			echo '<span class="zymarg-wcpg__price-current">' . wp_kses_post( $product->get_price_html() ) . '</span>';
			return;
		}

		$min_price   = (float) min( $prices['price'] );
		$min_regular = (float) min( $prices['regular_price'] );
		$on_sale     = $min_price < $min_regular;
		$all_same    = ( count( array_unique( $prices['price'] ) ) === 1 );

		if ( $on_sale ) {
			echo '<span class="zymarg-wcpg__price-current">' . wp_kses_post( wc_price( $min_price ) ) . '</span>';
			echo '<sub class="zymarg-wcpg__price-old"><del>' . wp_kses_post( wc_price( $min_regular ) ) . '</del></sub>';
			return;
		}

		if ( $all_same ) {
			echo '<span class="zymarg-wcpg__price-current">' . wp_kses_post( wc_price( $min_price ) ) . '</span>';
			return;
		}

		echo '<span class="zymarg-wcpg__price-current">';
		printf(
			/* translators: %s: minimum variation price */
			esc_html__( 'From %s', 'zymarg-wcpg' ),
			wp_kses_post( wc_price( $min_price ) )
		);
		echo '</span>';
	}
}
