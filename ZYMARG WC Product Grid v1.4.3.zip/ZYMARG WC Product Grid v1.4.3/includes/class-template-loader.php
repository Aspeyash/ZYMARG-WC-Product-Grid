<?php
/**
 * Template loader with theme override support.
 *
 * @package Zymarg\WCPG
 */

namespace Zymarg\WCPG;

defined( 'ABSPATH' ) || exit;

/**
 * Class Template_Loader
 *
 * Renders plugin templates with the option for themes to override them by
 * placing files at theme/zymarg-wcpg/<relative_path>.
 *
 * Usage:
 *   Template_Loader::get_template( 'grid/product-card.php', [
 *       'product'   => $product,
 *       'settings'  => $settings,
 *       'widget_id' => $widget_id,
 *   ] );
 */
class Template_Loader {

	/**
	 * Render a template with optional variables in scope.
	 *
	 * Templates are first looked up in the active theme under the
	 * `zymarg-wcpg/` directory. If not found there, the bundled plugin
	 * template is used.
	 *
	 * @param string $template_name Path relative to /templates/ (e.g. `grid/product-card.php`).
	 * @param array  $args          Variables to make available inside the template.
	 */
	public static function get_template( $template_name, $args = array() ) {
		$template_name = ltrim( (string) $template_name, '/' );

		// 1. Theme override.
		$located = locate_template( array( 'zymarg-wcpg/' . $template_name ) );

		// 2. Fall back to bundled template.
		if ( ! $located ) {
			$located = ZYMARG_WCPG_DIR . 'templates/' . $template_name;
		}

		if ( ! file_exists( $located ) ) {
			return;
		}

		// Make $args available as a single variable AND extract its keys
		// for ergonomic template authoring. EXTR_SKIP prevents collisions
		// from overwriting reserved names ($located, $template_name).
		if ( is_array( $args ) && ! empty( $args ) ) {
			extract( $args, EXTR_SKIP ); // phpcs:ignore WordPress.PHP.DontExtract.extract_extract -- safe: we control all callers.
		}

		include $located;
	}

	/**
	 * Return rendered template as a string instead of echoing.
	 *
	 * @param string $template_name Template path.
	 * @param array  $args          Variables.
	 * @return string
	 */
	public static function get_template_html( $template_name, $args = array() ) {
		ob_start();
		self::get_template( $template_name, $args );
		return (string) ob_get_clean();
	}
}
