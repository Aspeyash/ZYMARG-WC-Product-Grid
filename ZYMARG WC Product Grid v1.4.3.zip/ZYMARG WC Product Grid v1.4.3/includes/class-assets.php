<?php
/**
 * Asset registration.
 *
 * @package Zymarg\WCPG
 */

namespace Zymarg\WCPG;

defined( 'ABSPATH' ) || exit;

/**
 * Class Assets
 *
 * Registers (but does not enqueue) all front-end and editor asset handles.
 * Widgets enqueue what they need on render.
 *
 * Performance notes (v1.3.5):
 *   - All plugin JS is registered with strategy=>'defer' so the browser
 *     parses HTML first, then downloads + executes scripts. Safe because
 *     every handler uses $(document).on() delegation or $(function(){}).
 *   - quickview.js uses defer too — all its handlers are delegated on
 *     $(document), so it doesn't need to run before cards are painted.
 *   - On the Algolia search page (?s= / ?q=) CSS is enqueued in wp_head
 *     (via an early wp_enqueue_scripts hook) to prevent FOUC. JS remains
 *     in the footer with defer.
 *   - Swiper: we prefer Elementor Pro's registered copy. Fallback uses a
 *     LOCAL bundle (assets/js/swiper-bundle.min.js) to avoid an external
 *     CDN round-trip. If the local copy is absent we fall back to jsDelivr
 *     so the plugin never breaks.
 */
class Assets {

	const HANDLE_FRONTEND  = 'zymarg-wcpg-frontend';
	const HANDLE_SLIDER    = 'zymarg-wcpg-slider';
	const HANDLE_QUICKVIEW = 'zymarg-wcpg-quickview';
	const HANDLE_EDITOR    = 'zymarg-wcpg-editor';
	const HANDLE_SWIPER    = 'zymarg-wcpg-swiper';

	/**
	 * Hook registration callbacks.
	 */
	public function register() {
		add_action( 'wp_enqueue_scripts', array( $this, 'register_frontend' ), 5 );
		add_action( 'elementor/editor/after_enqueue_scripts', array( $this, 'register_editor' ) );
	}

	/**
	 * Register front-end handles. Widgets call wp_enqueue_*() themselves.
	 *
	 * Execution strategy for all plugin JS: 'defer'.
	 * WordPress 6.3+ supports the array-form 4th arg for in_footer/strategy.
	 * We use a compat helper so this also works on WP 6.2.
	 */
	public function register_frontend() {

		// ── CSS ────────────────────────────────────────────────────────────
		wp_register_style(
			self::HANDLE_FRONTEND,
			ZYMARG_WCPG_URL . 'assets/css/frontend.css',
			array(),
			ZYMARG_WCPG_VERSION
		);

		wp_register_style(
			self::HANDLE_QUICKVIEW,
			ZYMARG_WCPG_URL . 'assets/css/quickview.css',
			array( self::HANDLE_FRONTEND ),
			ZYMARG_WCPG_VERSION
		);

		// Swiper handle (prefer Elementor's copy, else local bundle).
		$swiper_handle = $this->resolve_swiper_handle();

		wp_register_style(
			self::HANDLE_SLIDER,
			ZYMARG_WCPG_URL . 'assets/css/slider.css',
			array( self::HANDLE_FRONTEND, $swiper_handle ),
			ZYMARG_WCPG_VERSION
		);

		// ── JS (all deferred) ───────────────────────────────────────────────
		//
		// frontend.js — wishlist hydration, ATC, load-more, click tracking.
		// All event listeners use $(document).on() delegation; DOM-ready
		// hydrate() call is also fine under defer (fires after HTML parsed).
		wp_register_script(
			self::HANDLE_FRONTEND,
			ZYMARG_WCPG_URL . 'assets/js/frontend.js',
			array( 'jquery' ),
			ZYMARG_WCPG_VERSION,
			self::defer_args()
		);

		// quickview.js — modal open/close/AJAX. All handlers delegated on
		// $(document); no setup runs at parse time, so defer is safe.
		wp_register_script(
			self::HANDLE_QUICKVIEW,
			ZYMARG_WCPG_URL . 'assets/js/quickview.js',
			array( 'jquery', self::HANDLE_FRONTEND ),
			ZYMARG_WCPG_VERSION,
			self::defer_args()
		);

		// slider.js — Swiper init inside $(function(){}), defer is safe.
		wp_register_script(
			self::HANDLE_SLIDER,
			ZYMARG_WCPG_URL . 'assets/js/slider.js',
			array( 'jquery', $swiper_handle, self::HANDLE_FRONTEND ),
			ZYMARG_WCPG_VERSION,
			self::defer_args()
		);

		// ── Localise shared runtime data onto frontend handle ───────────────
		wp_localize_script(
			self::HANDLE_FRONTEND,
			'ZYMARGWCPG',
			array(
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'nonce'   => wp_create_nonce( 'zymarg_wcpg' ),
				'i18n'    => array(
					'addToWishlist'      => __( 'Add to wishlist', 'zymarg-wcpg' ),
					'removeFromWishlist' => __( 'Remove from wishlist', 'zymarg-wcpg' ),
					'addedToWishlist'    => __( 'Added to wishlist', 'zymarg-wcpg' ),
					'addedToCart'        => __( 'Added to cart', 'zymarg-wcpg' ),
					'genericError'       => __( 'Something went wrong. Please try again.', 'zymarg-wcpg' ),
					'rateLimited'        => __( 'Too many requests. Please slow down.', 'zymarg-wcpg' ),
				),
			)
		);

		// ── Algolia search page: enqueue CSS + JS early ─────────────────────
		//
		// Detects clean URL /search/, ?s=, and ?q= patterns.
		// Both CSS and JS are enqueued at wp_enqueue_scripts priority 15
		// (after register at priority 5) so:
		//   - CSS lands in <head> preventing FOUC on card injection.
		//   - JS is registered with defer so it executes after parse,
		//     but wp_localize_script inline data is output in <head>
		//     correctly before the deferred script runs.
		//   - Nonce is guaranteed to be in the page for ATC + quickview.
		if ( $this->is_search_page() ) {
			add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_search_page_assets' ), 15 );
		}
	}

	/**
	 * Enqueue all CSS + JS for the Algolia search results page.
	 *
	 * Hooked at wp_enqueue_scripts priority 15.
	 * CSS lands in <head> (prevents FOUC on card injection).
	 * JS is registered with defer — wp_localize_script inline data is
	 * output in <head> before the deferred <script src> executes, so
	 * ZYMARGWCPG.nonce is always available for ATC + quickview AJAX.
	 */
	public function enqueue_search_page_assets() {
		// CSS.
		wp_enqueue_style( self::HANDLE_FRONTEND );
		wp_enqueue_style( self::HANDLE_QUICKVIEW );
		// JS (deferred — inline localize block outputs before execution).
		wp_enqueue_script( self::HANDLE_FRONTEND );
		wp_enqueue_script( self::HANDLE_QUICKVIEW );
		// Flag the Quick View modal shell to be printed in wp_footer.
		// On search results pages no Elementor widget calls flag_mount(),
		// so we do it here — without this the modal overlay is never
		// injected into the DOM and Quick View clicks do nothing.
		\Zymarg\WCPG\QuickView\QuickView_Modal::flag_mount();
	}

	/**
	 * Register editor-only assets inside Elementor's editor iframe.
	 */
	public function register_editor() {
		wp_enqueue_style(
			self::HANDLE_EDITOR,
			ZYMARG_WCPG_URL . 'assets/css/editor.css',
			array(),
			ZYMARG_WCPG_VERSION
		);

		// Editor JS does not need defer — it runs inside the editor iframe
		// which is already fully loaded before script execution matters.
		wp_enqueue_script(
			self::HANDLE_EDITOR,
			ZYMARG_WCPG_URL . 'assets/js/editor.js',
			array( 'jquery' ),
			ZYMARG_WCPG_VERSION,
			true
		);
	}

	// ── Private helpers ────────────────────────────────────────────────────

	/**
	 * Whether the current request is an Algolia/WP search page.
	 *
	 * Detects three URL patterns:
	 *   1. /search/query      — clean URL rewrite (primary ZYMARG format)
	 *   2. ?s=query           — standard WordPress search
	 *   3. ?q=query           — legacy/alternate query string format
	 *
	 * @return bool
	 */
	private function is_search_page() {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended

		// Pattern 1: clean URL /search/{term}
		$request_uri = isset( $_SERVER['REQUEST_URI'] ) ? (string) $_SERVER['REQUEST_URI'] : '';
		if ( preg_match( '#^/search(/|$)#i', parse_url( $request_uri, PHP_URL_PATH ) ) ) {
			return true;
		}

		// Pattern 2: ?s= (standard WP search)
		if ( isset( $_GET['s'] ) && '' !== $_GET['s'] ) {
			return true;
		}

		// Pattern 3: ?q= (alternate)
		if ( isset( $_GET['q'] ) && '' !== $_GET['q'] ) {
			return true;
		}

		return false;

		// phpcs:enable
	}

	/**
	 * Return the correct 5th-argument value for wp_register_script() to
	 * load a script in the footer with defer strategy.
	 *
	 * WordPress 6.3+ supports:
	 *   array( 'in_footer' => true, 'strategy' => 'defer' )
	 *
	 * WordPress 6.2 (our minimum) only accepts a boolean. We detect
	 * support at runtime so the plugin stays compatible with both.
	 *
	 * @return array|true
	 */
	private static function defer_args() {
		static $supports_strategy = null;
		if ( null === $supports_strategy ) {
			// wp_register_script() started accepting array args in WP 6.3.
			$supports_strategy = version_compare( get_bloginfo( 'version' ), '6.3', '>=' );
		}
		if ( $supports_strategy ) {
			return array(
				'in_footer' => true,
				'strategy'  => 'defer',
			);
		}
		// Fallback: in-footer only (same behaviour as before, no regression).
		return true;
	}

	/**
	 * Decide which Swiper handle to use.
	 *
	 * Priority:
	 *   1. 'swiper'           — Elementor Pro core (already local, no CDN hit).
	 *   2. 'elementor-swiper' — older Elementor builds.
	 *   3. Local bundle       — assets/js/swiper-bundle.min.js (no CDN).
	 *   4. jsDelivr CDN       — last-resort fallback if local file missing.
	 *
	 * @return string Registered handle.
	 */
	private function resolve_swiper_handle() {
		if ( wp_script_is( 'swiper', 'registered' ) ) {
			return 'swiper';
		}
		if ( wp_script_is( 'elementor-swiper', 'registered' ) ) {
			return 'elementor-swiper';
		}

		if ( wp_script_is( self::HANDLE_SWIPER, 'registered' ) ) {
			return self::HANDLE_SWIPER;
		}

		// Prefer a local Swiper bundle to avoid an external CDN request.
		$local_js  = ZYMARG_WCPG_DIR . 'assets/js/swiper-bundle.min.js';
		$local_css = ZYMARG_WCPG_DIR . 'assets/css/swiper-bundle.min.css';

		if ( file_exists( $local_js ) ) {
			wp_register_script(
				self::HANDLE_SWIPER,
				ZYMARG_WCPG_URL . 'assets/js/swiper-bundle.min.js',
				array(),
				'11.0.0',
				self::defer_args()
			);
			if ( file_exists( $local_css ) ) {
				wp_register_style(
					self::HANDLE_SWIPER,
					ZYMARG_WCPG_URL . 'assets/css/swiper-bundle.min.css',
					array(),
					'11.0.0'
				);
			}
			return self::HANDLE_SWIPER;
		}

		// Last-resort CDN fallback (only if no local file exists).
		wp_register_script(
			self::HANDLE_SWIPER,
			'https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js',
			array(),
			'11.0.0',
			self::defer_args()
		);
		wp_register_style(
			self::HANDLE_SWIPER,
			'https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css',
			array(),
			'11.0.0'
		);

		return self::HANDLE_SWIPER;
	}
}
