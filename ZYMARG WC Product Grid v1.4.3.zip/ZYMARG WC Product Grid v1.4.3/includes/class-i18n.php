<?php
/**
 * Internationalisation loader.
 *
 * @package Zymarg\WCPG
 */

namespace Zymarg\WCPG;

defined( 'ABSPATH' ) || exit;

/**
 * Class I18n
 *
 * Loads the plugin's text domain. Since WordPress 4.6+ this happens
 * automatically for plugins hosted on .org, but we still call it for
 * self-hosted use (GitHub installs).
 */
class I18n {

	/**
	 * Hook into init to load translations.
	 */
	public function register() {
		add_action( 'init', array( $this, 'load_textdomain' ) );
	}

	/**
	 * Load the plugin text domain.
	 */
	public function load_textdomain() {
		load_plugin_textdomain(
			'zymarg-wcpg',
			false,
			dirname( ZYMARG_WCPG_BASENAME ) . '/languages'
		);
	}
}
