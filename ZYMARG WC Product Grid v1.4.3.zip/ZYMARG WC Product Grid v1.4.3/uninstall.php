<?php
/**
 * Uninstall handler.
 *
 * Runs when the user deletes the plugin from the WordPress Plugins screen.
 * Removes plugin-owned options, transients, and per-user data so no orphan
 * rows remain.
 *
 * @package Zymarg\WCPG
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

global $wpdb;

/* -------------------------------------------------------------------------
 * Options
 * ------------------------------------------------------------------------- */

$options = array(
	'zymarg_wcpg_version',
	'zymarg_wcpg_settings',
	'zymarg_wcpg_engagement',
	'zymarg_wcpg_engagement_pruned',
	'zymarg_wcpg_trending_cache',
	'zymarg_wcpg_trending_meta',
	'zymarg_wcpg_seed_done',
);

foreach ( $options as $option ) {
	delete_option( $option );
	delete_site_option( $option );
}

/* -------------------------------------------------------------------------
 * Transients (rate limiter + trending cache)
 * ------------------------------------------------------------------------- */

$wpdb->query(
	"DELETE FROM {$wpdb->options}
	 WHERE option_name LIKE '\\_transient\\_zymarg\\_%'
	    OR option_name LIKE '\\_transient\\_timeout\\_zymarg\\_%'"
);

if ( is_multisite() ) {
	$wpdb->query(
		"DELETE FROM {$wpdb->sitemeta}
		 WHERE meta_key LIKE '\\_site\\_transient\\_zymarg\\_%'
		    OR meta_key LIKE '\\_site\\_transient\\_timeout\\_zymarg\\_%'"
	);
}

/* -------------------------------------------------------------------------
 * User meta (wishlist, recently-viewed mirror)
 * ------------------------------------------------------------------------- */

$wpdb->query(
	"DELETE FROM {$wpdb->usermeta}
	 WHERE meta_key IN ('_zymarg_wishlist', '_zymarg_recently_viewed')"
);

/* -------------------------------------------------------------------------
 * Post meta (engagement counters)
 * ------------------------------------------------------------------------- */

$wpdb->query(
	"DELETE FROM {$wpdb->postmeta}
	 WHERE meta_key IN ('_zymarg_clicks_7d')"
);

/* -------------------------------------------------------------------------
 * Vendor cache transients + per-vendor user meta age key
 * ------------------------------------------------------------------------- */

$wpdb->query(
	"DELETE FROM {$wpdb->options}
	 WHERE option_name LIKE '\\_transient\\_zymarg\\_vendor\\_%'
	    OR option_name LIKE '\\_transient\\_timeout\\_zymarg\\_vendor\\_%'"
);

$wpdb->query(
	"DELETE FROM {$wpdb->usermeta}
	 WHERE meta_key = '_zymarg_vendor_cache_at'"
);
