<?php
/**
 * Slider wrapper template.
 *
 * @package Zymarg\WCPG
 *
 * @var array       $settings
 * @var int|string  $widget_id
 * @var array       $products
 */

defined( 'ABSPATH' ) || exit;

$show_heading   = isset( $settings['show_heading'] ) && 'yes' === $settings['show_heading'];
$heading_text   = isset( $settings['heading_text'] ) ? (string) $settings['heading_text'] : '';
$subheading     = isset( $settings['subheading_text'] ) ? (string) $settings['subheading_text'] : '';
$allowed_tags   = array( 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'div', 'span' );
$heading_tag    = isset( $settings['heading_tag'] ) && in_array( $settings['heading_tag'], $allowed_tags, true ) ? $settings['heading_tag'] : 'h2';
$show_view_all  = isset( $settings['show_view_all'] ) && 'yes' === $settings['show_view_all'];
$view_all_text  = isset( $settings['view_all_text'] ) ? (string) $settings['view_all_text'] : __( 'View All', 'zymarg-wcpg' );
$view_all_url   = isset( $settings['view_all_url']['url'] ) ? (string) $settings['view_all_url']['url'] : '';
$view_all_blank = ! empty( $settings['view_all_url']['is_external'] );
$view_all_nf    = ! empty( $settings['view_all_url']['nofollow'] );

$cols_d  = max( 1, min( 6, (int) ( $settings['columns'] ?? 4 ) ) );
$cols_t  = max( 1, min( 6, (int) ( $settings['columns_tablet'] ?? 3 ) ) );
$cols_m  = max( 1, min( 6, (int) ( $settings['columns_mobile'] ?? 2 ) ) );

$swiper_config = array(
	'slidesPerView' => $cols_m,
	'spaceBetween'  => isset( $settings['slider_space_between'] ) ? (int) $settings['slider_space_between'] : 20,
	'speed'         => isset( $settings['slider_speed'] ) ? (int) $settings['slider_speed'] : 500,
	'loop'          => ! isset( $settings['slider_loop'] ) || 'yes' === $settings['slider_loop'],
	'breakpoints'   => array(
		768 => array( 'slidesPerView' => $cols_t ),
		1025 => array( 'slidesPerView' => $cols_d ),
	),
);
if ( isset( $settings['slider_autoplay'] ) && 'yes' === $settings['slider_autoplay'] ) {
	$swiper_config['autoplay'] = array(
		'delay'                => isset( $settings['slider_autoplay_delay'] ) ? (int) $settings['slider_autoplay_delay'] : 4000,
		'disableOnInteraction' => false,
	);
}
$pagination_type = isset( $settings['slider_pagination_type'] ) ? (string) $settings['slider_pagination_type'] : 'bullets';
if ( $pagination_type ) {
	$swiper_config['pagination'] = array(
		'type'      => $pagination_type,
		'clickable' => true,
	);
}
if ( ! isset( $settings['slider_show_arrows'] ) || 'yes' === $settings['slider_show_arrows'] ) {
	$swiper_config['navigation'] = true;
}

$empty_message = isset( $settings['empty_message'] ) ? (string) $settings['empty_message'] : __( 'No products found.', 'zymarg-wcpg' );
?>
<div class="zymarg-wcpg zymarg-wcpg--slider"
	data-widget-id="<?php echo esc_attr( $widget_id ); ?>"
	data-zymarg-hydrate="1"
	data-show-view-cart="<?php echo ( ! isset( $settings['show_view_cart_link'] ) || 'yes' === $settings['show_view_cart_link'] ) ? '1' : '0'; ?>"
	data-swiper-config="<?php echo esc_attr( wp_json_encode( $swiper_config ) ); ?>">

	<?php if ( $show_heading && ( '' !== $heading_text || '' !== $subheading || ( $show_view_all && $view_all_url ) ) ) : ?>
		<div class="zymarg-wcpg__heading">
			<div class="zymarg-wcpg__heading-main">
				<?php if ( '' !== $heading_text ) : ?>
					<<?php echo esc_html( $heading_tag ); ?> class="zymarg-wcpg__heading-title"><?php echo esc_html( $heading_text ); ?></<?php echo esc_html( $heading_tag ); ?>>
				<?php endif; ?>
				<?php if ( '' !== $subheading ) : ?>
					<div class="zymarg-wcpg__heading-subtitle"><?php echo esc_html( $subheading ); ?></div>
				<?php endif; ?>
			</div>
			<?php if ( $show_view_all && '' !== $view_all_url ) : ?>
				<a class="zymarg-wcpg__heading-link"
					href="<?php echo esc_url( $view_all_url ); ?>"
					<?php echo $view_all_blank ? 'target="_blank"' : ''; ?>
					<?php echo $view_all_nf ? 'rel="nofollow noopener"' : ( $view_all_blank ? 'rel="noopener"' : '' ); ?>>
					<?php echo esc_html( $view_all_text ); ?>
				</a>
			<?php endif; ?>
		</div>
	<?php endif; ?>

	<?php if ( empty( $products ) ) : ?>
		<?php
		\Zymarg\WCPG\Template_Loader::get_template(
			'parts/empty-state.php',
			array( 'message' => $empty_message )
		);
		?>
	<?php else : ?>
		<div class="zymarg-wcpg__slider swiper">
			<div class="swiper-wrapper">
				<?php
				foreach ( $products as $product ) {
					if ( ! $product instanceof \WC_Product ) {
						continue;
					}
					echo '<div class="swiper-slide">';
					\Zymarg\WCPG\Template_Loader::get_template(
						'grid/product-card.php',
						array(
							'product'   => $product,
							'settings'  => $settings,
							'widget_id' => $widget_id,
						)
					);
					echo '</div>';
				}
				?>
			</div>

			<?php if ( ! isset( $settings['slider_show_arrows'] ) || 'yes' === $settings['slider_show_arrows'] ) : ?>
				<button type="button" class="zymarg-wcpg__slider-arrow zymarg-wcpg__slider-arrow--prev swiper-button-prev" aria-label="<?php esc_attr_e( 'Previous', 'zymarg-wcpg' ); ?>">
					<?php \Zymarg\WCPG\Product_Data::render_icon( $settings['slider_arrow_prev'] ?? null, 'fas fa-chevron-left' ); ?>
				</button>
				<button type="button" class="zymarg-wcpg__slider-arrow zymarg-wcpg__slider-arrow--next swiper-button-next" aria-label="<?php esc_attr_e( 'Next', 'zymarg-wcpg' ); ?>">
					<?php \Zymarg\WCPG\Product_Data::render_icon( $settings['slider_arrow_next'] ?? null, 'fas fa-chevron-right' ); ?>
				</button>
			<?php endif; ?>

			<?php if ( $pagination_type ) : ?>
				<div class="swiper-pagination"></div>
			<?php endif; ?>
		</div>
	<?php endif; ?>
</div>
