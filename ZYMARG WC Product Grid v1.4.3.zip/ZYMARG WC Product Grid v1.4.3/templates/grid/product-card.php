<?php
/**
 * Single product card template.
 *
 * Layout: rows render in a fixed top-to-bottom order, but which rows
 * appear and where the Add-to-Cart button lands are fully configurable.
 * Empty rows are omitted from the DOM so flexbox closes any gaps
 * automatically.
 *
 * Price position options:
 *   above_title  - renders before Row 1 (title)
 *   above_rating - renders before Row 2 (meta)
 *   below_rating - renders as Row 3 (default)
 *
 * Vendor position options:
 *   above_title  - renders before Row 1 (title)
 *   below_meta   - renders after Row 2 (meta)
 *   below_price  - renders after Row 3 / price (default)
 *
 * ATC position options (atc_position):
 *   standalone   - its own row, always last, pushed to the far right
 *   with_meta    - shares the meta row (Row 2), pushed to the far right
 *   with_price   - shares whichever row price is in (default)
 *   with_vendor  - shares whichever row vendor is in
 *                  (falls back to with_price if vendor is hidden/empty)
 *
 * Whichever row ATC pairs with becomes a full-width flex row; the ATC
 * wrapper uses margin-left:auto to sit at the far-right edge. If the
 * configured pairing target never renders (e.g. with_price but price
 * is hidden), ATC falls back to its own standalone row at the end.
 *
 * Theme override: copy to theme/zymarg-wcpg/grid/product-card.php
 *
 * @package Zymarg\WCPG
 *
 * @var \WC_Product $product
 * @var array       $settings
 * @var int|string  $widget_id
 */

defined( 'ABSPATH' ) || exit;

if ( ! ( $product instanceof \WC_Product ) ) {
	return;
}

// -- Visibility toggles -----------------------------------------------
$show_image     = ! isset( $settings['show_image'] ) || 'yes' === $settings['show_image'];
$show_discount  = ! isset( $settings['show_discount_badge'] ) || 'yes' === $settings['show_discount_badge'];
$show_stock     = ! isset( $settings['show_stock_badge'] ) || 'yes' === $settings['show_stock_badge'];
$show_wishlist  = ! isset( $settings['show_wishlist'] ) || 'yes' === $settings['show_wishlist'];
$show_quickview = ! isset( $settings['show_quickview'] ) || 'yes' === $settings['show_quickview'];
$show_atc       = ! isset( $settings['show_atc'] ) || 'yes' === $settings['show_atc'];
$show_title     = ! isset( $settings['show_title'] ) || 'yes' === $settings['show_title'];
$show_vendor    = isset( $settings['show_vendor'] ) && 'yes' === $settings['show_vendor'];
$show_price     = ! isset( $settings['show_price'] ) || 'yes' === $settings['show_price'];

// -- Price position (3 options) ----------------------------------------
$allowed_pp     = array( 'above_title', 'above_rating', 'below_rating' );
$price_position = isset( $settings['price_position'] ) && in_array( $settings['price_position'], $allowed_pp, true )
	? $settings['price_position']
	: 'below_rating';

// -- Vendor position (3 options) ----------------------------------------
$allowed_vp      = array( 'above_title', 'below_meta', 'below_price' );
$vendor_position = $show_vendor && isset( $settings['vendor_position'] )
	&& in_array( $settings['vendor_position'], $allowed_vp, true )
	? $settings['vendor_position']
	: 'below_price';

// -- ATC position (4 options) --------------------------------------------
$allowed_atc_pos = array( 'standalone', 'with_meta', 'with_price', 'with_vendor' );
$atc_position    = isset( $settings['atc_position'] ) && in_array( $settings['atc_position'], $allowed_atc_pos, true )
	? $settings['atc_position']
	: 'with_price';

// -- ATC transform style (5 options, 'custom' adds rotate/offset/scale) --
$allowed_atc_transform = array( 'none', 'scale', 'slide_up', 'slide_in', 'custom' );
$atc_transform         = isset( $settings['atc_transform'] )
	&& in_array( $settings['atc_transform'], $allowed_atc_transform, true )
	? $settings['atc_transform']
	: 'none';

// -- Image options -----------------------------------------------------
$image_full = isset( $settings['image_full_resolution'] ) && 'yes' === $settings['image_full_resolution'];
$image_zoom = ! isset( $settings['image_hover_zoom'] ) || 'yes' === $settings['image_hover_zoom'];

// -- Product data ------------------------------------------------------
$product_id  = (int) $product->get_id();
$permalink   = $product->get_permalink();
$title       = $product->get_name();
$is_in_stock = $product->is_in_stock();

// -- Inline badges (v1.3.25): discount badge now lives in the price row
//    and stock badge lives in the meta row, instead of being absolutely
//    positioned over the product image.
// ---------------------------------------------------------------------
$discount_badge_html = '';
if ( $show_discount && $product->is_on_sale() ) {
	$discount_mode       = isset( $settings['discount_badge_mode'] ) ? (string) $settings['discount_badge_mode'] : 'percent';
	$raw_badge           = (string) \Zymarg\WCPG\Product_Data::get_discount_badge_html( $product, $discount_mode );
	// The helper outputs <span class="zymarg-wcpg__badge zymarg-wcpg__badge--discount">…</span>.
	// We add the --inline modifier so CSS can switch from absolute to flow layout.
	$discount_badge_html = str_replace(
		'zymarg-wcpg__badge--discount',
		'zymarg-wcpg__badge--discount zymarg-wcpg__badge--inline',
		$raw_badge
	);
}

$stock_badge_html = '';
if ( $show_stock ) {
	$show_in  = isset( $settings['show_stock_in'] ) && 'yes' === $settings['show_stock_in'];
	$show_out = ! isset( $settings['show_stock_out'] ) || 'yes' === $settings['show_stock_out'];
	if ( $is_in_stock && $show_in ) {
		$stock_badge_html = sprintf(
			'<span class="zymarg-wcpg__badge zymarg-wcpg__badge--stock-in zymarg-wcpg__badge--inline">%s</span>',
			esc_html__( 'In stock', 'zymarg-wcpg' )
		);
	} elseif ( ! $is_in_stock && $show_out ) {
		$stock_badge_html = sprintf(
			'<span class="zymarg-wcpg__badge zymarg-wcpg__badge--stock-out zymarg-wcpg__badge--inline">%s</span>',
			esc_html__( 'Out of stock', 'zymarg-wcpg' )
		);
	}
}

// -- Card classes ------------------------------------------------------
$card_classes = array( 'zymarg-wcpg__card' );
if ( ! $is_in_stock ) {
	$card_classes[] = 'is-oos';
}
if ( $product->is_on_sale() ) {
	$card_classes[] = 'is-on-sale';
}
$card_classes[] = 'zymarg-wcpg__card--' . esc_attr( $product->get_type() );

// -- Algolia click-analytics -------------------------------------------
$algolia_query_id = (string) apply_filters( 'zymarg_wcpg_algolia_query_id', '' );
$algolia_position = 0;
if ( '' !== $algolia_query_id ) {
	static $zymarg_algolia_card_position = 0;
	$zymarg_algolia_card_position++;
	$algolia_position = $zymarg_algolia_card_position;
}

// -----------------------------------------------------------------------
// Pre-render vendor / price / meta so we can detect whether each row has
// real content (vendor.php and rating-soldcount.php both early-return
// when there is nothing to show).
// -----------------------------------------------------------------------

// -- Vendor ---------------------------------------------------------------
$vendor_html = '';
if ( $show_vendor ) {
	ob_start();
	\Zymarg\WCPG\Template_Loader::get_template(
		'grid/vendor.php',
		array(
			'product'  => $product,
			'settings' => $settings,
		)
	);
	$vendor_html = ob_get_clean();
}
$vendor_has_content = '' !== trim( $vendor_html );

// -- Price ------------------------------------------------------------------
$price_html = '';
if ( $show_price ) {
	ob_start();
	\Zymarg\WCPG\Template_Loader::get_template(
		'grid/price.php',
		array(
			'product'  => $product,
			'settings' => $settings,
		)
	);
	// v1.3.25: discount badge appended into the price row, after the price.
	// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- badge HTML built from esc_*() helpers above.
	echo $discount_badge_html;
	$price_html = ob_get_clean();
}
$price_has_content = '' !== trim( $price_html );

// -- Meta (rating + sold count) ---------------------------------------------
ob_start();
\Zymarg\WCPG\Template_Loader::get_template(
	'grid/rating-soldcount.php',
	array(
		'product'          => $product,
		'settings'         => $settings,
		'wrapper_class'    => '',
		'stock_badge_html' => $stock_badge_html, // v1.3.25: stock badge now lives here.
	)
);
$meta_html = ob_get_clean();
$meta_has_content = '' !== trim( $meta_html );

// -----------------------------------------------------------------------
// ATC pairing logic.
//
// 1. Resolve effective position - with_vendor falls back to with_price
//    when vendor is hidden or has nothing to show.
// 2. Compute one boolean per possible pairing slot. price_position and
//    vendor_position are each a single value, so at most one
//    "with_price"/"with_vendor" flag and the single "with_meta" flag can
//    be true - no double-rendering risk.
// 3. If nothing matched (target row hidden/empty), ATC falls back to its
//    own standalone row at the very end.
// -----------------------------------------------------------------------
$effective_atc_position = $atc_position;
if ( 'with_vendor' === $effective_atc_position && ! $vendor_has_content ) {
	$effective_atc_position = 'with_price';
}

$pair_vendor_above_title  = $show_atc && $vendor_has_content && 'above_title' === $vendor_position && 'with_vendor' === $effective_atc_position;
$pair_price_above_title   = $show_atc && $price_has_content && 'above_title' === $price_position && 'with_price' === $effective_atc_position;
$pair_price_above_rating  = $show_atc && $price_has_content && 'above_rating' === $price_position && 'with_price' === $effective_atc_position;
$pair_meta                = $show_atc && 'with_meta' === $effective_atc_position;
$pair_vendor_below_meta   = $show_atc && $vendor_has_content && 'below_meta' === $vendor_position && 'with_vendor' === $effective_atc_position;
$pair_price_below_rating  = $show_atc && $price_has_content && 'below_rating' === $price_position && 'with_price' === $effective_atc_position;
$pair_vendor_below_price  = $show_atc && $vendor_has_content && 'below_price' === $vendor_position && 'with_vendor' === $effective_atc_position;

$atc_placed = $pair_vendor_above_title || $pair_price_above_title || $pair_price_above_rating
	|| $pair_meta || $pair_vendor_below_meta || $pair_price_below_rating || $pair_vendor_below_price;

$show_standalone_atc = $show_atc && ! $atc_placed;

// -- ATC button render data -------------------------------------------------
$is_simple_in_stock = $product->is_type( 'simple' ) && $product->is_purchasable() && $is_in_stock;
$atc_url            = $permalink;
$atc_label          = $is_simple_in_stock
	? __( 'Add to cart', 'zymarg-wcpg' )
	: ( $product->is_type( 'variable' )
		? __( 'Select options', 'zymarg-wcpg' )
		: __( 'Read more', 'zymarg-wcpg' ) );

$atc_wrap_classes    = array( 'zymarg-wcpg__atc-wrap', 'zymarg-wcpg__atc-wrap--' . $atc_transform );
$atc_wrap_class_attr = esc_attr( implode( ' ', $atc_wrap_classes ) );

/**
 * Render the ATC button + its transform wrapper.
 * Defined once, called from whichever row it ends up paired with.
 */
$render_atc_button = function() use ( $atc_wrap_class_attr, $atc_url, $product_id, $product, $atc_label, $settings ) {
	?>
	<div class="<?php echo $atc_wrap_class_attr; ?>">
		<a class="zymarg-wcpg__icon-btn zymarg-wcpg__icon-btn--atc"
			href="<?php echo esc_url( $atc_url ); ?>"
			data-action="add-to-cart"
			data-product-id="<?php echo esc_attr( $product_id ); ?>"
			data-product-type="<?php echo esc_attr( $product->get_type() ); ?>"
			aria-label="<?php echo esc_attr( $atc_label ); ?>">
			<?php \Zymarg\WCPG\Product_Data::render_icon( $settings['atc_icon'] ?? null, 'fas fa-plus' ); ?>
		</a>
	</div>
	<?php
};

/**
 * Render a generic row. $extra_classes is an array of additional class
 * names (e.g. position variant + has-atc). $inner_html is raw HTML from
 * a sub-template (already escaped by that template). $pair_atc renders
 * the ATC button at the end of the row when true.
 */
$render_row = function( $row_class, array $extra_classes, $inner_html, $pair_atc ) use ( $render_atc_button ) {
	$classes   = array_merge( array( 'zymarg-wcpg__row', $row_class ), $extra_classes );
	if ( $pair_atc ) {
		$classes[] = 'zymarg-wcpg__row--has-atc';
	}
	$classes = array_filter( $classes );
	?>
	<div class="<?php echo esc_attr( implode( ' ', $classes ) ); ?>">
		<?php
		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- sub-templates already escape their own output.
		echo $inner_html;
		if ( $pair_atc ) {
			$render_atc_button();
		}
		?>
	</div>
	<?php
};
?>
<div class="<?php echo esc_attr( implode( ' ', $card_classes ) ); ?>"
	data-product-id="<?php echo esc_attr( $product_id ); ?>"
	<?php if ( '' !== $algolia_query_id ) : ?>
		data-algolia-query-id="<?php echo esc_attr( $algolia_query_id ); ?>"
		data-algolia-position="<?php echo esc_attr( $algolia_position ); ?>"
	<?php endif; ?>>

	<?php // ---- IMAGE CONTAINER ---------------------------------------- ?>
	<?php if ( $show_image ) : ?>
		<div class="zymarg-wcpg__image-container<?php echo $image_zoom ? ' has-zoom' : ''; ?>">
			<a class="zymarg-wcpg__image-link"
				href="<?php echo esc_url( $permalink ); ?>"
				aria-label="<?php echo esc_attr( $title ); ?>">
				<?php
				$image_size = $image_full ? 'full' : 'woocommerce_thumbnail';
				$image_id   = (int) $product->get_image_id();
				if ( $image_id ) {
					echo wp_get_attachment_image(
						$image_id,
						$image_size,
						false,
						array(
							'class'    => 'zymarg-wcpg__image',
							'loading'  => 'lazy',
							'decoding' => 'async',
							'alt'      => esc_attr( $title ),
						)
					);
				} else {
					echo wc_placeholder_img( $image_size, array( 'class' => 'zymarg-wcpg__image' ) );
				}
				?>
			</a>

			<?php
			// v1.3.25: badges (discount + stock) moved out of the image
			// overlay and into the content box (price row + meta row).
			// The badges.php template is no longer called from here; it
			// remains in the codebase so theme overrides that reference
			// it directly continue to load without errors.
			?>

			<?php if ( $show_quickview ) : ?>
				<?php
				$qv_visibility = isset( $settings['quickview_visibility'] ) ? (string) $settings['quickview_visibility'] : 'desktop';
				$allowed_qv    = array( 'desktop', 'tablet', 'mobile', 'desktop_tablet', 'tablet_mobile', 'all' );
				if ( ! in_array( $qv_visibility, $allowed_qv, true ) ) {
					$qv_visibility = 'desktop';
				}
				// v1.3.25: display style — hover-only (default) hides the
				// icon until the user hovers the card on a hover-capable
				// device; always shows it permanently.
				$qv_display = isset( $settings['quickview_display'] ) ? (string) $settings['quickview_display'] : 'hover_only';
				if ( ! in_array( $qv_display, array( 'hover_only', 'always' ), true ) ) {
					$qv_display = 'hover_only';
				}
				?>
				<button type="button"
					class="zymarg-wcpg__icon-btn zymarg-wcpg__icon-btn--quickview"
					data-action="quickview"
					data-product-id="<?php echo esc_attr( $product_id ); ?>"
					data-qv-visibility="<?php echo esc_attr( $qv_visibility ); ?>"
					data-qv-display="<?php echo esc_attr( $qv_display ); ?>"
					aria-label="<?php esc_attr_e( 'Quick view', 'zymarg-wcpg' ); ?>">
					<?php \Zymarg\WCPG\Product_Data::render_icon( $settings['quickview_icon'] ?? null, 'far fa-eye' ); ?>
				</button>
			<?php endif; ?>

			<?php if ( $show_wishlist ) : ?>
				<?php $is_wished = \Zymarg\WCPG\Wishlist\Wishlist_Store::has( $product_id ); ?>
				<button type="button"
					class="zymarg-wcpg__icon-btn zymarg-wcpg__icon-btn--wishlist"
					data-action="wishlist-toggle"
					data-product-id="<?php echo esc_attr( $product_id ); ?>"
					aria-label="<?php echo esc_attr( $is_wished ? __( 'Remove from wishlist', 'zymarg-wcpg' ) : __( 'Add to wishlist', 'zymarg-wcpg' ) ); ?>"
					aria-pressed="<?php echo $is_wished ? 'true' : 'false'; ?>">
					<span class="zymarg-wcpg__icon-idle">
						<?php \Zymarg\WCPG\Product_Data::render_icon( $settings['wishlist_icon'] ?? null, 'far fa-heart' ); ?>
					</span>
					<span class="zymarg-wcpg__icon-active">
						<?php \Zymarg\WCPG\Product_Data::render_icon( $settings['wishlist_icon_active'] ?? null, 'fas fa-heart' ); ?>
					</span>
				</button>
			<?php endif; ?>
		</div>
	<?php endif; ?>

	<?php // ---- CONTENT BOX ---------------------------------------------- ?>
	<div class="zymarg-wcpg__content">

		<?php // ---- Vendor @ above_title ------------------------------- ?>
		<?php if ( $vendor_has_content && 'above_title' === $vendor_position ) : ?>
			<?php $render_row( 'zymarg-wcpg__row--vendor', array( 'zymarg-wcpg__row--vendor-above' ), $vendor_html, $pair_vendor_above_title ); ?>
		<?php endif; ?>

		<?php // ---- Price @ above_title ---------------------------------- ?>
		<?php if ( $price_has_content && 'above_title' === $price_position ) : ?>
			<?php $render_row( 'zymarg-wcpg__row--price', array( 'zymarg-wcpg__row--price-above-title' ), $price_html, $pair_price_above_title ); ?>
		<?php endif; ?>

		<?php // ---- ROW 1: Title ------------------------------------------ ?>
		<?php if ( $show_title ) : ?>
			<div class="zymarg-wcpg__row zymarg-wcpg__row--title">
				<a class="zymarg-wcpg__title-link" href="<?php echo esc_url( $permalink ); ?>">
					<h3 class="zymarg-wcpg__title"><?php echo esc_html( $title ); ?></h3>
				</a>
			</div>
		<?php endif; ?>

		<?php // ---- Price @ above_rating ---------------------------------- ?>
		<?php if ( $price_has_content && 'above_rating' === $price_position ) : ?>
			<?php $render_row( 'zymarg-wcpg__row--price', array( 'zymarg-wcpg__row--price-above-rating' ), $price_html, $pair_price_above_rating ); ?>
		<?php endif; ?>

		<?php // ---- ROW 2: Rating + Sold Count (renders if it has content,
		       //      or if ATC is paired here even when meta itself is empty) -- ?>
		<?php if ( $meta_has_content || $pair_meta ) : ?>
			<?php $render_row( 'zymarg-wcpg__row--meta', array(), $meta_html, $pair_meta ); ?>
		<?php endif; ?>

		<?php // ---- Vendor @ below_meta ------------------------------------ ?>
		<?php if ( $vendor_has_content && 'below_meta' === $vendor_position ) : ?>
			<?php $render_row( 'zymarg-wcpg__row--vendor', array(), $vendor_html, $pair_vendor_below_meta ); ?>
		<?php endif; ?>

		<?php // ---- ROW 3: Price @ below_rating (default) ------------------ ?>
		<?php if ( $price_has_content && 'below_rating' === $price_position ) : ?>
			<?php $render_row( 'zymarg-wcpg__row--price', array(), $price_html, $pair_price_below_rating ); ?>
		<?php endif; ?>

		<?php // ---- Vendor @ below_price (default) -------------------------- ?>
		<?php if ( $vendor_has_content && 'below_price' === $vendor_position ) : ?>
			<?php $render_row( 'zymarg-wcpg__row--vendor', array(), $vendor_html, $pair_vendor_below_price ); ?>
		<?php endif; ?>

		<?php // ---- Standalone ATC row (always last, fallback-safe) -------- ?>
		<?php if ( $show_standalone_atc ) : ?>
			<div class="zymarg-wcpg__row zymarg-wcpg__row--atc-standalone zymarg-wcpg__row--has-atc">
				<?php $render_atc_button(); ?>
			</div>
		<?php endif; ?>

	</div>

</div>
