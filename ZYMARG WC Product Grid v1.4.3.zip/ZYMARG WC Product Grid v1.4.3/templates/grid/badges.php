<?php
/**
 * Discount + stock badges.
 *
 * @package Zymarg\WCPG
 *
 * @var \WC_Product $product
 * @var array       $settings
 */

defined( 'ABSPATH' ) || exit;

if ( ! ( $product instanceof \WC_Product ) ) {
	return;
}

$show_discount = ! isset( $settings['show_discount_badge'] ) || 'yes' === $settings['show_discount_badge'];
$show_stock    = ! isset( $settings['show_stock_badge'] ) || 'yes' === $settings['show_stock_badge'];
$show_in       = isset( $settings['show_stock_in'] ) && 'yes' === $settings['show_stock_in'];
$show_out      = ! isset( $settings['show_stock_out'] ) || 'yes' === $settings['show_stock_out'];
$mode          = isset( $settings['discount_badge_mode'] ) ? (string) $settings['discount_badge_mode'] : 'percent';

if ( $show_discount && $product->is_on_sale() ) {
	echo \Zymarg\WCPG\Product_Data::get_discount_badge_html( $product, $mode ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- pre-escaped in helper.
}

if ( $show_stock ) {
	$is_in_stock = $product->is_in_stock();
	if ( $is_in_stock && $show_in ) {
		printf(
			'<span class="zymarg-wcpg__badge zymarg-wcpg__badge--stock-in">%s</span>',
			esc_html__( 'In stock', 'zymarg-wcpg' )
		);
	} elseif ( ! $is_in_stock && $show_out ) {
		printf(
			'<span class="zymarg-wcpg__badge zymarg-wcpg__badge--stock-out">%s</span>',
			esc_html__( 'Out of stock', 'zymarg-wcpg' )
		);
	}
}
