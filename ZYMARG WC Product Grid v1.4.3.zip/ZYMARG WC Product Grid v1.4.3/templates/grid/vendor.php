<?php
/**
 * Vendor profile row — shown below the product title on each card.
 *
 * Requires Dokan Lite or Pro 3.10+. Silently outputs nothing when:
 *   - Dokan is not active / below minimum version.
 *   - Vendor cannot be resolved for this product.
 *   - Vendor's selling or publishing status is suspended.
 *
 * Theme override: copy to theme/zymarg-wcpg/grid/vendor.php
 *
 * @package Zymarg\WCPG
 *
 * @var \WC_Product $product
 * @var array       $settings
 */

defined( 'ABSPATH' ) || exit;

if ( ! ( $product instanceof \WC_Product ) ) {
	return;
}

// Guard: Dokan must be active at the minimum version.
if ( ! \Zymarg\WCPG\Vendor\Vendor_Resolver::is_supported() ) {
	return;
}

$product_id = (int) $product->get_id();

// Resolve vendor ID — use cache when available.
$cache_key = 'vendor_id_' . $product_id;
$vendor_id = \Zymarg\WCPG\Vendor\Vendor_Cache::get( $product_id, $cache_key );
if ( false === $vendor_id ) {
	$vendor_id = \Zymarg\WCPG\Vendor\Vendor_Resolver::resolve( $product_id );
	\Zymarg\WCPG\Vendor\Vendor_Cache::set( $product_id, array( $vendor_id ), $cache_key );
} else {
	// Cache returns array; unwrap.
	$vendor_id = isset( $vendor_id[0] ) ? (int) $vendor_id[0] : 0;
}

if ( ! $vendor_id ) {
	return;
}

// Validate vendor status (selling enabled, publishing not suspended).
$status = \Zymarg\WCPG\Vendor\Vendor_Resolver::check_vendor_status( $vendor_id );
if ( empty( $status['ok'] ) ) {
	return;
}

// ── Gather vendor data ────────────────────────────────────────────────────
$display  = isset( $settings['vendor_display'] ) ? (string) $settings['vendor_display'] : 'avatar_name';
$linkable = ! isset( $settings['vendor_link'] ) || 'yes' === $settings['vendor_link'];

// Store name: Dokan stores it in dokan_profile_settings['store_name'],
// but the helper function is the safest cross-version way to get it.
$store_name = '';
if ( function_exists( 'dokan_get_store_info' ) ) {
	$store_info = dokan_get_store_info( $vendor_id );
	$store_name = ! empty( $store_info['store_name'] ) ? (string) $store_info['store_name'] : '';
}
// Fallback to WP display name.
if ( ! $store_name ) {
	$user       = get_user_by( 'id', $vendor_id );
	$store_name = $user ? $user->display_name : '';
}
if ( ! $store_name ) {
	return; // Nothing useful to display.
}

// Store URL.
$store_url = '';
if ( $linkable ) {
	if ( function_exists( 'dokan_get_store_url' ) ) {
		$store_url = dokan_get_store_url( $vendor_id );
	}
}

// Avatar — WordPress gravatar / profile photo.
$show_avatar = in_array( $display, array( 'avatar_name', 'avatar_name_location' ), true );
$avatar_size = isset( $settings['vendor_avatar_size']['size'] )
	? max( 12, min( 80, (int) $settings['vendor_avatar_size']['size'] ) )
	: 24;

// Avatar side: 'left' (default) or 'right'.
$avatar_side = isset( $settings['vendor_avatar_side'] ) && 'right' === $settings['vendor_avatar_side']
	? 'right'
	: 'left';

// Avatar shape: 'circle' (default), 'rounded', 'square'.
$allowed_shapes = array( 'circle', 'rounded', 'square' );
$avatar_shape   = isset( $settings['vendor_avatar_shape'] ) && in_array( $settings['vendor_avatar_shape'], $allowed_shapes, true )
	? $settings['vendor_avatar_shape']
	: 'circle';

// Location (city) — stored in dokan_profile_settings.
$location = '';
if ( 'avatar_name_location' === $display ) {
	if ( function_exists( 'dokan_get_store_info' ) ) {
		$store_info = $store_info ?? dokan_get_store_info( $vendor_id );
		$location   = ! empty( $store_info['address']['city'] ) ? (string) $store_info['address']['city'] : '';
		// Some Dokan versions store it flat.
		if ( ! $location && ! empty( $store_info['location'] ) ) {
			$location = (string) $store_info['location'];
		}
	}
}
?>
<div class="zymarg-wcpg__vendor zymarg-wcpg__vendor--avatar-<?php echo esc_attr( $avatar_side ); ?>">
	<?php if ( $store_url ) : ?>
		<a class="zymarg-wcpg__vendor-inner"
			href="<?php echo esc_url( $store_url ); ?>"
			aria-label="<?php echo esc_attr( sprintf( /* translators: %s: vendor store name */ __( 'Visit %s store', 'zymarg-wcpg' ), $store_name ) ); ?>">
	<?php else : ?>
		<span class="zymarg-wcpg__vendor-inner">
	<?php endif; ?>

		<?php if ( $show_avatar ) : ?>
			<?php
			echo get_avatar(
				$vendor_id,
				$avatar_size * 2, // 2× for retina; CSS constrains display size.
				'',
				esc_attr( $store_name ),
				array(
					'class'   => 'zymarg-wcpg__vendor-avatar zymarg-wcpg__vendor-avatar--' . esc_attr( $avatar_shape ),
					'loading' => 'lazy',
				)
			);
			?>
		<?php endif; ?>

		<span class="zymarg-wcpg__vendor-meta">
			<span class="zymarg-wcpg__vendor-name"><?php echo esc_html( $store_name ); ?></span>
			<?php if ( $location ) : ?>
				<span class="zymarg-wcpg__vendor-location"><?php echo esc_html( $location ); ?></span>
			<?php endif; ?>
		</span>

	<?php if ( $store_url ) : ?>
		</a>
	<?php else : ?>
		</span>
	<?php endif; ?>
</div>
