<?php
/**
 * Empty-state template (no products found).
 *
 * @package Zymarg\WCPG
 *
 * @var string $message
 */

defined( 'ABSPATH' ) || exit;

$message = isset( $message ) ? (string) $message : __( 'No products found.', 'zymarg-wcpg' );
?>
<div class="zymarg-wcpg__empty" role="status">
	<p><?php echo esc_html( $message ); ?></p>
</div>
