<?php
/**
 * Quick View modal content.
 *
 * @package Zymarg\WCPG
 *
 * @var \WC_Product $product
 * @var array       $data
 */

defined( 'ABSPATH' ) || exit;

$qv_id = 'zymarg-qv-' . (int) $data['id'];
?>
<div class="zymarg-wcpg__qv-product" data-product-id="<?php echo esc_attr( $data['id'] ); ?>" data-product-type="<?php echo esc_attr( $data['type'] ); ?>">
	<div class="zymarg-wcpg__qv-gallery">
		<div class="zymarg-wcpg__qv-gallery-main">
			<img class="zymarg-wcpg__qv-image"
				src="<?php echo esc_url( $data['gallery'][0]['large'] ); ?>"
				alt="<?php echo esc_attr( $data['name'] ); ?>"
				loading="lazy" decoding="async" />
		</div>
		<?php if ( count( $data['gallery'] ) > 1 ) : ?>
			<div class="zymarg-wcpg__qv-gallery-thumbs">
				<?php foreach ( $data['gallery'] as $i => $img ) : ?>
					<button type="button"
						class="zymarg-wcpg__qv-thumb<?php echo 0 === $i ? ' is-active' : ''; ?>"
						data-large="<?php echo esc_url( $img['large'] ); ?>"
						aria-label="<?php echo esc_attr( sprintf( /* translators: %d: image index */ __( 'Image %d', 'zymarg-wcpg' ), $i + 1 ) ); ?>">
						<img src="<?php echo esc_url( $img['thumb'] ); ?>"
							alt=""
							loading="lazy" decoding="async" />
					</button>
				<?php endforeach; ?>
			</div>
		<?php endif; ?>
	</div>

	<div class="zymarg-wcpg__qv-info">
		<h2 id="zymarg-wcpg-qv-title" class="zymarg-wcpg__qv-title"><?php echo esc_html( $data['name'] ); ?></h2>

		<?php if ( $data['rating'] > 0 && $data['rating_count'] > 0 ) : ?>
			<div class="zymarg-wcpg__qv-rating"
				aria-label="<?php echo esc_attr( sprintf( /* translators: %s: rating */ __( 'Rated %s out of 5', 'zymarg-wcpg' ), number_format_i18n( $data['rating'], 1 ) ) ); ?>">
				<span class="zymarg-wcpg__rating-stars" aria-hidden="true">
					<span class="zymarg-wcpg__rating-fill" style="width: <?php echo esc_attr( ( $data['rating'] / 5 ) * 100 ); ?>%"></span>
				</span>
				<span class="zymarg-wcpg__qv-rating-count">(<?php echo esc_html( number_format_i18n( $data['rating_count'] ) ); ?>)</span>
			</div>
		<?php endif; ?>

		<div class="zymarg-wcpg__qv-price"><?php echo wp_kses_post( $data['price_html'] ); ?></div>

		<?php if ( $data['excerpt'] ) : ?>
			<div class="zymarg-wcpg__qv-excerpt"><?php echo esc_html( $data['excerpt'] ); ?></div>
		<?php endif; ?>

		<?php if ( $data['is_variable'] && ! empty( $data['attributes'] ) ) : ?>
			<form class="zymarg-wcpg__qv-variations" data-variations="<?php echo esc_attr( wp_json_encode( $data['variations'] ) ); ?>">
				<?php
				\Zymarg\WCPG\Template_Loader::get_template(
					'quickview/swatches.php',
					array( 'attributes' => $data['attributes'] )
				);
				?>
				<div class="zymarg-wcpg__qv-variation-status" role="status" aria-live="polite"></div>
			</form>
		<?php endif; ?>

		<div class="zymarg-wcpg__qv-quantity" role="group" aria-label="<?php esc_attr_e( 'Quantity', 'zymarg-wcpg' ); ?>">
			<button type="button"
				class="zymarg-wcpg__qv-qty-btn zymarg-wcpg__qv-qty-btn--inc"
				data-action="qty-inc"
				aria-label="<?php esc_attr_e( 'Increase quantity', 'zymarg-wcpg' ); ?>">+</button>
			<input id="<?php echo esc_attr( $qv_id . '-qty' ); ?>"
				type="number"
				class="zymarg-wcpg__qv-qty"
				value="1"
				min="<?php echo esc_attr( max( 1, (int) $data['min_qty'] ) ); ?>"
				<?php if ( (int) $data['max_qty'] > 0 ) : ?>max="<?php echo esc_attr( (int) $data['max_qty'] ); ?>"<?php endif; ?>
				step="1"
				aria-label="<?php esc_attr_e( 'Quantity', 'zymarg-wcpg' ); ?>" />
			<button type="button"
				class="zymarg-wcpg__qv-qty-btn zymarg-wcpg__qv-qty-btn--dec"
				data-action="qty-dec"
				aria-label="<?php esc_attr_e( 'Decrease quantity', 'zymarg-wcpg' ); ?>">&minus;</button>
		</div>

		<div class="zymarg-wcpg__qv-actions">
			<button type="button"
				class="zymarg-wcpg__qv-btn zymarg-wcpg__qv-btn--atc"
				data-action="add-to-cart"
				<?php echo $data['is_variable'] ? 'disabled' : ''; ?>>
				<?php esc_html_e( 'Add to cart', 'zymarg-wcpg' ); ?>
			</button>
			<button type="button"
				class="zymarg-wcpg__qv-btn zymarg-wcpg__qv-btn--buy-now"
				data-action="buy-now"
				<?php echo $data['is_variable'] ? 'disabled' : ''; ?>>
				<?php
				$buy_now_label = apply_filters( 'zymarg_wcpg_buy_now_label', __( 'Buy now', 'zymarg-wcpg' ) );
				echo esc_html( $buy_now_label );
				?>
			</button>
		</div>

		<?php if ( ! $data['in_stock'] ) : ?>
			<div class="zymarg-wcpg__qv-stock-msg is-oos"><?php esc_html_e( 'Out of stock', 'zymarg-wcpg' ); ?></div>
		<?php endif; ?>

		<a class="zymarg-wcpg__qv-details-link"
			href="<?php echo esc_url( $data['permalink'] ); ?>">
			<?php esc_html_e( 'View full details', 'zymarg-wcpg' ); ?> &rarr;
		</a>
	</div>
</div>
