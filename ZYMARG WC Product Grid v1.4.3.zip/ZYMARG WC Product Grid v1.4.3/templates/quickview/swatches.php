<?php
/**
 * Quick View attribute swatches + dropdowns.
 *
 * Auto-detects each attribute's render type (color / image / label /
 * button / select) and renders accordingly. Attribute name labels are
 * NOT rendered visually - they are exposed to assistive tech via
 * `aria-label` on the wrapping group.
 *
 * Variation value name (e.g. "Red", "Cotton") is shown beside the
 * swatch icon for color and image types.
 *
 * @package Zymarg\WCPG
 *
 * @var array $attributes
 */

defined( 'ABSPATH' ) || exit;

if ( empty( $attributes ) || ! is_array( $attributes ) ) {
	return;
}
?>
<?php foreach ( $attributes as $attr ) : ?>
	<div class="zymarg-wcpg__qv-attr zymarg-wcpg__qv-attr--<?php echo esc_attr( $attr['type'] ); ?>"
		role="group"
		aria-label="<?php echo esc_attr( $attr['label'] ); ?>"
		data-attribute-name="<?php echo esc_attr( $attr['name'] ); ?>"
		data-slug="<?php echo esc_attr( $attr['slug'] ); ?>"
		data-attr-type="<?php echo esc_attr( $attr['type'] ); ?>">

		<?php
		$type    = $attr['type'];
		$is_iconified = ( 'color' === $type || 'image' === $type );
		$is_pillish   = ( 'label' === $type || 'button' === $type );

		if ( $is_iconified || $is_pillish ) :
		?>
			<div class="zymarg-wcpg__qv-swatches" role="listbox" aria-label="<?php echo esc_attr( $attr['label'] ); ?>">
				<?php foreach ( $attr['values'] as $value ) : ?>
					<button type="button"
						class="zymarg-wcpg__qv-swatch zymarg-wcpg__qv-swatch--<?php echo esc_attr( $type ); ?>"
						role="option"
						aria-selected="false"
						data-value="<?php echo esc_attr( $value['value'] ); ?>"
						data-label="<?php echo esc_attr( $value['label'] ); ?>">

						<?php if ( 'color' === $type ) : ?>
							<span class="zymarg-wcpg__qv-swatch-icon"
								style="background-color: <?php echo esc_attr( $value['swatch_color'] ? $value['swatch_color'] : '#cccccc' ); ?>;"
								aria-hidden="true">
								<?php if ( ! $value['swatch_color'] ) : ?>
									<span class="zymarg-wcpg__qv-swatch-letter"><?php echo esc_html( mb_substr( $value['label'], 0, 1 ) ); ?></span>
								<?php endif; ?>
							</span>
						<?php elseif ( 'image' === $type ) : ?>
							<span class="zymarg-wcpg__qv-swatch-icon zymarg-wcpg__qv-swatch-icon--image"
								<?php echo $value['swatch_image'] ? 'style="background-image: url(\'' . esc_url( $value['swatch_image'] ) . '\');"' : ''; ?>
								aria-hidden="true">
								<?php if ( ! $value['swatch_image'] ) : ?>
									<span class="zymarg-wcpg__qv-swatch-letter"><?php echo esc_html( mb_substr( $value['label'], 0, 1 ) ); ?></span>
								<?php endif; ?>
							</span>
						<?php endif; ?>

						<span class="zymarg-wcpg__qv-swatch-name"><?php echo esc_html( $value['label'] ); ?></span>
					</button>
				<?php endforeach; ?>
			</div>

		<?php else : // select type ?>
			<select class="zymarg-wcpg__qv-select"
				data-attribute-name="<?php echo esc_attr( $attr['name'] ); ?>"
				aria-label="<?php echo esc_attr( $attr['label'] ); ?>">
				<option value=""><?php esc_html_e( 'Choose an option', 'zymarg-wcpg' ); ?></option>
				<?php foreach ( $attr['values'] as $value ) : ?>
					<option value="<?php echo esc_attr( $value['value'] ); ?>"><?php echo esc_html( $value['label'] ); ?></option>
				<?php endforeach; ?>
			</select>
		<?php endif; ?>
	</div>
<?php endforeach; ?>
